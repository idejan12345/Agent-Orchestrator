# Migrating from SGWM 0.7.1 to CPO 0.8.0

The theoretical basis changed from the Structured Global Workspace Model (six-coordinate
diagnostics) to the focus loop of *A model for consciousness from binary sequences* (Stojkovic, 2026). Infrastructure is preserved.

| SGWM 0.7.1 | CPO 0.8.0 |
|---|---|
| package `sgwm`, env `SGWM_*`, headers `x-sgwm-*` | package `cpo`, env `CPO_*`, headers `x-cpo-*` |
| `Candidate.claimed_utility/confidence/grounding/novelty/consistency` | removed; `claimed_risk` (reject-only) and `evidence` remain |
| `CalibratingEvaluator`, calibration pipeline, synthetic bootstrap | removed (they calibrated claimed signals that no longer exist); optional `QualityHook` protocol |
| `TopKSelector` with temperature | top-φ by resonance × binding, capped by the capacity theorem |
| `DeterministicSynthesizer` | `MedoidConsensusWriter` / `ProviderConsensusWriter` |
| `change_signal` on admitted text | fractional Hamming change of the reference signature |
| six-coordinate proxies, viability bootstrap | `terminal_kind`, `occupancy`, `reconfirmation`, `plane_proxy` |
| `HierarchicalBundler` | `tower.bundle` with correlation block and serialisation bound |
| IFEval benchmark harness | not carried; the reconfirmation evaluation replaces it (see docs/PREREGISTRATION.md) |
| gateway, quotas, tracing, metrics, policies, provider adapters | unchanged |

Specialists must handle `workspace=None` on blind resamples without using stored broadcasts.
