# Release evidence for CPO 0.9.15

All files were produced by running the shipped code on 2026-09-14 (Python 3.12.3), via `make evidence`.

- `tests_summary.json`, `tests_output.txt` — pytest 91 passed; ruff clean; mypy clean
- `census_report.json` — `cpo-census` at reference parameters (n=24, N=20000, μ=0.15, η=0.20, φ=0.10, θ=3), 200 runs × seeds 1,2,3
- `plane_report.json` — `cpo-plane --length 200000 --offsets 100000`
- `security_scan.json` — stdlib pattern scan (0 high; medium findings are test fixtures named "secret")
- `external_security_summary.json`, `bandit.json`, `pip_audit.json`, `sbom.cdx.json` — bandit 0 findings; pip-audit of the wheel's runtime closure (17 packages) in a clean venv: 0 vulnerabilities; CycloneDX SBOM
- `load_test.json` — 500 in-process requests, all HTTP 200 (echo specialists; not a network benchmark)
- `staging_validation.json` — separate uvicorn process, 16 checks over real HTTP, all passed
- `go_no_go.json` — 8/10 gates GO; NO-GO pending provider smoke tests (credentials) and container scan (registry)

## Census vs paper

| quantity | paper | paper's independent reimplementation | this package (3 seeds) |
|---|---|---|---|
| fixed point reached | 200/200 | — | 99.5–100 % |
| non-motif rate | 9 % [5.4, 13.9] | 2–8 % | 3–7 % (pooled 5.5 % [3.8, 7.6]) |
| iterations to settle | 2–4 | — | ~2.0 |
| non-motif mean pairwise d_H | 6.18 | 5.0 | 5.3–5.8 |
| distance to nearer motif (non-motif / random) | 5.22 / 9.33 | 6.2, 5.8 | 5.1–5.5 / 9.1–9.3 |
| distance to nearest chimera (non-motif / random) | 2.56 / 6.83 | — | 2.3–2.7 / 6.7–6.9 |
| non-motif orders | 0.52–0.70 | — | 0.52–0.78 |

## Plane vs paper (W, M* in bits)

| archetype | paper | this package |
|---|---|---|
| noise | 0.00, 0.00 | 0.00, 0.00 |
| plant | 0.02, 0.00 | 0.02, 0.00 |
| thermostat | 0.38, 0.02 | 0.29, 0.02 |
| animal | 1.00, 0.11 | 0.81, 0.07 |
| dreamer | 0.06, 0.31 | 0.00, 0.57 |
| human | 1.19, 0.56 | 0.96, 0.83 |

The pattern (dissociation) reproduces; the absolute values do not, which the paper's Appendix
says to expect from a different realisation of the generators and estimator details.
