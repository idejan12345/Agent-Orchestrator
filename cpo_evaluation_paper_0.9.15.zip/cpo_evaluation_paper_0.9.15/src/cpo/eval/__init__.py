"""Evaluation harness for the preregistered H4/H5 protocol."""

from .baselines import BestOfN, CPOMethod, Debate, MethodRun, SelfConsistency, default_methods
from .harness import HarnessConfig, RunRecord, apply_ratings, run_evaluation, summarise
from .metrics import MethodOutcome, bootstrap_difference, wilson
from .tasks import Task, grade, load_tasks

__all__ = [
    "BestOfN",
    "CPOMethod",
    "Debate",
    "HarnessConfig",
    "MethodOutcome",
    "MethodRun",
    "RunRecord",
    "SelfConsistency",
    "Task",
    "apply_ratings",
    "bootstrap_difference",
    "default_methods",
    "grade",
    "load_tasks",
    "run_evaluation",
    "summarise",
    "wilson",
]
