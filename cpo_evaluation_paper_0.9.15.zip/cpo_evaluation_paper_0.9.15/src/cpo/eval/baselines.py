"""Baseline orchestration methods, under a common interface and a common budget.

Every method receives the same specialist prompts and the same call budget, and
returns a ``MethodRun``: the final answer, the number of provider calls it made,
token usage, and the candidate texts of its *last* round (used by the blind
support test, which is applied identically to all methods).

The budget is expressed in provider calls, so a method that uses fewer calls per
round may use more rounds.  Each method reports the calls it actually made; the
harness records both the cap and the actual.
"""

from __future__ import annotations

import asyncio
import contextvars
from collections import Counter
from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import Protocol

from ..config import CPOConfig
from ..consumers import TextConsumer
from ..models import OrchestrationRequest
from ..orchestrator import Orchestrator
from ..provider_specialist import (
    JudgedConsensusWriter,
    ProviderConsensusWriter,
    ProviderSpecialist,
    TextProvider,
)
from .tasks import answer_key


@dataclass
class MethodRun:
    answer: str
    calls: int = 0
    prompt_tokens: int = 0
    completion_tokens: int = 0
    rounds: int = 0
    final_candidates: list[str] = field(default_factory=list)
    detail: dict = field(default_factory=dict)
    error: str | None = None


class CountingProvider:
    """Wraps a provider and counts calls and tokens.  One instance per run."""

    def __init__(self, inner: TextProvider, budget: int):
        self.inner, self.budget = inner, budget
        self.calls = 0
        self.prompt_tokens = 0
        self.completion_tokens = 0
        self.provider_name = getattr(inner, "provider_name", "provider")

    @property
    def remaining(self) -> int:
        return max(0, self.budget - self.calls)

    async def generate(self, prompt: str, *, request_id: str):
        if self.remaining <= 0:
            raise RuntimeError("call budget exhausted")
        self.calls += 1
        result = await self.inner.generate(prompt, request_id=request_id)
        usage = dict(result.usage or {})
        self.prompt_tokens += int(usage.get("input_tokens") or usage.get("prompt_tokens") or 0)
        self.completion_tokens += int(usage.get("output_tokens") or usage.get("completion_tokens") or 0)
        return result

    async def readiness(self):
        return await self.inner.readiness()

    async def close(self):
        return None  # the harness owns the inner provider's lifetime


class Method(Protocol):
    name: str

    async def run(self, task_prompt: str, provider: CountingProvider, roles: dict[str, str]) -> MethodRun: ...


ANSWER_FORMAT = "Answer concisely. State your final answer on the last line as 'Answer: <answer>'."
PREAMBLE = "You are one specialist among several answering the same question."


DRAFT_FORMAT = "Write a complete, well-organised answer. Be specific and concrete."

# Set per run by the harness: True for tasks with a discrete answer (answer-line format and
# answer-line voting apply), False for drafting tasks (rubric-graded, judged reductions).
# The grader of the task currently being run.  This used to be a module-level global, which is
# shared by every concurrently running asyncio task: in a task file mixing rubric and discrete
# families, one run could flip it under another mid-flight (best-of-n would then pick the wrong
# judge prompt).  A ContextVar is copied into each asyncio task at creation, so a value set inside
# one run is invisible to the others.
_GRADER: contextvars.ContextVar[str] = contextvars.ContextVar("cpo_eval_grader", default="exact")


def set_grader(grader: str) -> None:
    _GRADER.set(grader)


def current_grader() -> str:
    return _GRADER.get()


def set_discrete(value: bool) -> None:
    """Compatibility shim for callers that only know discrete-vs-rubric."""
    if not value:
        _GRADER.set("rubric")
    elif _GRADER.get() == "rubric":
        _GRADER.set("exact")


def is_discrete() -> bool:
    return _GRADER.get() != "rubric"


def _role_prompt(role_instruction: str, task_prompt: str, context: str | None = None) -> str:
    parts = [PREAMBLE, role_instruction, f"Question:\n{task_prompt}"]
    if context:
        parts.append(context)
    parts.append(ANSWER_FORMAT if is_discrete() else DRAFT_FORMAT)
    return "\n\n".join(parts)


def cpo_specialist(name: str, role_instruction: str, provider) -> ProviderSpecialist:
    """A CPO specialist whose prompt is *identical* to the baselines' ``_role_prompt`` except
    for the workspace block that the method itself requires: same preamble, same role text,
    same question framing, same answer-format instruction, nothing else.

    Baseline prompt:  PREAMBLE / role / Question / [context] / ANSWER_FORMAT
    CPO prompt:       PREAMBLE / role / Question / [workspace] / ANSWER_FORMAT
    """
    return ProviderSpecialist(
        name,
        provider,
        role_instruction=f"{PREAMBLE}\n\n{role_instruction}",
        preamble="",
        guidance="",
        workspace_label="Current shared draft:",
        answer_format=ANSWER_FORMAT if is_discrete() else DRAFT_FORMAT,
    )


class ThrottledProvider:
    """Caps in-flight requests to a shared provider across every concurrent run."""

    def __init__(self, inner: TextProvider, max_inflight: int):
        self.inner = inner
        self.provider_name = getattr(inner, "provider_name", "provider")
        self._sem = asyncio.Semaphore(max_inflight)

    async def generate(self, prompt: str, *, request_id: str):
        async with self._sem:
            return await self.inner.generate(prompt, request_id=request_id)

    async def readiness(self):
        return await self.inner.readiness()

    async def close(self):
        await self.inner.close()


async def _sample(provider: CountingProvider, prompts: list[tuple[str, str]]) -> list[str]:
    """Issue the given (prompt, request_id) pairs concurrently, within the remaining budget."""
    if provider.remaining <= 0:
        raise RuntimeError("call budget exhausted")
    prompts = prompts[: provider.remaining]
    results = await asyncio.gather(*(provider.generate(p, request_id=rid) for p, rid in prompts))
    return [r.text for r in results]


def final_answer_line(text: str) -> str:
    """One parser for the answer line, shared with grading (it used to miss an indented
    'Answer:' line that the grader found)."""
    from .tasks import answer_line

    return answer_line(text)


def judge_prompt(task_prompt: str, texts: Sequence[str]) -> str:
    """The judge instruction shared by best-of-n and the convergence-gated judge, so that any
    difference between the two methods is in *when* the judge is called, not in what it is told."""
    listing = "\n\n".join(f"[{i + 1}] {t}" for i, t in enumerate(texts))
    if is_discrete():
        return (
            "Several candidate answers to the same question are listed below. "
            "Choose the single best one and reproduce it verbatim, then state the final answer "
            "on the last line as 'Answer: <answer>'.\n\n"
            f"Question:\n{task_prompt}\n\nCandidates:\n{listing}"
        )
    return (
        "Several candidate answers to the same question are listed below. "
        "Choose the single best one for correctness, specificity and organisation, and reproduce "
        f"it verbatim.\n\nQuestion:\n{task_prompt}\n\nCandidates:\n{listing}"
    )


# --------------------------------------------------------------------------- #
class BestOfN:
    """Sample n candidates, then one judge call picks the best."""

    name = "best_of_n"

    async def run(self, task_prompt, provider, roles):
        n = max(1, provider.budget - 1)
        names = list(roles)
        texts = await _sample(
            provider,
            [(_role_prompt(roles[names[i % len(names)]], task_prompt), f"bon-{i}") for i in range(n)],
        )
        r = await provider.generate(judge_prompt(task_prompt, texts), request_id="bon-judge")
        return MethodRun(answer=r.text, calls=provider.calls, rounds=1, final_candidates=texts)


class SelfConsistency:
    """Sample n candidates and take the majority over extracted final answers."""

    name = "self_consistency"
    requires_discrete = True  # answer-string voting is undefined for open-ended drafts

    async def run(self, task_prompt, provider, roles):
        n = max(1, provider.budget)
        names = list(roles)
        texts = await _sample(
            provider, [(_role_prompt(roles[names[i % len(names)]], task_prompt), f"sc-{i}") for i in range(n)]
        )

        g = current_grader()
        votes = Counter(answer_key(t, g) for t in texts)
        winner, _ = votes.most_common(1)[0]
        best = min((t for t in texts if answer_key(t, g) == winner), key=lambda t: (len(t), t))
        return MethodRun(
            answer=best,
            calls=provider.calls,
            rounds=1,
            final_candidates=texts,
            detail={"votes": dict(votes)},
        )


class Debate:
    """m agents, r rounds, each agent seeing the others' previous answers; final round
    answers are majority-voted (Du et al. 2023)."""

    name = "debate"

    def __init__(self, agents: int = 3):
        self.agents = agents

    async def run(self, task_prompt, provider, roles):
        names = list(roles)
        m = min(self.agents, max(2, len(names)))
        judged = not is_discrete()  # open-ended drafts: a judge picks from the final round
        rounds = max(1, (provider.budget - (1 if judged else 0)) // m)
        texts = ["" for _ in range(m)]
        for rnd in range(rounds):
            context = None
            if rnd:
                context = "Other specialists answered:\n" + "\n\n".join(
                    f"[{j + 1}] {t}" for j, t in enumerate(texts)
                )
            new = await _sample(
                provider,
                [
                    (_role_prompt(roles[names[j % len(names)]], task_prompt, context), f"deb-{rnd}-{j}")
                    for j in range(m)
                ],
            )
            if not new:
                break
            texts = new + texts[len(new) :]

        finals = [t for t in texts if t]
        if judged and provider.remaining > 0 and len(finals) > 1:
            listing = "\n\n".join(f"[{i + 1}] {t}" for i, t in enumerate(finals))
            r = await provider.generate(
                "Several specialists have debated the question below. Their final answers are listed. "
                "Choose the single best one for correctness, specificity and organisation, and reproduce it "
                f"verbatim.\n\nQuestion:\n{task_prompt}\n\nFinal answers:\n{listing}",
                request_id="deb-judge",
            )
            return MethodRun(
                answer=r.text,
                calls=provider.calls,
                rounds=rounds,
                final_candidates=finals,
                detail={"reduction": "judge"},
            )
        g = current_grader()
        votes = Counter(answer_key(t, g) for t in finals)
        winner, _ = votes.most_common(1)[0]
        best = min((t for t in finals if answer_key(t, g) == winner), key=len)
        return MethodRun(
            answer=best,
            calls=provider.calls,
            rounds=rounds,
            final_candidates=finals,
            detail={"votes": dict(votes)},
        )


class CPOMethod:
    """The focus loop.  ``ablation`` switches off one component at a time (H5)."""

    selects_candidates = True  # reference-relative selection: p_sel is measured

    def __init__(
        self,
        ablation: str = "full",
        config: CPOConfig | None = None,
        signer=None,
        pool_size: int | None = None,
        name: str | None = None,
        judged: bool = False,
        merge: bool = False,
    ):
        self.ablation = ablation
        self.judged = judged  # judge-written consensus text: one extra call per cycle
        self.merge = merge  # model-merged consensus text (drafting mode): one extra call per cycle
        self.pool_size = pool_size  # None -> one specialist per role; else fill the pool by cycling roles
        self.name = name or ("cpo" if ablation == "full" else f"cpo_no_{ablation}")
        self.base_config = config or CPOConfig()
        self.signer = signer
        # Overwritten by the harness from HarnessConfig before the sweep starts; these defaults
        # are what a bare CPOMethod() uses in tests.
        self.eval_limits: dict = {
            "call_timeout_s": 180.0,
            "request_timeout_s": 3600.0,
            "max_candidate_chars": 120_000,
            "max_workspace_chars": 200_000,
        }

    def _config(self, budget: int, specialists: int) -> CPOConfig:
        m = max(1, specialists)
        rounds = 0 if self.ablation == "reconfirmation" else self.base_config.reconfirmation_rounds
        # reserve the reconfirmation calls so the blind re-query never hits the budget wall
        per_cycle = m + (1 if (self.judged or self.merge) else 0)  # writer call per cycle
        cycles = max(1, (budget - rounds * m) // per_cycle)
        # Evaluation limits.  The production defaults (5 s per specialist, 30 s per request, 12k
        # characters per candidate) are for an interactive service.  Under evaluation each of them
        # is a way to lose a candidate *silently* — a timeout or an over-long answer removes it
        # from the pool, which biases whichever method is slowest or most verbose — so they are
        # taken from the harness config, which preflight_limits() has already checked for mutual
        # consistency.  The baselines call the provider directly and are bounded by the adapter.
        limits = self.eval_limits
        overrides: dict = {
            "max_cycles": min(self.base_config.max_cycles, cycles),
            "specialist_timeout_s": limits["call_timeout_s"],
            "consumer_timeout_s": limits["call_timeout_s"],
            "request_timeout_s": limits["request_timeout_s"],
            "max_candidate_chars": limits["max_candidate_chars"],
            "max_workspace_chars": limits["max_workspace_chars"],
            "trace_candidate_texts": True,  # needed for the p_sel measurement
        }
        if self.ablation == "consensus":
            overrides["k_min"] = 1
            overrides["consensus_required"] = False
        if self.ablation == "reconfirmation":
            overrides["reconfirmation_rounds"] = 0
        if self.ablation == "occupancy":
            overrides["occupancy_control_enabled"] = False
        return self.base_config.model_copy(update=overrides)

    def _make_specialists(self, provider, roles):
        """One specialist per role by default.  With pool_size set, fill to that many by cycling the
        role instructions, giving each a distinct name so the orchestrator's uniqueness check passes.
        This lets a fixed call budget be spent as breadth (large pool, few cycles) or depth (small
        pool, many cycles)."""
        items = list(roles.items())
        if self.pool_size is None:
            return [cpo_specialist(n, r, provider) for n, r in items]
        out = []
        for i in range(self.pool_size):
            base_name, role = items[i % len(items)]
            out.append(cpo_specialist(f"{base_name}-{i}", role, provider))
        return out

    async def run(self, task_prompt, provider, roles):
        specialists = self._make_specialists(provider, roles)
        cfg = self._config(provider.budget, len(specialists))
        if self.ablation == "consensus":
            # selection only: keep exactly one candidate per cycle, no vote
            cfg = cfg.model_copy(update={"k_min": 1, "k_max": 1})
        writer = None
        if self.merge:
            writer = ProviderConsensusWriter(provider)
        elif self.judged:
            writer = JudgedConsensusWriter(provider)
        orch = Orchestrator(
            specialists, [TextConsumer()], config=cfg, signer=self.signer, consensus_writer=writer
        )
        request = OrchestrationRequest(input=task_prompt, goal=None)
        result = await orch.run(request)
        ws = result.workspace
        return MethodRun(
            answer=ws.synthesis if ws else "",
            calls=provider.calls,
            rounds=len(result.cycles),
            final_candidates=[s.candidate.content for s in (ws.selected if ws else [])],
            detail={
                "terminal_kind": ws.terminal_kind if ws else None,
                "reconfirmation": result.reconfirmation.status if result.reconfirmation else None,
                "blind_consensus_distance": (
                    result.reconfirmation.blind_consensus_distance if result.reconfirmation else None
                ),
                "consensus_agreement": ws.consensus_agreement if ws else None,
                "change_signals": [round(c.change_signal, 4) for c in result.cycles],
                "cycle_failures": [c.failures for c in result.cycles],
                "specialist_failures_total": sum(len(c.failures) for c in result.cycles),
                "warnings": result.warnings[:5],
                # Per-cycle pool and selected candidate texts, for the p_sel measurement the
                # harness performs with the task's own grader.  Empty unless the config enabled
                # trace_candidate_texts (evaluation only).
                "cycles": [
                    {"cycle": c.cycle, "pool_texts": c.pool_texts, "selected_texts": c.selected_texts}
                    for c in result.cycles
                ],
            },
        )


# --------------------------------------------------------------------------- #
# 0.9.3 — convergence used for what the theory is actually good at
# --------------------------------------------------------------------------- #
class AdaptiveConsensus:
    """The fixed-point criterion as a *stopping rule* over blind batches.

    Draw batches of ``batch`` independent candidates.  Every batch is blind -- no workspace is
    shown -- so agreement is independent agreement, not echo: each batch is a blind reconfirmation
    of the running consensus.  Stop as soon as the consensus is a reconfirmed fixed point:

    * after batch 1, if it is unanimous;
    * after batch t >= 2, if the running plurality did not change in this batch and at least
      two-thirds of the batch agrees with it.

    The reference is the pool's own consensus, never the request: Proposition 1 says selecting
    toward an uninformative reference only shrinks the pool, so nothing is discarded before the
    vote.  Offline replay on the released draws (docs/OFFLINE_REPLAY_PREREG.md): matches plurality
    over 9 draws at a mean of 6.3.
    """

    name = "cpo_adaptive"
    requires_discrete = True
    selects_candidates = False  # nothing is discarded before the vote, so p_sel is undefined

    def __init__(self, batch: int = 3, *, reserve: int = 0, name: str | None = None):
        self.batch = max(2, batch)
        self.reserve = reserve  # calls held back (the gated judge keeps one)
        if name:
            self.name = name

    async def _converge(self, task_prompt, provider, roles) -> tuple[list[str], str, bool, int]:
        g = current_grader()
        names = list(roles)
        texts: list[str] = []
        previous: str | None = None
        batches = max(1, (provider.budget - self.reserve) // self.batch)
        for t in range(batches):
            n = min(self.batch, provider.remaining - self.reserve)
            if n <= 0:
                break
            prompts = [
                (_role_prompt(roles[names[(t * self.batch + i) % len(names)]], task_prompt), f"ad-{t}-{i}")
                for i in range(n)
            ]
            batch = await _sample(provider, prompts)
            texts += batch
            keys = [answer_key(x, g) for x in batch]
            current = Counter(answer_key(x, g) for x in texts).most_common(1)[0][0]
            if t == 0 and len(set(keys)) == 1 and len(keys) == self.batch:
                return texts, current, True, t + 1
            if t >= 1 and current == previous and sum(k == current for k in keys) * 3 >= 2 * len(keys):
                return texts, current, True, t + 1
            previous = current
        winner = Counter(answer_key(x, g) for x in texts).most_common(1)[0][0]
        return texts, winner, False, batches

    def _pick(self, texts: list[str], winner: str) -> str:
        g = current_grader()
        return min((t for t in texts if answer_key(t, g) == winner), key=lambda t: (len(t), t))

    async def run(self, task_prompt, provider, roles):
        texts, winner, converged, used = await self._converge(task_prompt, provider, roles)
        votes = Counter(answer_key(t, current_grader()) for t in texts)
        return MethodRun(
            answer=self._pick(texts, winner),
            calls=provider.calls,
            rounds=used,
            final_candidates=texts,
            detail={"votes": dict(votes), "converged": converged, "batches_used": used},
        )


class GatedJudge(AdaptiveConsensus):
    """Converge cheaply where the pool agrees; verify only where it does not.

    Runs :class:`AdaptiveConsensus` with one call held in reserve.  If the pool reaches a
    reconfirmed fixed point, that answer stands and the judge is never called.  If it does not
    converge within budget, a judge reads the *whole* pool -- not a pre-selected subset, which is
    the step the paper found costly -- and picks the answer, with the same instruction best-of-n
    uses.

    Rationale from the offline replay (exploratory, not preregistered): runs that converge early
    are where shared, systematic errors sit and no verifier can help; runs that fail to converge
    hold 56.5% of all errors and contain the correct answer 97.5% of the time.  The convergence
    test is used to decide *whether* verification is needed; the judge decides *what* is right.
    A perfect judge on non-converged runs only would bound accuracy at 0.838 against plurality's
    0.651 on the replay pools; a real judge is not perfect, so the live number must be measured.
    """

    name = "cpo_gated_judge"

    def __init__(self, batch: int = 3, *, name: str | None = None):
        super().__init__(batch, reserve=1, name=name or "cpo_gated_judge")

    async def run(self, task_prompt, provider, roles):
        texts, winner, converged, used = await self._converge(task_prompt, provider, roles)
        votes = Counter(answer_key(t, current_grader()) for t in texts)
        judged = False
        answer = self._pick(texts, winner)
        if not converged and provider.remaining >= 1 and len(votes) > 1:
            r = await provider.generate(judge_prompt(task_prompt, texts), request_id="gated-judge")
            answer = r.text
            judged = True
        return MethodRun(
            answer=answer,
            calls=provider.calls,
            rounds=used,
            final_candidates=texts,
            detail={
                "votes": dict(votes),
                "converged": converged,
                "batches_used": used,
                "judge_called": judged,
            },
        )


def default_methods(agents: int = 3, signer=None) -> list[Method]:
    """The preregistered methods: three baselines, CPO and its ablations, and (0.9.4) the two
    convergence-gated methods.  ``signer`` defaults to the marker-weighted SimHash
    (the evaluation representation); the plain-SimHash row is the representation ablation."""
    from ..sketch import MarkerWeightedSigner, SimHashSigner

    signer = signer or MarkerWeightedSigner(256)
    methods: list[Method] = [
        BestOfN(),
        SelfConsistency(),
        Debate(agents=agents),
        CPOMethod("full", signer=signer),
        CPOMethod("full", signer=signer, judged=True, name="cpo_judged"),
        CPOMethod("consensus", signer=signer),
        CPOMethod("reconfirmation", signer=signer),
        CPOMethod("occupancy", signer=signer),
        AdaptiveConsensus(),
        GatedJudge(),
    ]
    if not isinstance(signer, SimHashSigner):
        plain = CPOMethod("full", signer=SimHashSigner(256))
        plain.name = "cpo_plain_simhash"
        methods.append(plain)
    return methods


async def gather_limited(coros: Sequence, limit: int):
    sem = asyncio.Semaphore(limit)

    async def guarded(c):
        async with sem:
            return await c

    return await asyncio.gather(*(guarded(c) for c in coros), return_exceptions=True)
