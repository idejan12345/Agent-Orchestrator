"""The evaluation harness for H4 and H5.

One *run* is (task, method, condition, seed).  Every run:

1. executes the method under a fixed provider-call budget;
2. grades the final answer (deterministic grader, or defers to human rating);
3. applies the **blind support test** identically to every method: the same
   specialists are asked the task again with no memory of the run, and the final
   answer is compared with the fresh pool.  A final answer the fresh pool does
   not support is a *history-locked convergence*.

Conditions (manuscript section 7):
  clean            - the declared specialist roles
  noisy            - a share of specialists replaced by a distractor role
  history_locking  - specialists are told to build on the previous shared draft

Results are written as JSONL (one object per run) plus a summary JSON.  Runs are
resumable: an existing results file is read first and completed runs are skipped,
so a long evaluation can be interrupted without losing spend.
"""

from __future__ import annotations

import asyncio
import json
import time
from collections.abc import Sequence
from dataclasses import asdict, dataclass, field
from pathlib import Path

from ..sketch import Signature
from .baselines import CountingProvider, Method, MethodRun, _role_prompt, set_grader
from .metrics import MethodOutcome, bootstrap_difference
from .tasks import Task, answers_equivalent, grade

CLEAN_ROLES = {
    "analyst": "Work through the problem step by step and state what the evidence supports.",
    "planner": "Give the concrete steps or computation that lead to the answer.",
    "critic": "Check the reasoning for errors and state the answer you believe is correct.",
}
DISTRACTOR_ROLE = (
    "Answer briefly from general impressions without working through the problem; "
    "do not verify your reasoning."
)
LOCKING_SUFFIX = (
    "\n\nBuild directly on the shared draft you are given and preserve its conclusions "
    "unless they are clearly contradicted."
)


@dataclass
class RunRecord:
    task_id: str
    family: str
    method: str
    condition: str
    seed: int
    answer_excerpt: str
    correct: bool | None
    blind_supported: bool | None
    blind_distance: float | None
    calls: int
    budget: int
    rounds: int
    prompt_tokens: int
    completion_tokens: int
    elapsed_s: float
    detail: dict = field(default_factory=dict)
    error: str | None = None
    answer_full: str | None = None  # complete answer text; populated for rubric tasks (rating needs it)

    def key(self) -> str:
        return f"{self.task_id}|{self.method}|{self.condition}|{self.seed}"


CONDITIONS = ("clean", "noisy", "history_locking")


def roles_for(condition: str, noisy_share: float) -> dict[str, str]:
    if condition not in CONDITIONS:
        raise ValueError(f"unknown condition {condition!r}; expected one of {CONDITIONS}")
    roles = dict(CLEAN_ROLES)
    if condition == "noisy":
        names = list(roles)
        k = max(1, round(noisy_share * len(names)))
        for name in names[:k]:
            roles[name] = DISTRACTOR_ROLE
    elif condition == "history_locking":
        roles = {n: r + LOCKING_SUFFIX for n, r in roles.items()}
    return roles


async def blind_support(
    task: Task,
    answer: str,
    provider: CountingProvider,
    roles: dict[str, str],
    *,
    draws: int,
    signature_bits: int,
    theta: float,
) -> tuple[bool | None, float | None]:
    """Ask the specialists again with no memory of the run; is the answer supported?

    Two agreeing signals are required to call an answer supported: the final-answer
    line matches at least one fresh candidate's final-answer line (normalised), or
    the answer's signature is within ``theta`` of the fresh pool's majority.  The
    distance is returned for auditing and for threshold sensitivity analysis.
    """
    fresh: list[str] = []
    names = list(roles)
    for i in range(draws):
        if provider.remaining <= 0:
            break
        role = roles[names[i % len(names)]]
        try:
            r = await provider.generate(_role_prompt(role, task.prompt), request_id=f"blind-{i}")
        except Exception:
            break
        fresh.append(r.text)
    if not fresh:
        return None, None
    from ..sketch import majority

    sig = Signature.of_text(answer, signature_bits)
    pool = [Signature.of_text(t, signature_bits) for t in fresh]
    distance = sig.hamming(majority(pool, Signature(0, signature_bits))) / signature_bits
    literal = any(answers_equivalent(task, answer, t) for t in fresh)
    return (literal or distance <= theta), distance



def measure_selection_quality(task: Task, detail: dict) -> dict | None:
    """p_sel vs p: does reference-relative selection keep the correct candidates?

    Proposition 1 of the paper says selection can only pay when similarity to the reference is
    informative about correctness, i.e. when ``p_sel > p``.  This is the direct measurement of
    that condition, and it is the primary outcome of Stage 1 of PROTOCOL_V2.  Defined only for
    tasks with a discrete grader; rubric tasks need a rating pass and are handled separately.
    """
    if task.grader == "rubric":
        return None
    cycles = detail.get("cycles") or []
    pool_n = pool_ok = sel_n = sel_ok = 0
    per_cycle = []
    for c in cycles:
        pool = [t for t in (c.get("pool_texts") or []) if t]
        sel = [t for t in (c.get("selected_texts") or []) if t]
        if not pool:
            continue
        p_ok = sum(1 for t in pool if grade(task, t))
        s_ok = sum(1 for t in sel if grade(task, t))
        pool_n += len(pool)
        pool_ok += p_ok
        sel_n += len(sel)
        sel_ok += s_ok
        per_cycle.append(
            {
                "cycle": c.get("cycle"),
                "pool": len(pool),
                "pool_correct": p_ok,
                "selected": len(sel),
                "selected_correct": s_ok,
            }
        )
    if not pool_n or not sel_n:
        return None
    p = pool_ok / pool_n
    p_sel = sel_ok / sel_n
    return {
        "p": round(p, 4),
        "p_sel": round(p_sel, 4),
        "p_sel_minus_p": round(p_sel - p, 4),
        "pool_candidates": pool_n,
        "pool_correct": pool_ok,
        "selected_candidates": sel_n,
        "selected_correct": sel_ok,
        "per_cycle": per_cycle,
    }

NOT_APPLICABLE = "not_applicable"


def is_not_applicable(r: RunRecord) -> bool:
    """A discrete-only method on a rubric task: correctly not run, so neither a result nor a failure."""
    return r.error is not None and r.error.startswith(NOT_APPLICABLE)


def is_failure(r: RunRecord) -> bool:
    """A run that should have produced a result and did not.

    Before 0.9.4 every non-empty ``error`` counted, so in a task file mixing rubric and discrete
    families the not-applicable rows of the discrete-only methods were retried, counted as
    failures and failed the preflight -- which would have blocked Stage 2 of PROTOCOL_V2 outright.
    """
    return bool(r.error) and not is_not_applicable(r)

@dataclass
class HarnessConfig:
    budget: int = 12  # provider calls per run, identical across methods; matches the protocol and CLI
    blind_draws: int = 3
    blind_theta: float = 0.15
    signature_bits: int = 256
    conditions: tuple[str, ...] = ("clean", "noisy", "history_locking")
    noisy_share: float = 0.34
    seeds: tuple[int, ...] = (1,)
    concurrency: int = 4
    # --- limits -----------------------------------------------------------------
    # Every one of these is a way to lose a candidate silently, so each is explicit, generous by
    # default, and checked for mutual consistency by ``preflight_limits`` before a paid run.
    # None = derive from the budget (see __post_init__): the whole run must be allowed to take
    # every call's full timeout plus a round of retry backoff, or slow runs become fake failures.
    per_run_timeout_s: float | None = None
    call_timeout_s: float = 180.0  # one provider call inside the orchestrator
    max_output_tokens: int = 8192  # truncation is detected, not silently accepted
    max_candidate_chars: int = 120_000  # an over-long candidate is DROPPED, not clipped
    max_workspace_chars: int = 200_000
    retry_failed_runs: int = 1  # automatic re-run pass for errored runs

    def __post_init__(self) -> None:
        if self.per_run_timeout_s is None:
            # 1.25x the worst case: headroom for scheduling jitter without masking a real hang.
            self.per_run_timeout_s = round(self.worst_case_run_seconds() * 1.25)

    def worst_case_run_seconds(self, retry_backoff_s: float = 90.0) -> float:
        """Upper estimate of one run's wall-clock: every call taking the full timeout, plus one
        round of retry backoff.  ``per_run_timeout_s`` must exceed this or slow runs are recorded
        as failures and the arm that is slowest is the one that loses candidates."""
        return (self.budget + self.blind_draws) * self.call_timeout_s + retry_backoff_s


def preflight_limits(cfg: HarnessConfig) -> list[str]:
    """Return a list of limit inconsistencies that would corrupt a run. Empty list means safe.

    This exists because the 0.9.1 drafting run failed 43/240 CPO runs on an inherited 5 s
    specialist timeout: the limits were individually plausible and jointly wrong, and nothing
    checked them against each other before the money was spent.
    """
    problems: list[str] = []
    worst = cfg.worst_case_run_seconds()
    if cfg.per_run_timeout_s is not None and cfg.per_run_timeout_s < worst:
        problems.append(
            f"per_run_timeout_s={cfg.per_run_timeout_s:.0f}s is below the worst-case run time "
            f"({worst:.0f}s = ({cfg.budget}+{cfg.blind_draws}) calls x {cfg.call_timeout_s:.0f}s "
            "+ retry backoff). Slow runs will be recorded as errors and the slowest method loses "
            "the most candidates."
        )
    if cfg.call_timeout_s < 30:
        problems.append(
            f"call_timeout_s={cfg.call_timeout_s:.0f}s is very low for a real model; a timeout "
            "removes a candidate from the pool rather than failing loudly."
        )
    if cfg.max_output_tokens < 2048:
        problems.append(
            f"max_output_tokens={cfg.max_output_tokens} risks truncating long answers. Truncation "
            "is now detected and fails the run, so this mainly wastes money."
        )
    if cfg.max_candidate_chars < 4 * cfg.max_output_tokens:
        problems.append(
            f"max_candidate_chars={cfg.max_candidate_chars} is smaller than the ~{4 * cfg.max_output_tokens} "
            "characters max_output_tokens can produce; long candidates would be dropped from the pool."
        )
    if cfg.blind_draws < 1:
        problems.append("blind_draws=0 leaves the lock metric undefined; H4 cannot be tested.")
    return problems


async def run_one(
    task: Task,
    method: Method,
    condition: str,
    seed: int,
    provider_factory,
    cfg: HarnessConfig,
) -> RunRecord:
    roles = roles_for(condition, cfg.noisy_share)
    set_grader(task.grader)  # context-local: concurrent runs cannot see each other's grader
    if task.grader == "rubric" and getattr(method, "requires_discrete", False):
        return RunRecord(
            task_id=task.id,
            family=task.family,
            method=method.name,
            condition=condition,
            seed=seed,
            answer_excerpt="",
            correct=None,
            blind_supported=None,
            blind_distance=None,
            calls=0,
            budget=cfg.budget,
            rounds=0,
            prompt_tokens=0,
            completion_tokens=0,
            elapsed_s=0.0,
            detail={},
            error="not_applicable: method requires a discrete answer",
        )
    counter = CountingProvider(provider_factory(), cfg.budget)
    started = time.perf_counter()
    error = None
    try:
        result: MethodRun = await asyncio.wait_for(
            method.run(task.prompt, counter, roles), timeout=cfg.per_run_timeout_s
        )
    except Exception as exc:
        result = MethodRun(answer="", calls=counter.calls)
        error = f"{type(exc).__name__}: {str(exc)[:160]}"
    elapsed = time.perf_counter() - started
    correct = grade(task, result.answer) if result.answer and not error else None
    supported, distance = (None, None)
    if result.answer and not error and task.grader != "rubric":
        # The primary outcome is defined for tasks with a discrete deliverable. Rubric tasks have
        # no "reproduced answer" to test, so they are graded by humans and excluded from the
        # lock metric rather than counted as locked; their blind distance is still recorded.
        blind_counter = CountingProvider(provider_factory(), cfg.blind_draws)
        supported, distance = await blind_support(
            task,
            result.answer,
            blind_counter,
            CLEAN_ROLES,  # the blind pool always uses the clean roles
            draws=cfg.blind_draws,
            signature_bits=cfg.signature_bits,
            theta=cfg.blind_theta,
        )
        counter.prompt_tokens += blind_counter.prompt_tokens
        counter.completion_tokens += blind_counter.completion_tokens
    elif result.answer and not error:
        blind_counter = CountingProvider(provider_factory(), cfg.blind_draws)
        _, distance = await blind_support(
            task,
            result.answer,
            blind_counter,
            CLEAN_ROLES,
            draws=cfg.blind_draws,
            signature_bits=cfg.signature_bits,
            theta=cfg.blind_theta,
        )
    detail = dict(result.detail)
    sel_quality = None if error else measure_selection_quality(task, detail)
    if sel_quality is not None:
        detail["selection_quality"] = sel_quality
    # The per-cycle candidate texts are only needed to compute the figures above; keep the record
    # small by dropping them once measured (answer_full still carries the deliverable).
    detail.pop("cycles", None)
    return RunRecord(
        task_id=task.id,
        family=task.family,
        method=method.name,
        condition=condition,
        seed=seed,
        answer_excerpt=result.answer[:400],
        correct=correct,
        blind_supported=supported,
        blind_distance=distance,
        calls=counter.calls,
        budget=cfg.budget,
        rounds=result.rounds,
        prompt_tokens=counter.prompt_tokens,
        completion_tokens=counter.completion_tokens,
        elapsed_s=round(elapsed, 3),
        detail=detail,
        error=error,
        answer_full=(result.answer if (result.answer and not error) else None),
    )


def summarise(records: Sequence[RunRecord], reference: str = "cpo") -> dict:
    by: dict[tuple[str, str], MethodOutcome] = {}
    not_applicable = 0
    for r in records:
        if is_not_applicable(r):
            not_applicable += 1  # correctly not run: not a cell entry, not a failure
            continue
        out = by.setdefault((r.method, r.condition), MethodOutcome(method=r.method))
        out.runs += 1
        if r.error:
            out.failures += 1
            continue
        out.calls += r.calls
        out.cycles += r.rounds
        out.prompt_tokens += r.prompt_tokens
        out.completion_tokens += r.completion_tokens
        if r.correct is not None:
            out.add_correct(r.task_id, r.correct)
        if r.blind_supported is not None:
            out.add_locked(r.task_id, not r.blind_supported)
        if r.correct is not None and r.blind_supported is not None:
            out.add_lock_decomposition(bool(r.correct), bool(r.blind_supported))
        sq = (r.detail or {}).get("selection_quality")
        if isinstance(sq, dict):
            out.add_selection(sq)

    summary: dict = {"by_method_condition": {}, "comparisons": {}, "not_applicable_runs": not_applicable}
    for (method, condition), out in sorted(by.items()):
        summary["by_method_condition"][f"{method}|{condition}"] = out.summary()

    conditions = sorted({c for _, c in by})
    for condition in conditions:
        ref = by.get((reference, condition))
        if ref is None:
            continue
        for method, cond in sorted(by):
            if cond != condition or method == reference:
                continue
            other = by[(method, cond)]
            shared_lock = sorted(set(ref.per_task_locked) & set(other.per_task_locked))
            shared_q = sorted(set(ref.per_task_correct) & set(other.per_task_correct))
            entry: dict = {"paired_tasks_lock": len(shared_lock), "paired_tasks_quality": len(shared_q)}
            if shared_lock:
                obs, ci = bootstrap_difference(
                    [ref.per_task_locked[t] for t in shared_lock],
                    [other.per_task_locked[t] for t in shared_lock],
                )
                entry["lock_rate_difference"] = {
                    "cpo_minus_other": round(obs, 4),
                    "ci95": [round(ci[0], 4), round(ci[1], 4)],
                    "h4_supported": ci[1] < 0,
                }
            if shared_q:
                obs, ci = bootstrap_difference(
                    [ref.per_task_correct[t] for t in shared_q],
                    [other.per_task_correct[t] for t in shared_q],
                )
                entry["quality_difference"] = {
                    "cpo_minus_other": round(obs, 4),
                    "ci95": [round(ci[0], 4), round(ci[1], 4)],
                    "quality_not_worse": ci[0] > -0.05,
                }
            summary["comparisons"][f"{reference}_vs_{method}|{condition}"] = entry
    summary["preregistered_decision"] = _decide(summary)
    return summary


def _decide(summary: dict) -> dict:
    baselines = ("best_of_n", "self_consistency", "debate")
    lock_ok, quality_ok, checked = True, True, 0
    for key, entry in summary["comparisons"].items():
        method = key.split("_vs_")[1].split("|")[0]
        if method not in baselines or "lock_rate_difference" not in entry:
            continue
        checked += 1
        lock_ok = lock_ok and entry["lock_rate_difference"]["h4_supported"]
        quality_ok = quality_ok and entry.get("quality_difference", {}).get("quality_not_worse", True)
    decision: dict = {
        "comparisons_checked": checked,
        "H4_supported": bool(checked and lock_ok and quality_ok),
        "note": (
            "H4 requires CPO's history-locked convergence rate below every baseline's with a "
            "non-overlapping 95% interval and quality not materially worse. H5 is read from the "
            "cpo_no_* ablation rows, not from this flag."
        ),
    }
    if checked == 0:
        # Distinguish "H4 refuted" from "H4 never tested": the flag above is False in both cases.
        cells = summary["by_method_condition"].values()
        any_lock = any(c.get("history_locked_convergence") is not None for c in cells)
        has_baseline = any(c.get("method") in baselines for c in cells)
        if not any_lock:
            reason = (
                "H4 NOT TESTED: no run carries a history-locked convergence value. The lock metric is "
                "defined only for tasks with a discrete deliverable (graders exact/numeric/contains); "
                "rubric-graded tasks are excluded from it by design. Use a task file with discrete "
                "graders (e.g. the calibrated math set) to test H4."
            )
        elif not has_baseline:
            reason = (
                "H4 NOT TESTED: no baseline method (best_of_n, self_consistency, debate) is present "
                "in the run, so CPO has nothing to be compared against."
            )
        else:
            reason = (
                "H4 NOT TESTED: lock values exist but no CPO-vs-baseline pair shares a task id; "
                "check that the same task file was used for every method."
            )
        decision["H4_status"] = "not_tested"
        decision["reason"] = reason
    else:
        decision["H4_status"] = "supported" if decision["H4_supported"] else "not_supported"
    return decision


def task_set_summary(tasks: Sequence) -> dict:
    """Pre-flight description of a task set: how many tasks carry a discrete grader (and so can
    contribute to the H4 lock metric) versus a rubric grader (quality only, human/model rated)."""
    discrete = [t for t in tasks if getattr(t, "grader", "exact") != "rubric"]
    rubric = [t for t in tasks if getattr(t, "grader", "exact") == "rubric"]
    return {
        "tasks": len(tasks),
        "discrete_graded": len(discrete),
        "rubric_graded": len(rubric),
        "h4_testable": bool(discrete),
        "families": sorted({t.family for t in tasks}),
    }


def apply_ratings(
    records: Sequence[RunRecord], sheet: Sequence[dict], *, pass_threshold: float = 2.0
) -> list[RunRecord]:
    """Fold blind human ratings back into the run records.

    ``sheet`` is the rating sheet with ``rating`` filled in (a number, or a list of numbers
    from several raters, on the 0-3 scale the runbook prescribes).  A rubric answer counts
    as correct when its mean rating is at least ``pass_threshold``.  Unrated entries stay
    ungraded.  Returns new records; the originals are not modified.
    """
    by_run: dict[str, float] = {}
    for entry in sheet:
        rating = entry.get("rating")
        if rating is None:
            continue
        values = [float(v) for v in (rating if isinstance(rating, list) else [rating])]
        if not values:
            continue
        by_run[entry["run"]] = sum(values) / len(values)
    out = []
    for r in records:
        if r.key() in by_run and r.correct is None and not r.error:
            out.append(RunRecord(**{**asdict(r), "correct": by_run[r.key()] >= pass_threshold}))
        else:
            out.append(r)
    return out


def run_fingerprint(cfg: HarnessConfig, provenance: dict | None) -> dict:
    """The fields that change what an *existing* record means.

    A record is keyed by task|method|condition|seed, so adding seeds, tasks, methods or conditions
    only adds keys and is a legitimate way to extend a sweep on resume.  What must not change
    under an existing key is the budget, the blind test, the signature, the output ceiling or the
    model -- those make two records with the same key incomparable.  Reliability limits
    (timeouts, concurrency, retry passes) are excluded too: raising a timeout and resuming is the
    intended way to recover from slow calls."""
    import hashlib

    fields = {
        "budget": cfg.budget,
        "blind_draws": cfg.blind_draws,
        "blind_theta": cfg.blind_theta,
        "signature_bits": cfg.signature_bits,
        "noisy_share": cfg.noisy_share,
        "max_output_tokens": cfg.max_output_tokens,
    }
    for k, v in sorted((provenance or {}).items()):
        fields[f"provenance.{k}"] = v
    digest = hashlib.sha256(json.dumps(fields, sort_keys=True).encode()).hexdigest()[:16]
    return {"digest": digest, "fields": fields}


async def run_evaluation(
    tasks: Sequence[Task],
    methods: Sequence[Method],
    provider_factory,
    cfg: HarnessConfig,
    out_dir: str | Path,
    *,
    resume: bool = True,
    redo_methods: Sequence[str] = (),
    provenance: dict | None = None,
    max_total_tokens: int | None = None,
) -> dict:
    """Run the sweep.

    ``provenance`` (provider, model, task-file hash, ...) is folded into a fingerprint written to
    ``out_dir/run_fingerprint.json``; resuming into a directory whose fingerprint differs is refused,
    because silently mixing records from two configurations produces a summary that describes
    neither.  ``max_total_tokens`` stops launching new runs once cumulative usage reaches it, so a
    misconfiguration cannot run up an unbounded bill.
    """
    redo: set[str] = set(redo_methods)
    for c in cfg.conditions:
        if c not in CONDITIONS:
            raise ValueError(f"unknown condition {c!r}; expected one of {CONDITIONS}")
    problems = preflight_limits(cfg)
    if problems:
        raise ValueError(
            "harness limits are mutually inconsistent and would corrupt the run:\n  - "
            + "\n  - ".join(problems)
        )
    # Hand the checked limits to every CPO arm, so no arm silently runs on production defaults.
    for m in methods:
        if hasattr(m, "eval_limits"):
            m.eval_limits = {
                "call_timeout_s": cfg.call_timeout_s,
                "request_timeout_s": cfg.per_run_timeout_s,
                "max_candidate_chars": cfg.max_candidate_chars,
                "max_workspace_chars": cfg.max_workspace_chars,
            }
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    fingerprint = run_fingerprint(cfg, provenance)
    fp_path = out / "run_fingerprint.json"
    if fp_path.exists() and resume:
        previous = json.loads(fp_path.read_text(encoding="utf-8"))
        if previous.get("digest") != fingerprint["digest"]:
            old_f = previous.get("fields", {})
            new_f = fingerprint["fields"]
            changed = sorted(k for k in set(old_f) | set(new_f) if old_f.get(k) != new_f.get(k))
            raise ValueError(
                f"{out} holds records from a different configuration (changed: {changed}). "
                "Resuming would mix them into one summary. Use a new --out directory, or "
                "--no-resume to start this directory over."
            )
    fp_path.write_text(json.dumps(fingerprint, indent=2), encoding="utf-8")
    results_path = out / "runs.jsonl"
    done: set[str] = set()
    records: list[RunRecord] = []
    if resume and results_path.exists():
        latest: dict[str, RunRecord] = {}
        for line in results_path.read_text(encoding="utf-8").splitlines():
            if line.strip():
                rec = RunRecord(**json.loads(line))
                latest[rec.key()] = rec  # a retry supersedes the record it retried
        records = [r for r in latest.values() if r.method not in redo]
        done = {r.key() for r in records if not is_failure(r)}
        dropped = sum(1 for r in latest.values() if r.method in redo)
        if dropped:
            print(f"{dropped} existing records for {sorted(redo)} discarded for re-run")

    planned = [
        (t, m, c, s)
        for t in tasks
        for m in methods
        for c in cfg.conditions
        for s in cfg.seeds
        if f"{t.id}|{m.name}|{c}|{s}" not in done
    ]
    print(f"{len(done)} runs already complete; {len(planned)} to go")
    sem = asyncio.Semaphore(cfg.concurrency)
    lock = asyncio.Lock()

    spent = {"tokens": sum(r.prompt_tokens + r.completion_tokens for r in records)}
    stopped = {"by_cap": 0}

    async def worker(task, method, condition, seed):
        async with sem:
            if max_total_tokens is not None and spent["tokens"] >= max_total_tokens:
                stopped["by_cap"] += 1  # not launched; left for a resumed run
                return None
            record = await run_one(task, method, condition, seed, provider_factory, cfg)
            spent["tokens"] += record.prompt_tokens + record.completion_tokens
        async with lock:
            # replace any earlier record for the same run (a failed attempt being retried)
            records[:] = [r for r in records if r.key() != record.key()]
            records.append(record)
            with results_path.open("a") as fh:
                fh.write(json.dumps(asdict(record)) + "\n")
            n = len(records)
            if n % 10 == 0:
                print(f"  {n} runs written")
        return record

    await asyncio.gather(*(worker(*p) for p in planned))

    # --- automatic retry pass ---------------------------------------------------------------
    # A transient failure (rate limit exhausted, a slow call, a dropped connection) removes a run
    # from one arm only, and the arm that fails most is the slowest one -- which is a bias, not
    # noise.  Retrying errored runs costs a little and removes an asymmetry between methods that
    # would otherwise have to be disclosed as a deviation, as it was in 0.9.1.
    for attempt in range(1, max(0, cfg.retry_failed_runs) + 1):
        failed = [r for r in records if is_failure(r)]
        if not failed:
            break
        index = {(t.id): t for t in tasks}
        by_name = {m.name: m for m in methods}
        again = [
            (index[r.task_id], by_name[r.method], r.condition, r.seed)
            for r in failed
            if r.task_id in index and r.method in by_name
        ]
        if not again:
            break
        print(f"retry pass {attempt}: re-running {len(again)} failed run(s)")
        await asyncio.gather(*(worker(*p) for p in again))
        still = sum(1 for r in records if is_failure(r))
        print(f"  {len(again) - still} recovered; {still} still failing")

    summary = summarise(records)
    summary["config"] = asdict(cfg)
    summary["tasks"] = len(tasks)
    summary["methods"] = [m.name for m in methods]
    errs: dict[str, dict] = {}
    for r in records:
        if is_failure(r):
            e = errs.setdefault(r.method, {"failed": 0, "kinds": {}})
            e["failed"] += 1
            kind = (r.error or "").split(":")[0]
            e["kinds"][kind] = e["kinds"].get(kind, 0) + 1
    summary["failures_by_method"] = errs
    # Secondary references (declared in PROTOCOL_V2 addendum, 0.9.3): the convergence-gated methods
    # are compared against the baselines in their own right; H4 itself stays referenced to "cpo".
    present = {m.name for m in methods}
    summary["selecting_methods"] = sorted(
        m.name for m in methods if getattr(m, "selects_candidates", False)
    )
    summary["comparisons_by_reference"] = {
        ref: summarise(records, reference=ref)["comparisons"]
        for ref in ("cpo_adaptive", "cpo_gated_judge")
        if ref in present
    }
    summary["tokens_spent"] = spent["tokens"]
    summary["runs_not_launched_by_token_cap"] = stopped["by_cap"]
    summary["fingerprint"] = fingerprint["digest"]
    summary["failure_asymmetry_warning"] = (
        "failures are not evenly spread across methods; the arm with more failures has lost more "
        "candidates and its numbers are not comparable to the others"
        if errs and max(v["failed"] for v in errs.values()) >= 3 and len(errs) < len(methods)
        else None
    )
    (out / "summary.json").write_text(json.dumps(summary, indent=2, default=str))

    rubric = [r for r in records if r.correct is None and not r.error and (r.answer_full or r.answer_excerpt)]
    if rubric:
        sheet = [
            {
                "task_id": r.task_id,
                "run": r.key(),
                "answer": r.answer_full or r.answer_excerpt,
                "rating": None,
            }
            for r in sorted(rubric, key=lambda r: (r.task_id, r.key()))
        ]
        (out / "rating_sheet.json").write_text(json.dumps(sheet, indent=2))
    return summary
