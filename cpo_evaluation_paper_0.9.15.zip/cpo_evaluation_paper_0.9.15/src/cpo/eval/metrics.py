"""Outcome measures and their uncertainty.

Primary outcomes (manuscript section 7):
  quality                     - fraction of graded tasks answered correctly
  history_locked_convergence  - fraction of runs whose final answer a blind
                                re-query of the same specialists does not support

The blind-support test is applied identically to every method, including the
baselines, so the comparison is not rigged in CPO's favour: whatever the method
produced, the same specialists are asked the task again with no memory of the
run, and the final answer is compared with the fresh pool's consensus.

Intervals are Wilson score intervals for proportions and BCa-free percentile
bootstrap for differences; both are deterministic given the seed.
"""

from __future__ import annotations

import math
import random
from collections.abc import Sequence
from dataclasses import dataclass, field

Z95 = 1.959963984540054


def wilson(successes: int, trials: int, z: float = Z95) -> tuple[float, float]:
    if trials <= 0:
        return (0.0, 1.0)
    p = successes / trials
    d = 1 + z * z / trials
    centre = (p + z * z / (2 * trials)) / d
    half = z * math.sqrt(p * (1 - p) / trials + z * z / (4 * trials * trials)) / d
    return (max(0.0, centre - half), min(1.0, centre + half))


def bootstrap_difference(
    a: Sequence[float], b: Sequence[float], *, rounds: int = 10_000, seed: int = 0
) -> tuple[float, tuple[float, float]]:
    """Percentile bootstrap for mean(a) - mean(b) on paired-by-task samples.

    ``a`` and ``b`` must be aligned per task; resampling is over tasks, which is
    the unit of independence.
    """
    if len(a) != len(b):
        raise ValueError("paired samples required")
    n = len(a)
    if n == 0:
        return (0.0, (0.0, 0.0))
    observed = sum(a) / n - sum(b) / n
    rng = random.Random(seed)  # nosec B311 - resampling, not security
    diffs = []
    for _ in range(rounds):
        idx = [rng.randrange(n) for _ in range(n)]
        diffs.append(sum(a[i] for i in idx) / n - sum(b[i] for i in idx) / n)
    diffs.sort()
    lo = diffs[int(0.025 * rounds)]
    hi = diffs[min(rounds - 1, int(0.975 * rounds))]
    return (observed, (lo, hi))


@dataclass
class MethodOutcome:
    method: str
    runs: int = 0
    graded: int = 0
    correct: int = 0
    blind_tested: int = 0
    history_locked: int = 0
    calls: int = 0
    prompt_tokens: int = 0
    completion_tokens: int = 0
    cycles: int = 0
    failures: int = 0
    _correct_by_task: dict[str, list[float]] = field(default_factory=dict)
    _locked_by_task: dict[str, list[float]] = field(default_factory=dict)

    def add_correct(self, task_id: str, value: bool) -> None:
        self.graded += 1
        self.correct += int(value)
        self._correct_by_task.setdefault(task_id, []).append(float(value))

    def add_locked(self, task_id: str, locked: bool) -> None:
        self.blind_tested += 1
        self.history_locked += int(locked)
        self._locked_by_task.setdefault(task_id, []).append(float(locked))

    @property
    def per_task_correct(self) -> dict[str, float]:
        """Per-task mean over seeds; the task is the unit of independence for the bootstrap."""
        return {t: sum(v) / len(v) for t, v in self._correct_by_task.items()}

    @property
    def per_task_locked(self) -> dict[str, float]:
        return {t: sum(v) / len(v) for t, v in self._locked_by_task.items()}

    @property
    def completed(self) -> int:
        return self.runs - self.failures

    @property
    def quality(self) -> float | None:
        return self.correct / self.graded if self.graded else None

    @property
    def lock_rate(self) -> float | None:
        return self.history_locked / self.blind_tested if self.blind_tested else None

    # --- lock decomposition (secondary outcome, declared in 0.9.3) ------------------------
    # The primary lock metric -- the answer is not reproduced by a blind re-draw -- measures
    # reproducibility, and a correct *minority* answer is by construction rarely reproduced.  On
    # the offline replay a perfect judge raised accuracy 0.651 -> 0.839 while raising the lock
    # rate 0.177 -> 0.221, flagging 23.7% of its correct answers.  So the lock rate is split into
    # the harmful half (wrong AND unsupported: converged on something the task does not support)
    # and the false-alarm half (correct but unsupported).
    both_known: int = 0
    wrong_unsupported: int = 0
    correct_unsupported: int = 0

    def add_lock_decomposition(self, correct: bool, supported: bool) -> None:
        self.both_known += 1
        self.wrong_unsupported += (not correct) and (not supported)
        self.correct_unsupported += correct and (not supported)

    @property
    def lock_decomposition(self) -> dict | None:
        if not self.both_known:
            return None
        return {
            "error_lock_rate": round(self.wrong_unsupported / self.both_known, 4),
            "error_lock_95ci": wilson(self.wrong_unsupported, self.both_known),
            "false_alarm_rate": round(self.correct_unsupported / self.both_known, 4),
            "runs": self.both_known,
        }

    # --- selection quality (Proposition 1's condition p_sel > p) -------------------
    sel_pool: int = 0
    sel_pool_correct: int = 0
    sel_kept: int = 0
    sel_kept_correct: int = 0

    def add_selection(self, q: dict) -> None:
        self.sel_pool += q["pool_candidates"]
        self.sel_pool_correct += q["pool_correct"]
        self.sel_kept += q["selected_candidates"]
        self.sel_kept_correct += q["selected_correct"]

    @property
    def selection_quality(self) -> dict | None:
        """Pooled p and p_sel over every cycle of every run of this method/condition."""
        if not self.sel_pool or not self.sel_kept:
            return None
        p = self.sel_pool_correct / self.sel_pool
        p_sel = self.sel_kept_correct / self.sel_kept
        return {
            "p": round(p, 4),
            "p_sel": round(p_sel, 4),
            "p_sel_minus_p": round(p_sel - p, 4),
            "p_95ci": wilson(self.sel_pool_correct, self.sel_pool),
            "p_sel_95ci": wilson(self.sel_kept_correct, self.sel_kept),
            "pool_candidates": self.sel_pool,
            "selected_candidates": self.sel_kept,
            "selection_informative": p_sel > p,
        }

    def summary(self) -> dict:
        return {
            "method": self.method,
            "runs": self.runs,
            "failures": self.failures,
            "quality": self.quality,
            "quality_95ci": wilson(self.correct, self.graded) if self.graded else None,
            "graded": self.graded,
            "history_locked_convergence": self.lock_rate,
            "history_locked_95ci": wilson(self.history_locked, self.blind_tested)
            if self.blind_tested
            else None,
            "blind_tested": self.blind_tested,
            "mean_calls": self.calls / self.completed if self.completed else None,
            "mean_cycles": self.cycles / self.completed if self.completed else None,
            "mean_prompt_tokens": self.prompt_tokens / self.completed if self.completed else None,
            "mean_completion_tokens": self.completion_tokens / self.completed if self.completed else None,
            "selection_quality": self.selection_quality,
            "lock_decomposition": self.lock_decomposition,
        }
