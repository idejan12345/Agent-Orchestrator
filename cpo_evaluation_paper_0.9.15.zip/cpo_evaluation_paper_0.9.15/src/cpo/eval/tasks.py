"""Task definitions and graders for the evaluation.

A task is a prompt, a grading rule, and enough metadata to stratify results.  The
harness never sees the reference answer until grading, and the grader is frozen
before any run (preregistration, manuscript section 7).

Task files are JSONL, one object per line:

    {"id": "gsm8k-0042", "family": "math", "prompt": "...", "answer": "72",
     "grader": "numeric", "metadata": {"source": "gsm8k", "split": "test"}}

Graders shipped here are deterministic and need no model call:
  exact     - normalised string equality
  numeric   - last number in the answer equals the reference within tolerance
  contains  - reference (or any of a list of alternatives) appears in the answer
  rubric    - NOT graded automatically; the answer is written out for blind human
              rating.  Runs containing rubric tasks produce a rating sheet.
"""

from __future__ import annotations

import json
import re
from collections.abc import Iterator, Sequence
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal

Grader = Literal["exact", "numeric", "contains", "rubric"]
_NUM = re.compile(r"-?\d[\d,]*\.?\d*")


@dataclass(frozen=True)
class Task:
    id: str
    family: str
    prompt: str
    answer: str | list[str] | None = None
    grader: Grader = "exact"
    metadata: dict[str, Any] = field(default_factory=dict)


def load_tasks(path: str | Path) -> list[Task]:
    tasks: list[Task] = []
    seen: set[str] = set()
    for line_no, line in enumerate(Path(path).read_text(encoding="utf-8").splitlines(), 1):
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        try:
            obj = json.loads(line)
        except json.JSONDecodeError as exc:
            raise ValueError(f"{path}:{line_no}: invalid JSON") from exc
        for key in ("id", "family", "prompt"):
            if not obj.get(key):
                raise ValueError(f"{path}:{line_no}: missing '{key}'")
        if obj["id"] in seen:
            raise ValueError(f"{path}:{line_no}: duplicate task id {obj['id']!r}")
        seen.add(obj["id"])
        grader = obj.get("grader", "exact")
        if grader not in ("exact", "numeric", "contains", "rubric"):
            raise ValueError(f"{path}:{line_no}: unknown grader {grader!r}")
        if grader != "rubric" and obj.get("answer") in (None, ""):
            raise ValueError(f"{path}:{line_no}: grader {grader!r} requires an answer")
        tasks.append(
            Task(
                id=obj["id"],
                family=obj["family"],
                prompt=obj["prompt"],
                answer=obj.get("answer"),
                grader=grader,
                metadata=obj.get("metadata", {}),
            )
        )
    if not tasks:
        raise ValueError(f"{path}: no tasks")
    return tasks


def normalise(text: str) -> str:
    return re.sub(r"[^a-z0-9 ]+", " ", text.lower()).strip()


def last_number(text: str) -> float | None:
    matches = _NUM.findall(text.replace(",", ""))
    for token in reversed(matches):
        try:
            return float(token)
        except ValueError:
            continue
    return None


def answer_line(text: str) -> str:
    """The text after the last 'Answer:' marker, or the whole text if there is none."""
    for line in reversed(text.strip().splitlines()):
        if line.lower().lstrip().startswith("answer:"):
            return line.split(":", 1)[1].strip()
    return text.strip()


def grade(task: Task, answer: str) -> bool | None:
    """True/False, or None when the task needs human rating.

    Exact and contains graders look at the final-answer line when the method produced
    one (every method is instructed to), and fall back to the whole text otherwise;
    the numeric grader uses the last number in the final-answer line, then the text.
    """
    if task.grader == "rubric" or task.answer is None:
        return None
    refs: Sequence[str] = task.answer if isinstance(task.answer, list) else [task.answer]
    line = answer_line(answer)
    if task.grader == "exact":
        targets = {normalise(r) for r in refs}
        return normalise(line) in targets or (line == answer.strip() and normalise(answer) in targets)
    if task.grader == "numeric":
        got = last_number(line)
        if got is None:
            got = last_number(answer)
        if got is None:
            return False
        for r in refs:
            want = last_number(str(r))
            if want is not None and abs(got - want) <= 1e-6 * max(1.0, abs(want)):
                return True
        return False
    if task.grader == "contains":
        hay = normalise(line) if line != answer.strip() else normalise(answer)
        return any(normalise(r) in hay for r in refs)
    raise ValueError(f"unknown grader {task.grader!r}")


def answer_key(text: str, grader: str = "exact") -> str:
    """Canonical vote key: answers the grader treats as the same must share one key.

    Voting used to key on ``normalise(answer_line)``, which maps the decimal point and the
    thousands comma to spaces and drops the sign: "2,432.74" and "2432.74" landed in different
    buckets and split the correct answer's votes (28 of 62 replay pools), while "-0.88" and "0.88"
    landed in the same one.  For a numeric grader the key is now the last number in the answer
    line, sign kept and separators removed; otherwise it is the normalised answer line, as before.
    """
    line = answer_line(text)
    if grader == "numeric":
        n = last_number(line)
        if n is None:
            n = last_number(text)
        if n is not None:
            return f"#{n:.12g}"
    return normalise(line)


def answers_equivalent(task: Task, a: str, b: str) -> bool:
    """Do two answers count as the same answer under this task's grader?

    numeric: the last number in each answer line agrees (so '52 pens' == '52');
    exact / contains / rubric: the normalised answer lines agree.  Used by the blind
    support test so that it applies the same notion of sameness as grading does.
    """
    la, lb = answer_line(a), answer_line(b)
    if task.grader == "numeric":
        na, nb = last_number(la), last_number(lb)
        if na is None or nb is None:
            return False
        return abs(na - nb) <= 1e-6 * max(1.0, abs(nb))
    return normalise(la) == normalise(lb)


def stratify(tasks: Sequence[Task]) -> Iterator[tuple[str, list[Task]]]:
    families: dict[str, list[Task]] = {}
    for t in tasks:
        families.setdefault(t.family, []).append(t)
    yield from sorted(families.items())
