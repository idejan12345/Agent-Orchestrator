# Changelog

## 0.9.15 - whole-package review

Reviewed both papers, the package, the scripts, the tests and the docs together. Changes:

**Code**
- `blind_consensus_distance` is now the expected fractional distance from the reference to the
  whole fresh pool's majority under random tie-breaking (a tied position counts one half), via
  the new `sketch.expected_majority_distance`. Before, ties were resolved to 0, which the papers
  described as "no tie rule"; the old value depended on which bits of the reference happened to
  be 1 at tied positions. The strict verdict is unchanged in every cell of H2 (30/30 and 30/30);
  only the distances moved (largest supported 0.135, smallest history-locked 0.229, at theta =
  0.15). Records of the companion evaluation were written under the old rule; no reported number
  uses them.
- Orchestrator: `min_cycles` now governs both fixed-point criteria. An exact repeat of the
  reference before `min_cycles` no longer ends the run as a `fixed_point` marked not converged;
  `converged` now equals `terminal_kind == "fixed_point"`. Default behaviour (`min_cycles = 1`)
  is unchanged; test added.
- Docstrings in `capacity.py`, `reconfirmation.py`, `census.py` and the CLI descriptions now cite
  the theory paper (Definition 1, Theorem 3, H2, Appendix B) instead of the source model's section
  titles and prediction numbers; `docs/PROTOCOL_V2.md`, `PREREGISTRATION.md`, `THEORY_MAPPING.md`
  and the README likewise, and the README documents `strict_status`.

**Theory paper**
- Blind-consensus distance defined as above in the design rules, algorithm step 6 and H2; the H2
  margins updated (0.135 / 0.229).
- Proposition 1: the decision rule is now required to be breadth-monotone and
  correctness-monotone, both defined; the proof of clause (ii) uses the second instead of "any
  sensible D"; the plurality rule of the direct test is noted to satisfy both at the p tested.
- "More than three times its narrow-focus value" (phi = 0.60) corrected to "two to three times
  the rates at phi <= 0.25" (0.155 against 0.045-0.075).
- `pool_exhausted` added to the terminal kinds (step 5, response fields); non-motif fixed points
  "within Hamming distance 4 of a chimera"; theorem-test count 14; a missing paragraph break.

**Evaluation paper**: blind-distance wording and the theorem-test count.

78 tests in the theory bundle, 137 in the package.

## 0.9.14 - theory paper: points from a standalone review, addressed in text only

The paper goes out as is (no new experiments); five text changes answer the review:
- Framing: the abstract and a new introduction paragraph ("What kind of paper this is") state that
  this is theory and controlled tests motivating a preregistered evaluation, and that it does not
  show CPO improves orchestration.
- New paragraph in sec. 3.3, "Why anything should transfer": the theorems do not; their
  qualitative consequences need only a similarity kernel and a position-wise vote, which signatures
  supply, which is why they are classed as empirical hypotheses and tested directly.
- Conclusion: the conditional practical recommendation (no selection toward an uninformative
  reference; reserve it for references worth preserving; test convergence blind).
- Algorithm step 2 marks the binding proxy optional and cites its ablation.
- Limitations: the controlled tests show the mechanisms exist and how they behave in isolation,
  not how often or how strongly they act in undesigned pools.
Points already covered and left unchanged: the capacity cap's benefit is untested (stated in
secs. 2, 3.4, 6.5); Proposition 1 predicts a sign, not a magnitude (Remark, Limitations); the
tolerances are researcher degrees of freedom (Limitations); the information coordinates are
appendix diagnostics only.

## 0.9.13 - fourth proofreading pass

Real errors fixed (all in the theory paper's source):
- Comma splice "...wrong direction for a safety check, The operational verdict..." (from the 0.9.8
  tie-bias edit) -> full stop.
- Body sentence "Table 9: structure replicates." read as a caption -> "The structure of Table 9
  replicates."
- "...floor, Theorem 3 read as a rule." -> colon.
- The section sign extracted as the letter "S" (a side effect of the 0.9.12 workaround that took it
  from the symbol font). Both papers now use T1 Latin Modern (lmodern), vector Type 1 with a Unicode
  map: "§2" extracts as "§2", and every font in both PDFs has a Unicode map. Building the papers now
  needs the lmodern package, which every standard TeX Live installation includes.

Checked and not errors (verified in the rendered PDF, the source, or both):
- Table 3, phi = 0.25 row: every cell is 0 in the typeset table (rendered and inspected) and in
  experiments.json; the reported 1.00 belongs to the phi = 0.50 row and is an extraction misalignment.
- Floor brackets in sec. 6.5 and the Table 10 caption, Table 10's closing parenthesis, "past" (no
  "fast" anywhere), "Figure 2", "lies nearest", the abstract's em-dashes, the Table 9 caption's
  full stop, and reference spacing.

## 0.9.12 - PDFs fixed at the font level; tables captioned on top

A third proofreading report (on 0.9.11) again found "corrupted" pages of repeated 1s, missing table
bodies and broken words. Rendering the pages showed every table and page intact. The cause was the
PDF's text layer: with T1 encoding and no vector T1 fonts installed, body text, tables and appendix
were set in Type 3 bitmap fonts with no Unicode map, so any text-based reader (search, copy-paste,
automated review) got garbage, e.g. "recon\x1crmation", "su\x1eciency".

- Both papers: OT1 Computer Modern (vector Type 1) with glyphtounicode and cmap; the section and
  paragraph signs taken from the vector symbol font instead of the bitmap companion font; figures
  embedded as TrueType (matplotlib pdf.fonttype 42). Result: zero Type 3 fonts in either PDF, and
  the text layer extracts ligatures, dashes, quotes and section signs correctly.
- Code identifiers use the typewriter font's own underscore, so `focus_loop` extracts as such.
- Table captions placed above tables (caption package, tableposition=top) in both papers, which
  removes the apparent Table 7/8 caption mix-up. Both number checkers now locate a table by its
  enclosing table environment, so they are independent of caption placement; both still pass.
- Sec. 6.2 now spells out that every cell of the phi = 0.10 and phi = 0.25 rows of Table 3 is 0
  (the report's reading of a 1.00 there came from a garbled extraction).
- Not changed, because not present in the source or the extracted text: the listed typos, the
  "3 (Capacity)" heading, the bracket notation in Theorem 3, step 3 of the algorithm and sec. 6.5;
  all were artefacts of the bitmap-font text layer.

## 0.9.11 - production fixes from a proofreading report

- **The 0.9.10 PDFs had 95 unresolved references ("??").** The .tex was correct; the shipped PDF
  came from a single LaTeX pass made for proofreading, which overwrote the full build before
  bundling. Fixed by a correct build, and prevented by a new `scripts/check_pdf_refs.py` (pdftotext
  + log scan; rejects any "??" or undefined reference). `make paper` now runs three passes and
  this check before deleting the logs, and `make_paper_bundles.py` refuses to bundle a PDF that
  fails it. The check rejects a deliberate single-pass build (108 "??").
- H1 setup reworded: the motif 0^12 1^12 has order 22/23 = 0.957; the starting references are the
  motif with three random bits flipped (mean order 0.752). The old wording attached 0.75 to the
  motif.
- Definition 1 states that B counts the shared state itself plus B-1 alternatives.
- Author line filled (both papers); the companion citations name the author.
- Figure 1 caption names its data table explicitly.
- Checked and unchanged: the phi <= 0.25 statement of sec. 6.2 is correct (every cell of the
  phi = 0.25 row of Table 3 is 0, including noise share 0.75); no "consistenty" exists in the
  bibliography; all twelve tables and both figures are present; the reported garbling, split
  hyphenations and broken words were artefacts of the reviewer's text extraction.

## 0.9.10 - checked against the source manuscript

The source (D. Stojkovic, "A model for consciousness from binary sequences: you are the ordering
that the world must have to hold you", Sept 2026) was read against the theory paper.

- **Capacity definitions differ; the formulas agree.** The source's count is the number of
  interfering ontic amplitudes in the spin formalism of Powers et al. (PRA 111, 012217, 2025),
  1 + min(j, g) with j = N/2, g = (n-N)/2. Definition 1 here counts configurations held apart by
  disjoint differences. The two agree exactly when N and n-N are even; otherwise Theorem 3 gives the
  integer part. The source applies its count to bundling through a bridge it says it cannot derive
  (its sec. 11.4); Theorem 3 derives the bundling band and ceiling directly for its own notion,
  which is the sense CPO uses. The paper now says this in place of the "may not coincide"
  disclaimer; Powers et al. 2025 is cited.
- **Scaling paragraph corrected.** It had said the source's scaling claims were reproduced and
  that the density-0.30 rise was "not discussed by the source". Both overstated agreement: our
  non-motif rates are lower than the source's at small n (0.28 vs 0.44 at n = 12) and far lower in
  the lawless limit (0.165 of all runs, 0.53 of fixed points, vs 0.91-1.00), and the source's sweep
  reports < 0.05 for densities >= 0.15 where we find 0.095 at 0.30. Reported as discrepancies in
  rates, with the qualitative structure replicating.
- **Plane caption** now separates the source's generator sizes (4e5 bits, 2e5 offsets) from ours
  (2e5, 1e5).
- **Citation corrected** in both papers, README, MIGRATION notes and a module docstring: the source
  had been cited under a wrong working title.
- Every other number attributed to the source (census, chimera distances, archetype table,
  selection law, Hamming theorem, reproduction protocol) was checked and agrees.

## 0.9.9 - the capacity theorem is proved; the theory paper is self-contained

- Theorem 3 (capacity) is now a theorem of the paper, not an imported statement. The notion it is
  about is made explicit (Definition 1: a configuration of occupancy N holds B alternatives apart if
  B-1 other configurations of occupancy N differ from it on pairwise disjoint sets of at least four
  positions, i.e. by more than one elementary exchange each, on positions of their own). Theorem:
  this is possible iff 2(B-1) <= N <= n-2(B-1); hence floor(1 + (n/2) min(nu, 1-nu)) alternatives,
  B_max = 1 + floor(n/4) at half filling. Proof in Appendix A (necessity by counting cleared and
  filled positions, sufficiency by construction). The paper says plainly that the definition is the
  one under which the result is proved here and may not coincide with the source's.
- New test `test_capacity_theorem_by_exhaustive_search`: every family satisfying the definition is
  enumerated for n <= 8 and all occupancies; the maximum matches the theorem and the shipped
  `holdable_alternatives`, `admissible_band` and `max_bundle`. (Checked separately up to n = 10.)
- Every passage that called the result imported or unproved is revised; the register section is
  again described as self-contained. 20 pages. 136 tests (77 in the theory bundle).

## 0.9.8 - theory paper revised in response to a referee-style report

**Corrected: Proposition 1.** Its first clause assumed only that similarity to the reference is
independent of *correctness*; the proof needs it independent of each candidate's *answer*. A new
direct test (E7) showed the difference matters: when candidates giving the same answer resemble one
another, selection toward an uninformative reference has p_sel = p yet does worse than k random
candidates (by 0.03-0.07), because it captures one answer's cluster. The proposition is restated in
three clauses with the correct hypothesis and proof, and "cluster capture" is named and measured as
an effect the proposition does not cover. The evaluation paper restates the proposition and is
updated identically, with one sentence connecting cluster capture to its marker-weighted signer.

**New experiments** (`paper_experiments.py`; all earlier results regenerate byte-identically)
- E7, Proposition 1 on controlled pools: three references (uninformative, partially correct draft,
  wrong incumbent) at three values of p, and the reference's informativeness swept. Every clause
  holds; p_sel > p is shown to be necessary but not sufficient (delta = 0.40).
- E3 now also reports a strict reconfirmation verdict (tie-retaining test AND unbiased
  blind-consensus distance within theta): 30/30 supported accepted, 30/30 history-locked rejected at
  eps >= 0.06, against 25/30 for the tie-retaining verdict; the margin on supported pools is narrow
  (0.145 against theta = 0.15) and is reported.
- E8, binding-proxy ablation: E2b, E3 and E4 with b = 0 give identical outcomes.

**Package.** `ReconfirmationReport.strict_status` (new, additive): the recommended verdict. `status`
is unchanged, so the companion evaluation's records and protocol are unaffected. Test added.

**Theory paper**
- Title now says "Register Theorems, an Analogical Transfer to Text, and Controlled Tests".
- Abstract, introduction and contributions separate the two proved register results from simulation
  findings (fixed-point structure) and from the capacity rule, now an "Imported statement" (not a
  theorem), unproved here and used only as a policy. "Self-contained" removed.
- SimHash: distance tracks lexical overlap in expectation, not monotonically.
- The two registers (256-bit signatures vs. the n_ws = 24-slot workspace model) are distinguished;
  the reference carried between cycles is stated to be the consensus signature while specialists
  read the medoid's text.
- Strict reconfirmation verdict recommended; binding proxy demoted (definition moved to the
  configuration appendix, ablation cited).
- "Widening never lowers the spurious rate" restated as "not beyond sampling variation".
- H2's small sample stated; limitations rewritten; related work contrasts with self-consistency and
  ensemble selection; the remark notes a non-monotone judge can reverse clause (i)'s sign.
- Two new subsections (6.6, 6.7), two new tables. 19 pages.

**Checks.** `check_theory_numbers.py` now covers the two new tables, the strict-verdict column and
the ablation's identity claim (189 numbers); planted errors in each are caught. 135 tests (76 in the
theory bundle).

## 0.9.7 — two papers: theory and evaluation

The single manuscript is split into two, each with the code it needs.

**Theory paper** (`paper/theory/cpo_theory.tex`, 16 pp). The select–consensus map on binary
registers and the proofs it uses; the transfer to text, every result classified by what survives;
the algorithm; Proposition 1 (when selection toward a reference can help a decision); controlled
tests of H1–H3 and the noise and breadth sweeps; the source model's census reproduced. It makes no
claim about language-model tasks. Its scope paragraph and discussion state, in one place each, what
the companion evaluation found on single-answer arithmetic and that the drafting regime, where the
theory predicts an advantage, is untested for reasons of cost. New abstract, introduction,
discussion (with a limitations paragraph for the controlled tests) and conclusion; every reference
to the live run is now a citation of the companion paper.

**Evaluation paper** (`paper/evaluation/cpo_evaluation.tex`, 17 pp). The former manuscript's live
evaluation, decomposition, replay, boundary, discussion, open experiment and deviations, unchanged in
substance and in every number, with a short section describing the orchestrator and citing the
theory paper for its theorems, transfer and controlled tests. Proposition 1 is restated with its
proof so the paper stands alone.

**Code**
- `paper/theory/` holds the theory paper, `experiments.json` and the figures (moved from `paper/`);
  `paper_experiments.py`, `paper_figures.py`, `fill_poolshape.py` and `check_paper_numbers.py` point
  at the new locations. `make paper` builds both; `make figures` added.
- New `scripts/check_theory_numbers.py`: every value in the six experiment tables of the theory paper
  (121 numbers with version and test count) against `experiments.json`; regression test
  `tests/test_paper_theory.py` plants an error and requires it to be caught. `make papercheck` now
  runs both checkers. `experiments.json` was regenerated from its fixed seeds and is byte-identical.
- New `scripts/make_paper_bundles.py`: one release bundle per paper. The theory bundle is the package
  without `cpo.eval`, the tests without `test_eval.py` (75), the experiment, figure and check
  scripts, and the paper; it runs its own tests, number check and LaTeX build. The evaluation bundle
  is the whole SDK and carries both papers.
- 134 tests (1 new).

## 0.9.6 — paper revision: the output ceiling, and what was not tested and why

Prompted by the question whether the live results rest on flawed runs. They were checked against the
released records before the paper was touched.

**Finding.** The runs behind the live and decomposition tables are not the failed runs. The 0.9.1
timeout bug was corrected and every CPO-family row re-run then; in the released records no run in any
arm failed and no specialist candidate was dropped. One defect had not been disclosed: every call ran
under the then-default 2048-token output ceiling with truncation undetected. Bounded from the records
(per-call texts were not stored): 53/960 self-consistency draws (5.5%) never reached an answer line,
25 of them on three tasks (two digit-sum enumerations, one schedule computation); CPO's calls were no longer than the baselines' (432 vs
432-497 completion tokens per call). Without those three tasks every gap moves by at most 0.07, CPO
still equals self-consistency within 0.03 and still trails best-of-n by 0.11 in both conditions. The
negative result on single-answer arithmetic stands; it is not an artefact of the ceiling.

**Paper**
- Deviations appendix: new "Output ceiling" item with the bound above and Table `tab:truncation`
  (sensitivity of the live comparison); the timeout item now states that the released records contain
  no failed runs or dropped candidates. The guard-rails paragraph cites both instances.
- The regime in which the theory predicts the mechanism's advantage (drafting, planning, synthesis;
  Claim B) is now stated as untested *because of cost*, not because a test failed, in the abstract,
  the introduction's scope paragraph and Claim A/B passage, the H4 paragraph, the boundary section,
  the Discussion, the open-experiment section (with order-of-magnitude cost: pilot ~10^3 USD, full
  grid ~10^4, scaled from this paper's measured per-run tokens) and the Conclusion. The abstract now
  says the two convergence-gated methods are preregistered for the next run.
- No result was changed and none was removed.

**Code**
- New `scripts/truncation_sensitivity.py` -> `eval/replay/truncation_sensitivity.json`. Recorded tokens
  include the three blind-test draws while the call count does not, so per-call tokens divide by
  calls + 3.
- `check_paper_numbers.py` verifies the new table and the draw counts (113 numbers; row floor 4 for
  the new table; caught two planted errors). `make papercheck` regenerates the sensitivity file first.
- 133 tests (1 new: the audit reproduces the released figures).

## 0.9.5 — audit pass: the paper's numbers, its evidence, and the next run's path

A full audit of paper against data and code. Every results table was recomputed from its source;
the audit is now a shipped gate so it does not have to be repeated by hand.

**Serious**
- **The paper's evidence was gitignored.** `.gitignore` excluded all of `eval/runs/`, which holds the
  two run-record sets behind the live-results and decomposition tables, the replay's input and the
  number checker's input. Archives built from the working directory included them by accident; a
  release built from git (e.g. a GitHub-to-Zenodo DOI) would have shipped the paper without its
  data. Now `eval/runs/*` is ignored except the two released runs and the README, verified with a
  real `git init`; only caches remain ignored.
- **Mixed-family task files failed the preflight.** Discrete-only methods record "not_applicable"
  on rubric tasks as an `error`; the 0.9.3 guard-rails counted those as failures, retried them, and
  failed the preflight ("8 failed runs" on a 4-task mixed file) — which would have blocked Stage 2
  of PROTOCOL_V2 outright. New `is_failure` / `is_not_applicable`: not-applicable rows are neither
  cells, failures, retries nor re-planned on resume; `summary.json` reports `not_applicable_runs`.
- **Following the runbook could overwrite provenance.** Its calibration commands wrote to names that
  collide with the paper's frozen task file. `gen_hard_math.py` and `calibrate_tasks.py` now refuse
  to overwrite an existing output without `--force`; the runbook's next-run commands use the frozen
  `main_math_calibrated_v2.jsonl`, and any new task set is written as `_v3`.

**Paper corrections** (numbers checked against the records)
- "History locking raised lock rates by at most 0.05 for any method" was false: the judged writer
  rose 0.10. Now stated, with a pointer to where that rise is discussed.
- Decomposition table: 10.9 -> 11.0 and 8.4 -> 8.5 calls (exact means 10.95 and 8.45). The caption
  called the 3x4 row "the configuration of" the live table; it has that pool size but spends the
  reconfirmation round's calls on a fourth cycle. The replay table's CPO row is relabelled likewise.
- The exploratory replay figures had come from ad-hoc code with a different seed. The shipped
  `offline_replay.py` now regenerates every one of them (under `exploratory` in its JSON); two
  values moved in the third decimal (23.6% -> 23.7%, 0.176 -> 0.177), logged as Erratum 2.
- Discussion: "What has not been shown — that CPO helps anywhere" now says *on a live model*; both
  the Discussion and the Conclusion now carry the replay's constructive result; Claim A's support
  sentence cites the replay.
- Zero overfull lines (an `\emergencystretch` allowance; the focus-map definition displayed).

**Docs and code hygiene**
- The runbook's "what each outcome means for the paper" predated any result; rewritten for the
  next run (H6, H7, Stage 1). Stale paths fixed (`eval/PREREGISTRATION.md` -> `docs/...`, the
  pre-`_v2` task file name). Docstrings of `paper_experiments.py` cited anchors that do not exist.
- `eval/runs/README.md` said "gitignored"; it now documents the two released runs and what reads
  them.

**New: `scripts/check_paper_numbers.py`** (`make papercheck`; gate `paper_numbers_match_data`).
Recomputes 96 numbers in the live-results, decomposition and replay tables from the records, plus
the version and the test count, and fails on any difference. Its first version silently skipped
whole tables — a leading `\midrule` defeated the row parser — so it now strips booktabs rules and
enforces a row-count floor; it caught two deliberately planted errors in testing, and the stale test
count on its own during this release.

132 tests (3 new: not-applicable rows, checker parsing, overwrite guard).

## 0.9.4 — what convergence is good for

Asked to make CPO beat the baselines, the right first move was not to tune it on the 40 tasks
already used (that would be fitting the test set) but to test design ideas on data already paid for.

**Offline replay** (`scripts/offline_replay.py`; rules and predictions in
`docs/OFFLINE_REPLAY_PREREG.md`, hashed before running). The self-consistency rows store all 12
real answers per task, so any rule using at most 12 draws can be evaluated exactly at zero cost.
- First execution invalid and discarded: the built-in grader check agreed on only 60/80 pools,
  because the stored keys are a lossy normalisation (decimal point and comma become spaces, sign
  dropped). Grader replaced by numeric reconstruction; the 9 negative-answer tasks excluded (sign
  unrecoverable); the check made a hard gate (passes 58/58). Recorded as Amendment 1, not hidden.
- All four predictions held. CPO's aggregation alone, with no workspace conditioning, is 0.029
  below plurality and locks 0.052 more often (error retention reproduced). The fixed-point criterion
  as a stopping rule matches plurality-of-9 at 6.3 draws. Acting on a failed reconfirmation
  recovers most of CPO's loss. No consensus rule beats plurality; Oracle-9 is 0.968.
- Exploratory: non-converged runs hold 56.5% of errors and contain the right answer 97.5% of the
  time; unanimous-but-wrong runs are shared systematic errors no verifier can fix.

**New methods** (in `default_methods`, preregistered as H6/H7 in `PROTOCOL_V2.md`, not yet run live)
- `cpo_adaptive`: blind batches of 3, stop at a reconfirmed fixed point, plurality answer. A test
  proves it takes the same number of calls and returns the same answer as the replayed rule.
- `cpo_gated_judge`: the same with one call reserved; if the pool does not converge, a judge reads
  the whole pool with best-of-n's exact instruction (now shared via `judge_prompt()`).

**Defects found and fixed**
- **Baseline vote key** (self-consistency, debate): votes keyed on the lossy normalisation split one
  value across buckets ("2,432.74" vs "2432.74"; 28/62 replay pools) and merged opposite signs. New
  `answer_key()` is value-aware and sign-preserving for numeric graders. This can only make those
  baselines stronger, so the paper's live comparison was conservative toward them.
- **Grading context was a shared global.** `set_discrete` mutated module state read by concurrently
  running asyncio tasks; in a mixed rubric/discrete task file one run could flip it under another
  (best-of-n would use the wrong judge prompt). Now a `ContextVar` (`set_grader` / `current_grader`);
  `set_discrete` kept as a shim. A test proves isolation.
- **Two answer-line parsers disagreed**: `final_answer_line` missed an indented "Answer:" line that
  the grader found. Now one parser.
- **0.9.3 paper stated 116 tests; the package had 118.** Now 129, matching.
- Preflight's p_sel check guessed selecting methods from the `cpo` name prefix and failed on the two
  new methods, which keep the whole pool by design. Methods now declare `selects_candidates`; the
  summary records `selecting_methods`; the check uses it, and a test requires the declaration.
- Stale method counts: CLI help said "default is all eight" (there are eleven); `--profile minimal`
  said "6 methods" while its list held 7. Minimal now runs 9 — it adds `cpo_adaptive` and
  `cpo_gated_judge`, the most promising arms for the next run. Runbook and docstring updated.

**Measurement**
- The preregistered lock metric penalises correct dissent: on replay, a perfect gated judge raises
  accuracy 0.651 -> 0.839 *and* the lock rate 0.177 -> 0.221, flagging 23.7% of its correct
  answers. New declared secondary outcome `lock_decomposition`: `error_lock_rate` (wrong AND
  unsupported) and `false_alarm_rate` (correct but unsupported). H4's primary metric is unchanged.
- `summary.json` gains `comparisons_by_reference` for the two new methods.

**Paper**: new section "Offline replay: what convergence is good for", with the amendment disclosed
and every exploratory number labelled; a deviation item for the baseline vote key; a limitation on
the lock outcome; the open experiment carries H6/H7; one abstract sentence and one contribution
item. Docs now cite tables by name rather than number (four stale numbers fixed; erratum appended to
the hashed preregistration). 129 tests (11 new).

## 0.9.3 — ready for an authorized-provider run

The theme of this release is limits that fail *silently*. A timeout, an output-token ceiling or a
size cap does not stop a run; it removes a candidate from the pool or returns a partial answer as
if it were complete, and the arm that is slowest or most verbose loses the most. The 0.9.1
timeout failure (43/240 CPO runs) was one instance. 0.9.3 treats the whole class.

**Silent failures closed**
- **Output truncation is detected.** `max_output_tokens` defaulted to 2048, no eval script raised
  it, and `stop_reason` was inspected only when the text came back empty — so a long answer cut off
  at the ceiling was returned as complete and graded. New `TruncatedOutput` (a `ProviderError`):
  the Anthropic adapter raises on `stop_reason == "max_tokens"`, and `raise_if_truncated` does the
  same for the OpenAI and Azure Responses adapters on `status: incomplete`. `ProviderResult` now
  carries `stop_reason`.
- **Limits are checked against each other.** `per_run_timeout_s` was a flat 300 s while a 12-call
  run at 180 s per call needs ~2,800 s. It now derives from budget x call timeout + retry backoff
  (x1.25 headroom), and `preflight_limits()` refuses a sweep whose limits are jointly incompatible
  (run timeout below worst case, candidate cap below what the output ceiling can emit, call timeout
  under 30 s, zero blind draws). `run_evaluation` exits before spending if they are.
- **Ceilings raised so slow models can be configured.** Provider `timeout_s` 300 → 1800 s,
  `max_output_tokens` 16k → 64k; orchestrator specialist/consumer timeouts 120 → 1800 s, request
  600 → 7200 s. Production defaults unchanged; the eval sets 180 s per call and 8192 output tokens.
- **Over-long candidates.** `max_candidate_chars` (12k) *drops* a candidate rather than clipping it;
  the eval now uses 120k and the preflight rejects values below the output ceiling's reach.
- **No arm on different limits.** `CPOMethod` no longer hard-codes 120/60/600; every CPO arm takes
  its limits from the checked `HarnessConfig`. Adapter limits are passed from the same config.
- **Failures can't quietly become between-arm bias.** Automatic re-run pass for errored runs
  (`--retry-failed`, default 1); `summary.json` gains `failures_by_method` and
  `failure_asymmetry_warning`.

**Fail early, not late**
- **Provider ping.** One minimal call before a real sweep: a wrong key, model name or exhausted
  quota costs one call and a clear message. Verified against the live API with an invalid key —
  it fails at the ping with the provider's 401 message and writes nothing.
- **Fingerprinted resume.** `run_fingerprint.json` per output directory; resuming under a different
  budget, blind test, signature, output ceiling or model is refused with the changed fields named.
  Adding seeds, tasks, methods or conditions is allowed (new record keys only).
- **Hard token cap.** `--max-total-tokens` stops launching runs at the cap; rerun to resume.
- **Spend projection.** Projected tokens, optional dollar estimate (`--price-in/--price-out`) and
  worst-case wall clock printed before the spend prompt.
- **`make preflight TASKS=<file>`** (`scripts/preflight.py`): tests → limit check for your budget →
  can this task file test the hypothesis → mock dry run of the exact command → assertions on its
  summary (no failed runs, `H4_status != not_tested`, `p_sel` on every CPO cell). Writes
  `release/evidence/preflight.json`; new `evaluation_preflight` gate in `release_gate.py`. On a
  rubric-only file it fails three checks and names why — the 0.9.1 drafting mistake, caught free.

**Instrumentation**
- **p_sel implemented** (PROTOCOL_V2 Stage 1's primary outcome). Behind a new config flag
  `trace_candidate_texts` (off in production, on in eval), cycle traces carry pool and selected
  texts; `measure_selection_quality()` grades them with the task's own grader; `summarise()`
  aggregates `p`, `p_sel`, `p_sel_minus_p`, Wilson intervals and `selection_informative` per
  method and condition. Texts are dropped from the record once measured.
- `answer_full` is now persisted for every task, not only rubric ones, so discrete runs can be
  re-graded or audited without re-running.

**Scripts**
- `rate_with_model.py`: the rating sheet was written only after *all* ratings finished, so an
  interruption lost every paid rating. Now checkpointed every 25 and in `finally`, atomically.
  Scores recovered by the loose trailing-digit regex are marked `rating_parse: fallback` and
  counted, so they can be audited or excluded.
- `calibrate_tasks.py`: same flaw — probes now checkpoint to `<out>.probes_partial.json`; a resume
  must match model, provider, probe count and candidate file, and the report discloses
  `resumed_from_checkpoint`. Output and timeout limits raised to match the eval, since a probe that
  times out would otherwise be scored as *unknown* and leave an easy task out of the set.

**Consistency fixes**
- `HarnessConfig().budget` was 9 while the CLI, the protocol and the paper use 12; now 12.
- Paper cited `tests/test_information_and_census.py` for the capacity theorem; the test is
  `test_capacity_theorem_numbers_at_n24` in `tests/test_register_theorems.py`. Fixed; test count
  109 → 118; version 0.9.3; Appendix E gains an "Evaluation guard-rails" paragraph; §9 notes that
  p_sel is now instrumented. All thirteen defaults the paper states were checked against
  `CPOConfig` and match.

**Release hygiene**
- Root cause of the stray `cpo-traces.jsonl` in the 0.9.2 archive: `cpo.api` defaults its trace
  path to the current directory, so running the API tests from the repo root wrote a live trace log
  into the source tree. New `tests/conftest.py` points `CPO_TRACE_PATH` at a temp dir; the suite
  now leaves the tree clean. `check_clean_tree.py` also flags calibration checkpoints and
  half-written temp files.
- 118 tests (9 new: limit preflight x3, truncation x2, p_sel x2, fingerprinted resume, token cap).

## 0.9.2 — evaluation guard-rails after the drafting run

- `summarise()`: the preregistered decision now carries `H4_status` ∈ {`supported`, `not_supported`,
  `not_tested`} and, when no CPO-vs-baseline lock comparison exists, a `reason` saying why. Previously
  a run on rubric-only tasks reported `H4_supported: false` with `comparisons_checked: 0`, which reads
  as a refutation but is an untested hypothesis (the lock metric is undefined on rubric tasks by design)
- `run_evaluation.py`: pre-flight task-set summary (discrete vs rubric graders, families); a loud
  warning and a confirmation prompt when the file is rubric-only and so cannot test H4; the
  `not_tested` reason is printed after the run
- `run_drafting.py`: states on start that it measures quality only and does not test H4
- runbook: verify-before-spend sequence (pytest → mock dry run of the exact command → `--limit 3`
  smoke → grid) and a "which script tests what" note
- tests: `not_tested` vs `not_supported` labelling; task-set pre-flight; rating sheet carries the
  full answer (regression for rating sheets built from the 400-character excerpt in an older copy)
- paper: `paper/` replaced by the revised manuscript (same data). Revision after two internal
  reviews: recentred on the question *when does reference-relative selection help or hurt*; the
  null result on H4 foregrounded in title/abstract; a self-contained §2 with proofs of the Hamming
  theorem and selection law; Proposition 1 (effective-pool reduction / error retention); binding
  proxy, weight and occupancy defined explicitly; W/M* and the security appendix moved out of the
  main text; reproduction of the source computations moved to an appendix; tables fitted to the
  text width; H5 language made conservative; limitations expanded (power, model-specific
  calibration, representation, synthetic H2); §9 states the open experiment
- new experiment **E6** (`paper_experiments.py`, `paper/experiments.json`): spurious fixed-point
  rate and convergence against selection breadth `phi` at the census parameters. Widening the
  focus does not lower the spurious rate anywhere from `phi = 0.02` to `0.25`; beyond that it
  raises it (0.155 at 0.60, 0.615 at 0.80) and limit cycles appear. Reported as §6.3 of the paper;
  it also reproduces the source manuscript's statement that the fixed-point rate falls at the
  extremes of selection breadth
- paper, third review pass: the decomposition no longer claims the **signature** is neutral — it
  was held fixed in every configuration and its preregistered ablation was not run, and the judged
  writer does not stand in for it since selection still scores by resonance to the marker-weighted
  signature. A new limitation states what the 8x `Answer:` weighting likely does on single-answer
  tasks (resonance ≈ answer agreement, so selection ≈ keeping candidates that agree with the
  incumbent — error retention in its most direct form, and why CPO tracks self-consistency so
  closely), and bounds Claim A accordingly
- paper: the difficulty-calibration rule is now analysed as an interaction rather than only
  disclosed — keeping tasks the model gets wrong lowers `p`, which makes wrong incumbents more
  common and raises the value of breadth to the baselines, so both effects **enlarge** the measured
  deficit; the result is stated as an upper estimate, with the bias toward Claim A
- paper: the reconfirmation tie rule (ties retain the tested state's bit) is now given as a design
  property of the test, biased toward acceptance, in §4.2 rather than only in the §6.4 error
  analysis; the 5/30 false acceptances are labelled as its measured cost
- paper: `epsilon = 0.06` is named a researcher degree of freedom, chosen against this signer's
  paraphrase noise floor and not transferable without repeating the sweep
- paper: the representation ablation is added to §9 alongside the drafting pilot as the cheaper of
  the two, since it bears on Claim A rather than Claim B; abstract cut from 539 to 355 words
- release: `scripts/check_clean_tree.py` (`make cleantree`) fails when runtime artifacts are
  present in the tree — `.ruff_cache/`, `cpo-traces.jsonl` and its lock file shipped in the 0.9.2
  archive because the release was built by archiving the working directory rather than by
  `git archive`, though `.gitignore` already excluded them. Wired into `release_gate.py` as the
  `release_tree_clean` gate; evidence in `release/evidence/clean_tree.json`
- paper: the two central statements are now labelled and separated — **Claim A (tested)** for the
  single-answer regime and **Claim B (conjectured, not tested)** for drafting — in the
  introduction, the boundary section and the conclusion; "definite boundary" language replaced by
  "clear boundary in the tested regime"; an explicit scope paragraph states that no empirical claim
  is made about drafting, planning, synthesis or coding; register-model results are qualified as
  such in the abstract; Proposition 1's four assumptions are listed, breadth-monotonicity is
  explicitly not asserted for learned judges (the judged writer becomes a robustness check), and
  the direction in which each assumption fails live is stated; the remaining source-manuscript
  paragraph moved from the discussion into the reproduction appendix
- `docs/PROTOCOL_V2.md`: adds **Stage 1**, a small sign-reversal pilot (3 models, 50–100 drafting
  tasks, pool 3/6/12, selection on/off, reconfirmation on/off, 3 seeds) measuring whether
  `p_sel > p` appears on drafting after `p_sel ≈ p` on arithmetic, with the arithmetic anchor rerun
  in the same session; the full grid becomes Stage 2 and is worth funding only if Stage 1 shows the
  reversal
- `docs/PROTOCOL_V2.md`: `phi` is now the swept principal factor (0.10/0.25/0.50/1.0) crossed with
  pool size and noise share, with four predictions and two extra falsifiers recorded in advance;
  notes that `phi` is inert below `k_min` on a pool of 3
- `docs/PROTOCOL_V2.md`: preregistration of that experiment (frozen ~1,000-task benchmark
  calibrated on a non-evaluated model, task-family × selection factorial, drafting-family lock
  outcome via `blind_distance > theta`, `p_sel` measurement, seeded-error history locking)
- README: leads with the dynamical system; the source manuscript is mentioned once, neutrally

## 0.9.1 — Windows compatibility and first live-run fixes

- Anthropic adapter: when a model answers HTTP 400 "`temperature` is deprecated for this model",
  the parameter is dropped, remembered, and the request retried once at the provider default
  (found on the first live pilot with claude-sonnet-5; regression tests added)
- evaluation scripts no longer send `temperature` to Anthropic models
- `run_pilot.py`: pre-flight generation before spending; key prefix/length printed; warning when
  `--api-key` differs from the environment key; smoke test and pilot use the same key
- provider errors now include the API's message text (sanitised, no credentials)
- provider timeouts raised (60 s request, 10 s connect) for slower models
- task file is pure ASCII; every `read_text` specifies UTF-8 (Windows cp1252 crash)
- resume retries errored runs instead of skipping them; dry run writes to a temp folder
- blind support test is grader-aware (`52 pens` == `52` for numeric tasks); the pilot's 1/12 'locks'
  at quality 1.0 were literal-match false positives
- `gen_hard_math.py` (procedural hard tasks, computed answers) and `calibrate_tasks.py`
  (rule-based difficulty calibration with a recorded probe log) for families at ceiling
- provider retries: 6 attempts, exponential backoff with jitter capped at 30 s, Retry-After honoured,
  429/529 included (the first calibration run was throttled and its output was invalid)
- calibration: a failed probe is unknown, not wrong; tasks with any failed probe are excluded; errors
  reported; defaults lowered to concurrency 2 / in-flight 3
- `run_evaluation.py --profile minimal`: 6 methods, clean + history_locking, one seed; the cheapest
  configuration that still tests H4 and the central H5 claim (documented trade-offs in the runbook)
- `gen_hard_math.py`: eight generators targeting language-model error modes (long rounded ledgers,
  inclusion-exclusion, recurrences, digit enumeration, calendar counting, tiered pricing, expected value,
  two-stage rounding), sampled 3x more often than the arithmetic ones; `candidates_math_v2.jsonl` (300)
- `calibrate_tasks.py --prepend`: keep an earlier calibrated file's tasks without re-probing
- orchestrator: a later cycle with no admissible candidates now ends the run with the previous
  workspace (`terminal_kind: pool_exhausted`) instead of raising; only an empty *first* cycle raises.
  Found on the first live main run, where Haiku intermittently returned empty messages on later-cycle
  prompts and 43/240 CPO runs were lost while the baselines (which make all calls up front) lost none.
  The 43 runs were re-executed under the patched orchestrator; completed runs are unaffected.
- Anthropic adapter reports stop_reason and block types when a response has no text
- EVALUATION VALIDITY FIX: `CPOMethod` now sets evaluation timeouts (120 s per specialist, 600 s per
  request). The production default of 5 s per specialist silently dropped every slow (long-reasoning)
  candidate from CPO's pool and failed runs where all three specialists were slow; the baselines call
  the provider directly with a 60 s limit and were unaffected. All CPO-family rows of the first live main
  run are invalid and were re-run with `--redo-methods`; baseline rows unchanged.
- resume: the latest record per run supersedes earlier attempts (summaries were inflated by retries);
  `--redo-methods` discards and re-runs named methods
- CPO run detail records per-cycle specialist failures
- `CPOMethod(pool_size=...)`: fill the candidate pool by cycling roles, so a fixed budget can be spent
  as breadth or depth; `scripts/run_poolshape.py` sweeps 12x1 ... 2x6 at a 12-call budget and
  `scripts/fill_poolshape.py` writes the results into the manuscript
- manuscript: pedagogical passage on what the specialists were and why the minimal profile tests the
  mechanism's least favourable regime; new section "Pool shape at a fixed budget" (table filled after the run)
- pool-shape sweep run on Haiku 4.5: quality flat across breadth-vs-depth, refuting the allocation
  reading of the minimal-profile result and localising the gap to the reduction rule (signature vote
  vs model judge); written into manuscript section 9
- `JudgedConsensusWriter`: the loop's state (signature-majority reference, convergence, blind
  reconfirmation) is unchanged; the text carried forward and returned is chosen by a model judge over
  the selected candidates instead of the medoid. One call per cycle, reserved inside the budget.
  Motivated by the pool-shape sweep, which localised CPO's deficit to the reduction rule.
- `cpo_judged` method row (default and minimal profiles)
- live result: `cpo_judged` scored 0.50 clean / 0.40 history-locking, identical to or worse than the
  medoid writer; the reduction-rule hypothesis is refuted (written into manuscript section 9). Both
  refutations isolate reference-relative selection as the remaining cause.
- `run_poolshape.py --decisive`: pool 11, judge over the whole pool, selection disabled (phi=1) -- the
  test that decides whether selection is the cost
- decisive test run on Haiku 4.5: selection disabled + judge over the whole pool scores 0.60 / lock 0.10,
  matching best-of-n within intervals; reference-relative selection identified as the cost on
  single-answer tasks (manuscript section 9)
- 104 tests

- `tracing.py`: replaced `fcntl` (Unix-only) with a cross-platform file lock;
  Windows uses `msvcrt.locking`, POSIX keeps `fcntl.flock`.  `mypy` is now
  clean on Windows as well as Linux/macOS.

## 0.9.0 — evaluation harness

- second readiness pass:
  - multi-seed runs average per task before the paired bootstrap (previously the last seed overwrote)
  - means over calls/cycles/tokens exclude failed runs
  - rubric tasks excluded from the history-locked metric (undefined without a discrete answer); their
    blind distance is still recorded; `apply_ratings` + `scripts/apply_ratings.py` fold blind human
    ratings back into quality
  - unknown condition names rejected instead of silently treated as clean
  - CPO specialist prompt made byte-identical to the baselines' on the first cycle (tested); the
    only difference in later cycles is the shared-draft block the method requires
  - within-round samples issued concurrently; `ThrottledProvider` caps provider requests in flight
    across all runs (`--max-inflight`)
  - zero remaining budget raises a clean error instead of an index error
  - provider smoke test writes `release/evidence/provider_smoke_summary.json` with the `passed`
    field the release gate reads; failures are recorded, not lost
  - 91 tests

- readiness fixes found while dry-running the harness against a realistic mock and a live endpoint:
  - `ProviderConfig.temperature` (None = provider default) passed through all three adapters;
    the evaluation sets 0.7 so best-of-n and self-consistency actually sample
  - `MarkerWeightedSigner`: SimHash with the `Answer:` line weighted ×8; plain SimHash converged
    0/12 on a paraphrase mock, the marker signer 12/12 — plain SimHash kept as the
    `cpo_plain_simhash` ablation row
  - CPO reserves its reconfirmation calls inside the shared budget instead of hitting the wall
  - graders read the `Answer:` line first; per-cycle `change_signals` exposed for ε calibration
  - `run_evaluation.py`: `--temperature`, `--signer`, `--yes`, clear error on missing env vars,
    shared provider closed on exit; default budget 12
  - live check: a request with a dummy key reaches the provider, records a sanitised 401, counts
    one call and continues

- new `cpo.eval` package implementing the preregistered H4/H5 protocol:
  - `tasks` — JSONL task files, four deterministic graders, validation that fails loudly
  - `baselines` — best-of-n with a judge, self-consistency voting, multi-round debate, and CPO with
    one-component-at-a-time ablations (no consensus / no reconfirmation / no occupancy cap), all
    under a shared provider-call budget enforced by a counting provider wrapper
  - `harness` — three conditions (clean, noisy, history-locking), the blind support test applied
    identically to every method, resumable JSONL output, blind rating sheets for rubric tasks
  - `metrics` — Wilson intervals, task-paired percentile bootstrap, preregistered decision rule
- `scripts/run_evaluation.py` with an offline mock provider for zero-cost dry runs and a spend
  confirmation prompt before any paid call
- `docs/EVALUATION_RUNBOOK.md` — phase-by-phase instructions, cost model, pilot checks,
  troubleshooting, reporting checklist
- specialist prompts equalised across methods (same preamble, role text and answer format) so the
  comparison is not confounded by prompt shape; `ProviderSpecialist` now labels the task "Question"
- 10 new tests (78 total)

## 0.8.2 — review response

- `fixed_point_threshold` default 0.06 (was 0.02): the register criterion is near-exact repetition, text
  signatures move by several bits per cycle under paraphrase alone; 0.06 is the value at which supported
  pools converge while history-locked pools are still rejected (manuscript §6.3)
- `cpo-run --fixed-point-threshold` default follows
- experiments: φ × noise-share admission sweep added (`E2b_phi_sweep`)
- manuscript rewritten along the reviewer's structure: hypotheses H1–H5, transfer-status table, related
  work expanded, infrastructure moved to an appendix, 0/200 reported with an upper bound, preregistered
  protocol with baselines and ablations; title changed

## 0.8.1 — hardening and completion

- `Signer` protocol; `SimHashSigner` (default) and `ThresholdedVectorSigner` (embedding adapter);
  `Orchestrator(signer=...)`
- response carries `bundle` (level-1 atom of the selected candidates with correlations)
- reconfirmation reports `blind_consensus_distance` (unbiased majority of all fresh candidates)
- `cpo-run` CLI; `Makefile` (`check`, `evidence`, `paper`, `build`)
- quota sanity: startup warning when `CPO_QUOTA_BURST` < `max_cycles + reconfirmation_rounds`
- default trace path no longer under `/tmp`
- occupancy cap tolerates floating-point rounding in the tent (regression test)
- static analysis: ruff (E,F,I,B,UP,RUF,FURB) and mypy clean; bandit 0 findings; code formatted
- new evidence: `scripts/staging_validation.py` (real HTTP, 16 checks),
  `scripts/external_security.py` (bandit, pip-audit on the wheel's clean-venv closure, CycloneDX SBOM),
  `scripts/record_tests.py`; release gate restructured (8/10 local gates GO)
- tests: 68 (replay over HTTP, quota 429, signer hook, bundle, blind distance)
- manuscript: related work, three figures, configuration appendix, updated verification section
- `py.typed` shipped

## 0.8.0 — Chosen-Pattern Orchestrator (supersedes SGWM Orchestrator 0.7.1)

- new register-level core `cpo.focus`: flip map, order, Hamming resonance, affine selection law,
  focus map with tie-retaining consensus, fixed-point/cycle iteration, veridical/non-motif
  classification, chimeras, census with exact binomial intervals
- capacity theorem, admissible band, duty cycle, serialisation bound; occupancy controller caps
  selection breadth
- Φ_mc min-cut integration; shuffle-corrected W and M* estimators with the two-state conditioner;
  archetype generators and the (W, M*) plane
- text focus loop over SimHash signatures; medoid and provider consensus writers
- environmental reconfirmation of fixed points by blind resample; recombination signature
- abstraction-tower bundles that ship their correlation block
- traces record reference XOR deltas; responses report terminal kind and occupancy
- `cpo-census` and `cpo-plane` CLIs; computed evidence shipped in `release/evidence/`
- removed: claimed-signal evaluator, calibration pipeline, IFEval harness
- carried over: signed gateway identity, quotas, hash-chained traces, metrics, domain policy,
  OpenAI/Azure/Anthropic adapters, security scan, load test, fail-closed release gate
- 63 tests
