# Runbook: the real-environment evaluation (H4 and H5)

This is the next step for the project. Everything before it establishes mechanism on synthetic
specialists; this establishes — or refutes — the claim that the focus loop is worth using with
real language models. The harness is in `cpo.eval` and is driven by `scripts/run_evaluation.py`.

**What is being tested**

- **H4** — under a fixed provider-call budget, CPO reaches fewer *history-locked convergences*
  than best-of-*n*, self-consistency voting and debate, at comparable answer quality.
- **H5** — the difference is carried by the consensus step and blind reconfirmation, not by the
  occupancy cap or the choice of signature.

**The primary outcome, precisely.** A run's final answer is *history-locked* when a blind re-query
of the same specialists does not support it. The blind pool gets the task with no memory of the
run, and support means either the extracted final-answer line matches a fresh candidate's, or the
answer's signature lies within θ of the fresh pool's majority. **This test is applied identically
to every method, including the baselines** — that is what keeps the comparison honest, and it is
the part reviewers will check first.

---

## Phase 0 — before anything costs money

> **One command does the whole check: `make preflight TASKS=eval/tasks/main_math_calibrated_v2.jsonl`.**
> It runs the tests, checks the limits against your budget, confirms the task file can test the
> hypothesis, runs a mock dry run of the real command, and asserts on its summary (no failed runs,
> `H4_status != not_tested`, `p_sel` present). It writes `release/evidence/preflight.json`.
>
> **Limits that silently drop candidates, and the flags that set them.** A timeout, an output-token
> ceiling or a size cap does not fail a run loudly — it removes a candidate from the pool, and the
> arm that is slowest or most verbose loses the most. Set them explicitly:
> `--call-timeout` (default 180 s per provider call), `--per-run-timeout` (default derives from
> budget x call timeout + retry backoff), `--max-output-tokens` (default 8192; truncation is now
> *detected* and fails the run rather than being graded as a short answer),
> `--max-candidate-chars` (default 120k; an over-long candidate is dropped, not clipped), and
> `--retry-failed` (default 1 automatic re-run pass, so a transient failure does not become a
> between-arm asymmetry). `summary.json` carries `failures_by_method` and a
> `failure_asymmetry_warning` so an uneven failure pattern cannot pass unnoticed.
>
> **What else now fails early instead of late.** Before a real sweep, `run_evaluation` makes
> one minimal call: a wrong key, a wrong model name or an exhausted quota costs one call and a
> clear message instead of every run failing in turn. Each output directory carries a
> `run_fingerprint.json`; resuming into a directory written under a different budget, blind test,
> signature, output ceiling or model is refused, because those make same-keyed records
> incomparable (adding seeds, tasks, methods or conditions is allowed). `--max-total-tokens` stops
> launching new runs at a hard cap; rerunning the same command resumes. The rating and
> calibration scripts checkpoint atomically, so an interruption loses nothing already paid for;
> a calibration resumed from its checkpoint says so in its report.
>
> **Verify before you spend — every time.** The order is fixed: (1) `pytest`; (2) a `--provider mock`
> dry run of the *exact* command you intend to pay for, and read `preregistered_decision` in its
> `summary.json` — it must not say `H4_status: not_tested`; (3) a `--limit 3` smoke on the real model;
> (4) the grid. A paid run that skipped (2) cannot be trusted to have measured what you think.
>
> **Which script tests what.** `scripts/run_evaluation.py` on a task file with *discrete* graders
> (exact/numeric/contains — e.g. the calibrated math set) is the H4/H5 test: it computes the
> history-locked convergence metric. `scripts/run_drafting.py`, and any *rubric-graded* task file,
> measure **quality only**: the lock metric is undefined on rubric tasks by design, and such a run
> reports `H4_status: not_tested`. Both scripts now print this before spending.


### 0.1 Install and verify

```bash
cd cpo_orchestrator_sdk_v0.9.0
python -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"
make check            # ruff + mypy + 91 tests, all must pass
```

### 0.2 Dry run the whole pipeline offline

```bash
PYTHONPATH=src python scripts/run_evaluation.py \
  --provider mock --tasks eval/tasks/example.jsonl --out eval/runs/dryrun
```

This executes all eleven methods (three baselines, CPO, its judged-writer variant, four ablations, and the two convergence-gated methods of 0.9.4) across all three conditions with a deterministic offline provider
and zero network calls. It must finish with no entries in the `failures` column. Read
`eval/runs/dryrun/summary.json` and confirm you understand every field before spending anything.
Quality will be 0.0 — the mock does not actually answer questions. That is expected.

### 0.3 Build the task file

JSONL, one object per line:

```json
{"id": "gsm8k-0042", "family": "math", "prompt": "…", "answer": "72", "grader": "numeric",
 "metadata": {"source": "gsm8k", "split": "test"}}
```

Graders: `numeric` (last number, tolerant), `exact` (normalised equality), `contains` (reference
appears; `answer` may be a list of acceptable strings), `rubric` (no auto-grading; answers are
written to `rating_sheet.json` for blind human rating).

Sizing. The protocol calls for four families. A defensible minimum is **40 tasks per family, 160
total**; below ~30 per family the confidence intervals will be too wide to separate methods. Draw
from held-out splits of public sets (GSM8K or MATH for `math`, TriviaQA or NaturalQuestions for
`factual`) and write your own for `planning` and `synthesis`, which are rubric-graded. Keep the
task file under version control and **do not change it after the first real run**.

Validate before running:

```bash
PYTHONPATH=src python -c "from cpo.eval import load_tasks; t=load_tasks('eval/tasks/main.jsonl'); \
print(len(t), sorted({x.family for x in t}))"
```

Loading fails loudly on duplicate ids, missing fields, unknown graders, and graders that need an
answer but have none.

### 0.3b Difficulty calibration (pilot stage only)

A strong model can solve a whole family every time; then quality is 1.0 for every method, no
answer is ever locked, and the family cannot discriminate anything. Detect this in the pilot
(all quality = 1.0 and all lock rates = 0.0 is the signature) and fix it by rule, not by hand:

```bash
# NEW task sets only, under NEW names: the paper's frozen set is main_math_calibrated_v2.jsonl and
# both scripts refuse to overwrite an existing file without --force.
python scripts/gen_hard_math.py --count 120 --seed 7 --out eval/tasks/candidates_math_v3.jsonl
python scripts/calibrate_tasks.py --provider anthropic --model <model> \
  --candidates eval/tasks/candidates_math_v3.jsonl --keep 40 --probes 3 \
  --out eval/tasks/main_math_calibrated_v3.jsonl
```

The generator computes every answer, so references are correct by construction. The
calibration script asks the model three times per candidate and keeps the first 40 it gets
wrong at least once; it writes a `.calibration.json` record with the rule, every probe result,
and the output file's SHA-256. Replace the family in `main.jsonl` with the calibrated file, record
the hash in the preregistration, and never re-calibrate after the main run starts. Do the same
for any other family that hits the ceiling.

### 0.4 Freeze the parameters — in writing, before you look at any result

Record these in the preregistration and do not touch them afterwards:
`φ = 0.5`, `k_min = 2`, `k_max = 8`, `n = 256`, `n_ws = 24`, `ε = 0.06`, `θ = 0.15`, `R = 1`
(CPO's internal blind round), blind draws = 3 (the harness's test, applied to all methods),
budget = 12 calls per run, temperature = 0.7, signer = marker-weighted. The manuscript section 7
states these; the point of writing them down again is that the run log should show them unchanged.

**Why these values.** Budget 12 with three specialists gives CPO three cycles plus its blind round,
debate four rounds, self-consistency twelve samples, best-of-*n* eleven candidates plus a judge.
Temperature must be above zero or self-consistency and best-of-*n* draw near-identical samples per
role; 0.7 is conventional. The signer is *marker-weighted* SimHash: every method is instructed to end
with `Answer: <answer>`, and that line's shingles are weighted ×8 so agreement on the deliverable
drives convergence rather than phrasing. Plain SimHash is kept as the `cpo_plain_simhash` ablation
row — on a realistic paraphrase mock it converged in 0 of 12 runs where the marker signer converged
in 12 of 12, which is the representation finding the paper flags and this run will measure on real
models.

**Rubric tasks and the primary metric.** History-locked convergence is only defined where there is a
discrete answer to reproduce; rubric-graded families feed quality (after blind rating) and are
excluded from the lock metric.

**The blind pool must be an independent sample.** With real providers at temperature > 0 it is.
If you ever substitute a cached or seeded provider, make sure the blind re-query is not replaying the
run's outputs; a replay makes every answer look supported and hides every lock.

### 0.5 Cost estimate

Calls per run ≤ `budget + blind_draws` = 15. Total ≤
`tasks × methods × conditions × seeds × 15`. For 160 tasks × 8 methods × 3 conditions × 1 seed
that is **3,840 runs, ≤ 57,600 calls per model**. At ~700 input + ~250 output tokens per call,
roughly 40M input and 14M output tokens per model. Price that against your provider's rates
before you start, and run the pilot first. Use `--methods` to run a subset if the budget is tight;
the three baselines plus `cpo` and `cpo_no_reconfirmation` are the minimum that tests H4 and the
central H5 claim.

---

## Minimal-cost profile

If budget is the constraint, `--profile minimal` runs the cheapest configuration that still tests H4
and the central H5 claim: one model, one calibrated family (40 hard math tasks), nine methods
(three baselines, `cpo`, `cpo_judged`, `cpo_no_consensus`, `cpo_no_reconfirmation`, and the two
convergence-gated methods `cpo_adaptive` and `cpo_gated_judge`), two conditions (clean and
history-locking), one seed — 720 runs, at most 720 x (12 + 3) = 10,800 calls; the adaptive and
gated arms stop early when they converge, so the real count is lower. What it gives up, and what
the paper must then say: no representation ablation (SimHash question stays open), no occupancy
ablation, no noisy condition, no factual/planning/synthesis families, no run-to-run variance, one
model. Record the deviation in `docs/PREREGISTRATION.md` before running.

```bash
# The next minimal-profile run re-uses the paper's frozen calibrated set, so results stay
# comparable with the published table. Preflight first; it costs nothing.
make preflight TASKS=eval/tasks/main_math_calibrated_v2.jsonl
python scripts/run_evaluation.py --provider anthropic --tasks eval/tasks/main_math_calibrated_v2.jsonl \
  --out eval/runs/main-minimal-v2 --profile minimal --max-total-tokens 12000000
```

## Phase 1 — pilot (one model, a fraction of the tasks)

```bash
export ANTHROPIC_API_KEY=...   # or OPENAI_*, or AZURE_OPENAI_*
export ANTHROPIC_MODEL=...
PYTHONPATH=src python scripts/run_evaluation.py \
  --provider anthropic --tasks eval/tasks/main.jsonl --out eval/runs/pilot-anthropic \
  --limit 12 --budget 12 --temperature 0.7 --concurrency 4
```

The script prints the planned run and call count and asks for confirmation before any paid call
(`--yes` skips the prompt for unattended runs). It exits with a clear message if a required
environment variable is missing.

**Check before scaling up:**

| check | where | what you want |
|---|---|---|
| failures | `summary.json` → `failures` per method | 0, or a handful with a clear cause |
| budget respected | `mean_calls` | ≤ 9 for every method |
| `cpo` terminal kinds | `runs.jsonl` → `detail.terminal_kind` | mostly `fixed_point`; if mostly `budget_exhausted`, the loop is not converging — see Troubleshooting |
| `cpo` change signals | `detail.change_signals` | falling across cycles; the last value is what ε must exceed. Calibrate ε from the 75th percentile of last-cycle changes on runs whose answer was correct |
| blind test usable | `blind_tested` | close to `runs`; near zero means the blind pool is failing |
| graders behaving | spot-check 10 `answer_excerpt` against `correct` | no systematic mis-grading |
| lock rates spread | `history_locked_convergence` | not all 0.0 and not all 1.0; if degenerate, adjust θ *now*, before the main run, and record that you did |

Calibrating θ is legitimate at the pilot stage and only at the pilot stage. Re-run the pilot with
`--blind-theta` at 0.10, 0.15 and 0.20, pick one, write it down, never touch it again.

---

## Phase 2 — main run

One command per model. Each is resumable: if it dies, re-run the identical command and it skips
completed runs.

```bash
for MODEL in small mid large; do
  export ANTHROPIC_MODEL=$MODEL
  PYTHONPATH=src python scripts/run_evaluation.py \
    --provider anthropic --tasks eval/tasks/main.jsonl \
    --out eval/runs/main-$MODEL --budget 12 --temperature 0.7 --concurrency 4 --seeds 1 --yes
done
```

Use three open-weight models of different sizes if you can host them (point the OpenAI adapter at
a compatible endpoint); otherwise three sizes from one vendor, and say so in the paper — it
weakens the generality claim and a reviewer will notice.

Run it in `tmux` or `screen`. Expect hours. Watch spend at the provider console; the harness does
not know your prices.

---

## Phase 3 — human rating for rubric tasks

Each output directory contains `rating_sheet.json` with one entry per rubric answer, **with the
method name absent from the answer text**. Rate blind:

1. Shuffle the sheet.
2. Have two raters score each answer 0–3 against a rubric you fixed in Phase 0.
3. Report inter-rater agreement (Cohen's κ). Below κ ≈ 0.6, sharpen the rubric and re-rate.
4. Write the ratings back into the `rating` field (a number, or a list of numbers from several
   raters) and fold them in:

```bash
PYTHONPATH=src python scripts/apply_ratings.py eval/runs/main-mid --threshold 2.0
```

This writes `runs_rated.jsonl` and `summary_rated.json` next to the originals, which are left
untouched. A rubric answer counts as correct when its mean rating is at least the threshold; fix the
threshold in Phase 0. Rubric tasks contribute to **quality only** — the history-locked metric is
defined on discrete-answer tasks, so rubric runs are excluded from it rather than counted as locked
(their blind distance is still recorded for inspection).

---

## Phase 4 — read the result honestly

`summary.json` has three parts.

**`by_method_condition`** — per method and condition: quality with a Wilson interval, history-locked
convergence with a Wilson interval, mean calls, cycles and tokens.

**`comparisons`** — CPO against each other method, paired by task, with a percentile bootstrap over
tasks. `lock_rate_difference.h4_supported` is true when the whole 95% interval for
(CPO − baseline) lies below zero.

**`preregistered_decision.H4_supported`** — true only when that holds against *every* baseline and
quality is not materially worse. **This flag is not the conclusion; it is the arithmetic.** Read the
per-comparison intervals yourself.

H5 is read from the ablation rows, not from that flag:

| row | expected under H5 |
|---|---|
| `cpo_no_consensus` | lock rate rises toward the baselines |
| `cpo_no_reconfirmation` | lock rate rises (the mechanism is removed) |
| `cpo_no_occupancy` | little change — if so, **drop the occupancy cap from the method** |
| `cpo_plain_simhash` | lock and quality similar to `cpo` → the loop, not the signer, carries the result; much worse → the representation matters and the paper must say so |

**What each outcome means for the paper.**

The minimal-profile run has already happened and is reported: H4 was not supported, H5 was not
decidable at n = 40, and the paper is positioned accordingly (a mechanism study whose tested claim
is that reference-relative selection is harmful in the single-answer regime). For the *next* run:

- **H6 supported** (`cpo_adaptive` within self-consistency's interval at <= 75% of its calls) → the
  convergence criterion pays as a stopping rule on a live model, not only in replay. Report it as the
  first positive live result for the mechanism.
- **H7 supported** (`cpo_gated_judge` above self-consistency, within 0.05 of best-of-n, at fewer
  calls) → the convergence test is useful for deciding where verification is worth paying for.
  Read its `lock_decomposition`, not only its raw lock rate: a higher raw lock rate is predicted.
- **H7 fails while the judge is called on ~40% of tasks** → the judge is the bottleneck, not the
  gating. Check `judge_called` rates and the accuracy of judged vs non-judged runs before concluding
  anything about convergence.
- **Stage 1 shows `p_sel > p` on drafting** → first evidence for Claim B; the full grid is then
  worth funding. **`p_sel <= p` on drafting** → Claim B fails and the paper should say the mechanism
  has no useful regime for selection, while H6/H7 may still stand.
- **Differences explained by candidate count** rather than the loop are a preregistered falsifier.
  Check `mean_calls` and `mean_cycles` first.

---

## Troubleshooting

| symptom | cause | fix |
|---|---|---|
| CPO mostly `budget_exhausted` | ε too tight for this model's paraphrase variance, or answers lack the `Answer:` line so the marker signer falls back to plain SimHash | check `detail.change_signals`; confirm outputs end with `Answer:`; raise ε at the **pilot** stage only and record it |
| CPO converges in one cycle every time | specialists are near-identical | diversify the role instructions; identical specialists make the loop pointless and the result uninteresting |
| every answer flagged history-locked | θ too tight, or blind draws too few | raise `--blind-draws` to 5 at the pilot stage |
| nothing flagged, in any condition | θ too loose | lower θ at the pilot stage |
| provider 429s | too many requests in flight | lower `--max-inflight` (default 8, applied across all runs) before lowering `--concurrency`; the adapters retry with bounded backoff |
| runs fail with "call budget exhausted" | a method needs more calls than the budget allows | raise `--budget`; it applies to all methods equally, which is the point |
| results differ between reruns | sampling at temperature 0.7 | expected; run `--seeds 1,2,3` to measure it, and report it |

---

## Reporting checklist

- [ ] Task file, its provenance, and the frozen split are published.
- [ ] Parameters were fixed before the first real run and are shown unchanged in the log.
- [ ] θ and ε calibration, if any, happened at the pilot stage and is disclosed.
- [ ] Every method received the same budget; `mean_calls` is reported per method.
- [ ] The blind support test is described as applied to all methods, not only CPO.
- [ ] Rubric ratings were blind, by two raters, with κ reported.
- [ ] Confidence intervals accompany every rate; the bootstrap is paired by task.
- [ ] Negative and null results are reported in the same detail as positive ones.
- [ ] `runs.jsonl` is published alongside the paper so anyone can recompute the summary.
- [ ] `--max-inflight` and `--concurrency` are reported; they affect timing, not results.

## Known limits of this harness

The baselines are faithful but minimal implementations of their published methods, not the
authors' own code; a reviewer may reasonably ask for stronger baselines. The blind support test is
a proxy for "the task supports this answer", and a fresh pool that is confidently wrong in the same
way will count as support — it detects *self-sustained* answers, not *false* ones. The marker-weighted
signer presupposes the `Answer:` format; on rubric tasks it reduces to plain SimHash and CPO will
converge less often there. One seed per configuration measures no run-to-run variance — add
`--seeds 1,2,3` if the budget allows, and report it.


## Pool-shape sweep (after the minimal run)

If the minimal run shows CPO trailing best-of-n on a single-answer family, test whether the cause is
pool *shape* rather than the mechanism. This holds the budget at 12 calls and varies only how it is
split between pool size and cycles (12x1 breadth ... 2x6 depth), with reconfirmation off so every call
is a candidate. About 2,400 calls on Haiku for 40 tasks.

```powershell
python scripts\run_poolshape.py --provider anthropic --model claude-haiku-4-5-20251001 --tasks eval\tasks\main_math_calibrated_v2.jsonl --out eval\runs\poolshape-haiku --yes
python scripts\fill_poolshape.py eval\runs\poolshape-haiku
```

The first command prints quality and lock rate per shape and writes the summary; the second fills the
table in `paper/evaluation/cpo_evaluation.tex` and prints the measured trend. If quality rises toward best-of-n as the
pool widens, the negative result is about allocation, not the mechanism, and the paper says so; if it
stays flat, convergence control adds nothing on this family even given breadth. Write the final reading
sentence yourself.
