# Deployment gates

`scripts/release_gate.py` is fail-closed: missing evidence is NO-GO. `make evidence` regenerates
every local evidence file and evaluates the gate.

| gate | evidence file | how produced | 0.9.0 |
|---|---|---|---|
| unit tests | `tests_summary.json` | `scripts/record_tests.py` | GO (91 passed) |
| static analysis clean | `tests_summary.json` | ruff + mypy, same script | GO |
| census reproduces structure (≥90 % fixed points per seed) | `census_report.json` | `cpo-census` | GO |
| plane dissociation | `plane_report.json` | `cpo-plane` | GO |
| local security scan (no high) | `security_scan.json` | `scripts/security_scan.py` | GO |
| SAST + dependency audit + SBOM | `external_security_summary.json`, `bandit.json`, `pip_audit.json`, `sbom.cdx.json` | `scripts/external_security.py` (clean venv from the wheel) | GO (0 findings, 0 vulns, 17 runtime packages) |
| local load test (500/500 HTTP 200) | `load_test.json` | `scripts/load_test.py` | GO |
| staging validation over HTTP (16 checks) | `staging_validation.json` | `scripts/staging_validation.py` (separate uvicorn process) | GO |
| provider smoke tests | `provider_smoke_summary.json` | `scripts/provider_smoke_test.py` with credentials | pending |
| container image scan | `container_scan.json` | build the image, scan with your registry's scanner, write `{passed, critical, high}` | pending |

## To reach GO

1. Run `PYTHONPATH=src python scripts/provider_smoke_test.py {openai|azure|anthropic}` with real
   credentials in a controlled environment; it writes `release/evidence/provider_smoke_summary.json`
   (one entry per provider, `passed` when every provider replied correctly) without logging secrets.
2. Build `docker build -t cpo:0.9.15 .`, scan it (Trivy, Grype, or your registry's scanner) and
   write `release/evidence/container_scan.json` with `passed`, `critical`, `high`.
3. Re-run `python scripts/release_gate.py`.
