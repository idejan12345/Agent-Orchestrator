# Security

- The application trusts only gateway assertions signed with `CPO_GATEWAY_SECRET`. The signature
  binds principal, timestamp, HTTP method, path and request-body SHA-256; assertions expire after
  the clock-skew window and are replay-protected within the process.
- Readiness fails closed when no gateway secret is configured. Metrics require `X-Metrics-Token`.
- Per-principal token-bucket and concurrency quotas apply after authentication; quota units count
  cycles plus reconfirmation rounds.
- Strict JSON models (`extra="forbid"`), nested context scanning, candidate size limits,
  specialist and consumer timeouts, request timeout, per-request locks.
- `_cpo_resample` is removed from client context; only the orchestrator issues blind resamples.
- Provider adapters: fixed HTTPS hosts, redirect rejection, bounded retries/response sizes,
  JSON-only responses, sanitized errors. Tools, files, streaming and arbitrary endpoints disabled.
- Candidate `claimed_risk` can only reject (hard threshold); nothing self-reported can promote.
- `scripts/security_scan.py` is a stdlib AST/pattern scan, not a dependency CVE database or
  penetration test. `.github/workflows/validation.yml` runs bandit, pip-audit and an SBOM export.
