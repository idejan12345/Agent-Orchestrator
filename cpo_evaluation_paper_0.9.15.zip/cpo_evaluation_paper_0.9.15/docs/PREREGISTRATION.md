# Preregistration template for the reconfirmation evaluation

The reconfirmation test is the SDK's operationalisation of H2 of the theory paper (the source model's prediction on non-motif perceptual locking): fixed points carved by a
regularity are re-confirmed by a fresh pool; those carved by the loop's history are not. Before
treating `not_reconfirmed` as an outcome signal, declare:

1. the task set and the outcome label (human review verdict, ground truth, or downstream metric);
2. the specialists, prompts and providers, frozen;
3. `phi`, `k_min`, `k_max`, `workspace_slots`, `target_bundle`, `fixed_point_threshold`;
4. `reconfirmation_rounds` and `reconfirmation_theta`, chosen before seeing outcomes;
5. the prediction: `not_reconfirmed` fixed points have a worse outcome rate than `reconfirmed`
   ones, with effect size and confidence interval;
6. the control: the same comparison on `budget_exhausted` runs, where no attractor formed;
7. what would falsify: no difference in outcome rate, or a difference explained by candidate count.

Report the recombination signature separately; it is exploratory.
