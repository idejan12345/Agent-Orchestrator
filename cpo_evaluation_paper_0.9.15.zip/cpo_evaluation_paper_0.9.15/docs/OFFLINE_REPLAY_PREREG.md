# Offline replay — rules and predictions fixed before running

Written before any replay result was computed. The replay harness is `scripts/offline_replay.py`.

## Data

The self-consistency rows of `eval/runs/main-minimal-haiku/runs.jsonl` store, per task and
condition, the 12 independent final answers Claude Haiku 4.5 produced (`detail.votes`). 40 tasks x
2 conditions = 80 empirical answer pools of 12 real draws, with ground truth. Draws within a pool are
exchangeable, so any rule that uses at most 12 of them is evaluated exactly by averaging over random
orderings (here 2000 per pool). No new model calls.

Each ordering is split: the **last 3 draws are the held-out blind test** and are never seen by a
rule; a rule may use at most the first 9. **Lock** is emulated as: the rule's answer does not appear
among the 3 held-out draws (the harness's literal-match criterion; its signature criterion is
close to redundant under the marker-weighted signer).

## What replay can and cannot test

It can test **aggregation and stopping rules over independent samples**. It cannot test anything
in which a candidate is conditioned on the workspace (cycles that read the previous draft), because
those candidates were never generated. Results are about these 80 pools from one model.

## Rules

- **SC-n** — plurality of the first n draws (n = 3..9). Ties break by first appearance, which is
  random under the ordering.
- **CPO-emul** — the configuration of paper Table 9 reduced to its aggregation logic: 3 cycles x
  pool of 3. Cycle 1: the reference is the request, which is uninformative about correctness, so 2
  of 3 are selected at random. Later cycles: the 2 candidates most similar to the incumbent are
  selected (copies of the incumbent answer first, then at random). Consensus of 2: agreement wins;
  disagreement is a tie, and ties retain the incumbent. 9 draws.
- **D2 adaptive** (the convergence criterion as a stopping rule) — batches of 3. Stop after batch
  1 if it is unanimous. After batch t >= 2, stop if the running plurality did not change in this
  batch and at least 2 of its 3 draws equal it. Otherwise continue, to at most 9 draws. Answer:
  running plurality.
- **D3 reconfirmation that acts** — CPO-emul for 2 cycles (6 draws), then 3 internal blind draws.
  If the converged answer appears among them it stands; otherwise the answer is the plurality of
  all 9 draws.
- **Oracle-9** — correct answer present among the 9 (ceiling for any selector or judge).

## Predictions

- **R1.** CPO-emul accuracy < SC-9 (Claim A reproduced offline, from aggregation alone).
- **R2.** D2's accuracy at its mean cost m is at least that of SC at cost m (linear interpolation
  between the neighbouring integers), and D2 reaches within 0.02 of SC-9 at m < 9.
- **R3.** D3's lock rate < CPO-emul's, with accuracy not lower.
- **R4.** No rule in this list exceeds SC-9 accuracy by more than 0.02. Exceeding plurality over
  independent samples needs information the samples do not carry — a verifier or judge — not a
  better consensus.

R4 is the prediction most likely to disappoint, and it is written down so that it cannot be
quietly dropped.

## Amendment 1 — grader replaced after a failed validation (2026-10-02T02:12:45Z)

The first execution graded a rule's answer by string equality between the normalised vote key and
the normalised ground truth. Its built-in check — does the grader reproduce the harness's recorded
verdict on the self-consistency winner? — agreed on only 60/80 pools, so **every number from that
execution is discarded**. The cause: `normalise` maps the decimal point and the thousands comma to
spaces and strips the sign, so "147.30" (correct for 147.3) failed to match while a wrong-signed
answer matched. That first execution's table *was seen* before this amendment; the rules and
predictions above are unchanged.

Changes: (1) keys are graded numerically after reconstructing the number (trailing digit tokens;
a final token of at most two digits is the fractional part; three-digit tokens are thousands
groups; prose keys are parsed from the last "answer" token). (2) The **9 tasks with negative
answers are excluded** — the sign is unrecoverable from the stored keys, and guessing it would bias
accuracy upward. 31 tasks x 2 conditions = 62 pools remain. (3) The validation check is now a hard
gate: the replay aborts unless the grader matches every recorded verdict on pools whose winner is
untied (a tied winner depends on sample order, which was not recorded).

Consequence for interpretation: absolute accuracies here are on 31 of the 40 tasks and are not
comparable to Table 9; comparisons between rules on the same pools are.

## Results (after Amendment 1; validation 58/58 untied pools)

62 pools (31 tasks x 2 conditions), 2000 orderings each, method budget 9 draws, 3 held out.

| rule | accuracy | lock | mean draws |
|---|---:|---:|---:|
| SC-3 | 0.607 | 0.258 | 3 |
| SC-6 | 0.641 | 0.194 | 6 |
| SC-9 | 0.651 | 0.177 | 9 |
| CPO-emul | 0.622 | 0.229 | 9 |
| D2 adaptive | 0.652 | 0.178 | 6.31 |
| D3 acting reconfirmation | 0.647 | 0.184 | 9 |
| Oracle-9 | 0.968 | — | 9 |

All four predictions hold. R1: CPO-emul is 0.029 below SC-9 and locks 0.052 more often — error
retention reproduced from aggregation alone, with no workspace conditioning. R2: D2 equals SC-9 at
70% of the draws and beats SC at its own mean cost (0.652 vs 0.642). R3: acting on reconfirmation
recovers most of CPO-emul's loss. R4: no consensus rule beats plurality; the 0.32 gap to Oracle-9
is headroom only a verifier can reach.

## Exploratory analyses (not preregistered — labelled as such wherever cited)

- **Where errors sit.** D2 stops after 3 draws in 31% of runs (accuracy 0.789, correct answer
  present 0.789 — unanimous-and-wrong runs are shared systematic errors no verifier can fix), after
  6 in 28% (0.691 / 0.951), and runs to 9 without converging in 41% (0.517 / 0.975). Non-converged
  runs hold 56.5% of all errors and almost always contain the right answer.
- **Gated verification ceiling.** A perfect judge called only on non-converged runs: accuracy 0.839
  (calls on 41% of tasks). This motivated `GatedJudge`; it is a bound, not a prediction.
- **The lock metric penalises correct dissent.** That same perfect gated judge *raises* the lock rate
  0.177 -> 0.221; 23.7% of its correct answers are flagged "locked" because three blind draws did
  not reproduce a minority answer. Hence the lock decomposition (error lock vs false alarm).
- **Baseline vote-key defect.** In 28/62 pools one numeric value was split across several vote keys;
  value-aware keys change SC-12 from 0.661 to 0.677 (one pool). Fixed in 0.9.3.

## Erratum (cross-reference only)

"Paper Table 9" above means the live-results table (`tab:live`). After the manuscript gained a
selection-breadth table and this replay's own table, that table is numbered 7. No rule, prediction or
result is affected. Documents in this repository now cite tables by name, not number.

## Erratum 2 — exploratory figures now regenerated by the shipped script

The exploratory figures above were first computed with ad-hoc code using a different random seed.
`scripts/offline_replay.py` now computes all of them on the same 2000 orderings (seed 1) as the main
table and writes them to `eval/replay/offline_replay.json` under `exploratory`. Two values changed
in the third decimal and were corrected in place: correct gated answers flagged "locked" 23.6% ->
23.7%, and the plurality-9 lock rate quoted beside it 0.176 -> 0.177 (matching the table). No
conclusion is affected.
