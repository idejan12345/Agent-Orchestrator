# Operations

Environment: `CPO_GATEWAY_SECRET`, `CPO_METRICS_TOKEN`, `CPO_TRACE_PATH`,
`CPO_QUOTA_UNITS_PER_MINUTE`, `CPO_QUOTA_BURST`, `CPO_QUOTA_MAX_CONCURRENT`, `CPO_LOG_LEVEL`.

Metrics: `cpo_http_requests_total`, `cpo_http_request_duration_seconds_*`, `cpo_orchestrations_total{status,terminal}`,
`cpo_reconfirmation_total{status}`, `cpo_policy_rejections_total`, inflight gauges.

Watch `terminal=budget_exhausted` and `reconfirmation=not_reconfirmed` rates; a rising
`not_reconfirmed` rate means the specialists lock onto workspace history rather than the input.
Verify trace integrity with `HashChainJsonlSink(path).verify()`.

Quota units per request = `max_cycles + reconfirmation_rounds` (7 by default). Set
`CPO_QUOTA_BURST` ≥ that value or every full-length request is refused; the service logs
`quota_burst_below_request_cost` at startup when this is violated.
