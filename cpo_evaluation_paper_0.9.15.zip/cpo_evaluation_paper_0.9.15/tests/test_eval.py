import asyncio
import json
from pathlib import Path

import pytest

from cpo.eval import HarnessConfig, default_methods, grade, load_tasks, summarise, wilson
from cpo.eval.baselines import BestOfN, CountingProvider, Debate, SelfConsistency, final_answer_line
from cpo.eval.harness import RunRecord, roles_for, run_one
from cpo.eval.metrics import bootstrap_difference
from cpo.eval.tasks import Task

TASKS = Path(__file__).resolve().parents[1] / "eval" / "tasks" / "example.jsonl"


class Fake:
    provider_name = "fake"

    def __init__(self, text="Working.\nAnswer: 52"):
        self.text, self.calls = text, 0

    async def generate(self, prompt, *, request_id):
        from cpo.providers.base import ProviderResult

        self.calls += 1
        return ProviderResult(self.text, "fake", "m", request_id, {"input_tokens": 3, "output_tokens": 5})

    async def readiness(self):
        return True, "ok"

    async def close(self):
        return None


def test_task_loading_and_validation(tmp_path):
    tasks = load_tasks(TASKS)
    assert len(tasks) == 6 and {t.family for t in tasks} == {"math", "factual", "planning", "synthesis"}
    bad = tmp_path / "bad.jsonl"
    bad.write_text('{"id":"a","family":"f","prompt":"p","grader":"numeric"}\n')
    with pytest.raises(ValueError):  # numeric grader without an answer
        load_tasks(bad)
    bad.write_text(
        '{"id":"a","family":"f","prompt":"p","answer":"1"}\n{"id":"a","family":"f","prompt":"q","answer":"2"}\n'
    )
    with pytest.raises(ValueError):  # duplicate id
        load_tasks(bad)


def test_graders():
    numeric = Task(id="n", family="f", prompt="p", answer="52", grader="numeric")
    assert grade(numeric, "so the total is 52") is True
    assert grade(numeric, "the total is 51") is False
    assert grade(numeric, "no digits here") is False
    exact = Task(id="e", family="f", prompt="p", answer=["W"], grader="exact")
    assert grade(exact, " w ") is True and grade(exact, "tungsten") is False
    contains = Task(id="c", family="f", prompt="p", answer=["Jupiter"], grader="contains")
    assert grade(contains, "It is Jupiter, at under 10 hours.") is True
    assert grade(Task(id="r", family="f", prompt="p", grader="rubric"), "anything") is None


def test_final_answer_extraction():
    assert final_answer_line("reasoning\nAnswer: 42") == "42"
    assert final_answer_line("no marker here") == "no marker here"


def test_budget_is_enforced_and_shared_across_methods():
    roles = roles_for("clean", 0.34)
    for method in (BestOfN(), SelfConsistency(), Debate(agents=3)):
        provider = CountingProvider(Fake(), budget=9)
        run = asyncio.run(method.run("2 plus 50?", provider, roles))
        assert run.calls <= 9 and run.answer and run.final_candidates
    provider = CountingProvider(Fake(), budget=2)
    with pytest.raises(RuntimeError):  # budget exhausted is raised, not silently ignored
        asyncio.run(SelfConsistency().run("q", CountingProvider(Fake(), budget=0), roles))
    assert provider.remaining == 2


def test_conditions_change_roles():
    clean = roles_for("clean", 0.34)
    noisy = roles_for("noisy", 0.34)
    locking = roles_for("history_locking", 0.34)
    assert clean != noisy and sum(v != clean[k] for k, v in noisy.items()) == 1
    assert all("shared draft" in v for v in locking.values())


def test_run_one_records_blind_support_for_every_method():
    tasks = load_tasks(TASKS)
    task = next(t for t in tasks if t.id == "math-001")
    cfg = HarnessConfig(budget=8, blind_draws=2, conditions=("clean",))
    for method in default_methods():
        rec = asyncio.run(run_one(task, method, "clean", 1, lambda: Fake(), cfg))
        assert rec.error is None, rec.error
        assert rec.blind_supported is True and rec.blind_distance is not None
        assert rec.correct is True and rec.calls <= cfg.budget


def test_unsupported_answer_is_flagged_as_history_locked():
    task = Task(id="t", family="f", prompt="What is 2 plus 50?", answer="52", grader="numeric")
    cfg = HarnessConfig(budget=4, blind_draws=2, conditions=("clean",))

    class Drifting(Fake):
        """Answers one way during the run and another way when re-queried blind."""

        def __init__(self):
            super().__init__()
            self.seen = 0

        async def generate(self, prompt, *, request_id):
            self.seen += 1
            self.text = (
                "Answer: 52" if not request_id.startswith("blind") else "Answer: 99 lantern quartz harbor"
            )
            return await super().generate(prompt, request_id=request_id)

    rec = asyncio.run(run_one(task, SelfConsistency(), "clean", 1, lambda: Drifting(), cfg))
    assert rec.blind_supported is False


def test_summary_statistics_and_decision():
    records = []
    for i in range(20):
        records.append(
            RunRecord(
                task_id=f"t{i}",
                family="f",
                method="cpo",
                condition="clean",
                seed=1,
                answer_excerpt="a",
                correct=True,
                blind_supported=i > 0,
                blind_distance=0.1,
                calls=9,
                budget=9,
                rounds=3,
                prompt_tokens=10,
                completion_tokens=10,
                elapsed_s=0.1,
            )
        )
        records.append(
            RunRecord(
                task_id=f"t{i}",
                family="f",
                method="best_of_n",
                condition="clean",
                seed=1,
                answer_excerpt="a",
                correct=True,
                blind_supported=i > 9,
                blind_distance=0.3,
                calls=9,
                budget=9,
                rounds=1,
                prompt_tokens=10,
                completion_tokens=10,
                elapsed_s=0.1,
            )
        )
    s = summarise(records)
    assert s["by_method_condition"]["cpo|clean"]["history_locked_convergence"] == pytest.approx(0.05)
    assert s["by_method_condition"]["best_of_n|clean"]["history_locked_convergence"] == pytest.approx(0.5)
    comp = s["comparisons"]["cpo_vs_best_of_n|clean"]
    assert comp["lock_rate_difference"]["cpo_minus_other"] < 0
    assert comp["lock_rate_difference"]["h4_supported"] is True
    assert s["preregistered_decision"]["H4_supported"] is True


def test_intervals_and_bootstrap():
    lo, hi = wilson(5, 100)
    assert lo < 0.05 < hi and 0 <= lo and hi <= 1
    obs, (lo, hi) = bootstrap_difference([1.0] * 10, [0.0] * 10, rounds=500, seed=1)
    assert obs == pytest.approx(1.0) and lo == pytest.approx(1.0)
    with pytest.raises(ValueError):
        bootstrap_difference([1.0], [0.0, 1.0])


def test_harness_is_resumable(tmp_path):
    from cpo.eval import run_evaluation

    tasks = load_tasks(TASKS)[:2]
    methods = [SelfConsistency()]
    cfg = HarnessConfig(budget=4, blind_draws=2, conditions=("clean",), concurrency=2)
    asyncio.run(run_evaluation(tasks, methods, lambda: Fake(), cfg, tmp_path, resume=True))
    first = (tmp_path / "runs.jsonl").read_text().count("\n")
    asyncio.run(run_evaluation(tasks, methods, lambda: Fake(), cfg, tmp_path, resume=True))
    assert (tmp_path / "runs.jsonl").read_text().count("\n") == first  # nothing re-run
    summary = json.loads((tmp_path / "summary.json").read_text())
    assert summary["by_method_condition"]["self_consistency|clean"]["runs"] == 2


class LLMLike:
    """Mimics a language model: paraphrase jitter, a wrong-answer rate, and a tendency to
    preserve a shared draft when one is shown (the history-locking mechanism)."""

    provider_name = "llmlike"

    def __init__(self, seed: int, wrong_rate: float = 0.2, lock_strength: float = 0.9):
        import random

        self.rng = random.Random(seed)  # nosec B311
        self.wrong_rate, self.lock_strength = wrong_rate, lock_strength
        self.calls = 0

    async def generate(self, prompt, *, request_id):
        from cpo.providers.base import ProviderResult

        self.calls += 1
        draft = None
        for block in prompt.split("\n\n"):
            if block.startswith("Current shared workspace") or block.startswith("Other specialists answered"):
                draft = block
        if draft and "Answer:" in draft and self.rng.random() < self.lock_strength:
            prior = draft.rsplit("Answer:", 1)[1].strip().split()[0]
            answer = prior
        else:
            answer = "52" if self.rng.random() > self.wrong_rate else str(self.rng.choice([50, 51, 60, 64]))
        filler = " ".join(
            self.rng.choice(["pens", "boxes", "left", "total", "so", "gives", "then"]) for _ in range(8)
        )
        return ProviderResult(
            f"Working: {filler}.\nAnswer: {answer}",
            "llmlike",
            "m",
            request_id,
            {"input_tokens": 100, "output_tokens": 20},
        )

    async def readiness(self):
        return True, "ok"

    async def close(self):
        return None


def test_cpo_converges_within_budget_on_llm_like_pool():

    task = Task(
        id="m",
        family="math",
        prompt="Maya buys 5 boxes of 12 pens and gives away 8. How many are left?",
        answer="52",
        grader="numeric",
    )
    cfg = HarnessConfig(budget=12, blind_draws=3, conditions=("clean",))
    kinds, supported, correct = [], 0, 0
    for seed in range(12):
        method = next(m for m in default_methods() if m.name == "cpo")  # marker-weighted signer
        rec = asyncio.run(run_one(task, method, "clean", seed, lambda s=seed: LLMLike(s), cfg))
        assert rec.error is None, rec.error
        assert rec.calls <= 12
        kinds.append(rec.detail["terminal_kind"])
        supported += bool(rec.blind_supported)
        correct += bool(rec.correct)
    assert kinds.count("fixed_point") >= 10, kinds  # converges within 3 cycles
    assert supported >= 9 and correct >= 9  # a supported majority answer is found and confirmed


def test_plain_simhash_does_not_converge_on_short_paraphrased_answers():
    """Documents the representation finding that motivated the marker-weighted signer."""
    from cpo.eval.baselines import CPOMethod
    from cpo.sketch import SimHashSigner

    task = "Maya buys 5 boxes of 12 pens and gives away 8. How many are left?"
    fixed = 0
    for seed in range(6):
        p = CountingProvider(LLMLike(seed), 12)
        r = asyncio.run(CPOMethod("full", signer=SimHashSigner(256)).run(task, p, roles_for("clean", 0.34)))
        fixed += r.detail["terminal_kind"] == "fixed_point"
    assert fixed <= 2


def test_marker_signer_behaviour():
    from cpo.sketch import MarkerWeightedSigner, SimHashSigner

    m = MarkerWeightedSigner(256, weight=8)
    a = m.sign("Reasoning one two three.\nAnswer: 52")
    b = m.sign("Completely different reasoning here.\nAnswer: 52")
    c = m.sign("Reasoning one two three.\nAnswer: 60")
    assert a.hamming(b) < a.hamming(c)  # agreement on the deliverable dominates
    assert m.sign("no marker at all") == SimHashSigner(256).sign("no marker at all")
    with pytest.raises(ValueError):
        MarkerWeightedSigner(60)


def test_history_locking_condition_produces_detectable_locks():
    """Debate preserves a wrong first-round majority; an independent blind pool catches it.
    The blind pool must be a *fresh* sample: a factory that reseeded identically would make
    the fresh specialists replay the run and hide every lock."""
    import itertools

    from cpo.eval.baselines import Debate

    task = Task(
        id="m",
        family="math",
        prompt="Maya buys 5 boxes of 12 pens and gives away 8. How many are left?",
        answer="52",
        grader="numeric",
    )
    cfg = HarnessConfig(budget=12, blind_draws=3, conditions=("history_locking",))
    counter = itertools.count(1000)
    wrong, unsupported, wrong_and_unsupported = 0, 0, 0
    for _ in range(15):
        factory = lambda: LLMLike(next(counter), wrong_rate=0.45)  # noqa: E731 - fresh seed per provider
        rec = asyncio.run(run_one(task, Debate(agents=3), "history_locking", 1, factory, cfg))
        assert rec.error is None
        wrong += rec.correct is False
        unsupported += rec.blind_supported is False
        wrong_and_unsupported += (rec.correct is False) and (rec.blind_supported is False)
    assert wrong >= 3, wrong  # the condition does produce locked-in wrong answers
    assert wrong_and_unsupported >= 2, (wrong, unsupported)  # and the blind pool flags them


def test_grading_uses_the_answer_line_first():
    exact = Task(id="e", family="f", prompt="p", answer=["W"], grader="exact")
    assert grade(exact, "Tungsten's symbol comes from wolfram.\nAnswer: W") is True
    assert grade(exact, "Tungsten's symbol comes from wolfram.\nAnswer: Wo") is False
    numeric = Task(id="n", family="f", prompt="p", answer="52", grader="numeric")
    assert grade(numeric, "5 times 12 is 60, minus 8.\nAnswer: 52") is True
    assert grade(numeric, "5 times 12 is 60, minus 8.\nAnswer: 60") is False


def test_cpo_reserves_reconfirmation_calls():
    from cpo.eval.baselines import CPOMethod

    full = CPOMethod("full")._config(12, 3)
    assert full.max_cycles == 3 and full.reconfirmation_rounds == 1  # 3 cycles + 1 blind round = 12
    no_recon = CPOMethod("reconfirmation")._config(12, 3)
    assert no_recon.max_cycles == 4 and no_recon.reconfirmation_rounds == 0
    assert CPOMethod("full")._config(6, 3).max_cycles == 1


def test_provider_config_accepts_temperature():
    from pydantic import SecretStr

    from cpo.providers import AnthropicMessagesConfig

    cfg = AnthropicMessagesConfig(model="m", api_key=SecretStr("k"), temperature=0.7)
    assert cfg.temperature == 0.7
    with pytest.raises(ValueError):
        AnthropicMessagesConfig(model="m", api_key=SecretStr("k"), temperature=3.0)


def test_multi_seed_runs_average_per_task_and_means_exclude_failures():
    recs = []
    for seed in (1, 2):
        recs.append(
            RunRecord(
                task_id="t1",
                family="f",
                method="cpo",
                condition="clean",
                seed=seed,
                answer_excerpt="a",
                correct=(seed == 1),
                blind_supported=(seed == 1),
                blind_distance=0.1,
                calls=9,
                budget=9,
                rounds=3,
                prompt_tokens=10,
                completion_tokens=10,
                elapsed_s=0.1,
            )
        )
    recs.append(
        RunRecord(
            task_id="t2",
            family="f",
            method="cpo",
            condition="clean",
            seed=1,
            answer_excerpt="",
            correct=None,
            blind_supported=None,
            blind_distance=None,
            calls=1,
            budget=9,
            rounds=0,
            prompt_tokens=0,
            completion_tokens=0,
            elapsed_s=0.1,
            error="ProviderError: boom",
        )
    )
    s = summarise(recs)["by_method_condition"]["cpo|clean"]
    assert s["runs"] == 3 and s["failures"] == 1 and s["graded"] == 2
    assert s["quality"] == pytest.approx(0.5) and s["mean_calls"] == pytest.approx(
        9.0
    )  # failures excluded from means
    from cpo.eval.metrics import MethodOutcome

    out = MethodOutcome(method="cpo")
    out.add_correct("t1", True)
    out.add_correct("t1", False)
    assert out.per_task_correct == {"t1": 0.5}  # seeds averaged, task remains the bootstrap unit


def test_rubric_tasks_are_excluded_from_lock_metric_but_keep_distance():
    task = Task(
        id="r", family="planning", prompt="Give two mitigations for pool exhaustion.", grader="rubric"
    )
    cfg = HarnessConfig(budget=8, blind_draws=2, conditions=("clean",))
    rec = asyncio.run(run_one(task, BestOfN(), "clean", 1, lambda: Fake(), cfg))
    assert rec.correct is None and rec.blind_supported is None and rec.blind_distance is not None
    skipped = asyncio.run(run_one(task, SelfConsistency(), "clean", 1, lambda: Fake(), cfg))
    assert skipped.error and "not_applicable" in skipped.error and skipped.calls == 0


def test_unknown_condition_is_rejected():
    with pytest.raises(ValueError):
        roles_for("adversarial", 0.34)


def test_apply_ratings_round_trip(tmp_path):
    from cpo.eval import apply_ratings

    rubric = RunRecord(
        task_id="r",
        family="planning",
        method="cpo",
        condition="clean",
        seed=1,
        answer_excerpt="plan",
        correct=None,
        blind_supported=None,
        blind_distance=0.3,
        calls=9,
        budget=9,
        rounds=2,
        prompt_tokens=1,
        completion_tokens=1,
        elapsed_s=0.1,
    )
    graded = RunRecord(**{**rubric.__dict__, "task_id": "m", "correct": True})
    sheet = [
        {"task_id": "r", "run": rubric.key(), "answer": "plan", "rating": [3, 2]},
        {"task_id": "x", "run": "missing|cpo|clean|1", "answer": "", "rating": None},
    ]
    rated = apply_ratings([rubric, graded], sheet, pass_threshold=2.0)
    assert (
        rated[0].correct is True and rated[1].correct is True and rubric.correct is None
    )  # originals untouched
    assert apply_ratings([rubric], sheet, pass_threshold=2.6)[0].correct is False


def test_cpo_prompt_matches_baseline_prompt_except_workspace_block():
    from cpo.eval.baselines import _role_prompt, cpo_specialist
    from cpo.models import OrchestrationRequest

    role = "Check the reasoning for errors."
    spec = cpo_specialist("critic", role, Fake())
    baseline = _role_prompt(role, "What is 2+2?")
    cpo_first_cycle = spec._prompt(OrchestrationRequest(input="What is 2+2?"), None)
    assert cpo_first_cycle == baseline  # first cycle: byte-identical prompts


def test_throttled_provider_caps_inflight():
    from cpo.eval.baselines import ThrottledProvider

    class Slow(Fake):
        inflight = 0
        peak = 0

        async def generate(self, prompt, *, request_id):
            Slow.inflight += 1
            Slow.peak = max(Slow.peak, Slow.inflight)
            await asyncio.sleep(0.01)
            Slow.inflight -= 1
            return await super().generate(prompt, request_id=request_id)

    t = ThrottledProvider(Slow(), max_inflight=2)

    async def burst():
        await asyncio.gather(*(t.generate("p", request_id=str(i)) for i in range(8)))

    asyncio.run(burst())
    assert Slow.peak <= 2


def test_answers_equivalent_is_grader_aware():
    from cpo.eval.tasks import answers_equivalent

    num = Task(id="n", family="math", prompt="p", answer="52", grader="numeric")
    assert answers_equivalent(num, "Working.\nAnswer: 52", "So the total is\nAnswer: 52 pens")
    assert not answers_equivalent(num, "Answer: 52", "Answer: 51")
    ex = Task(id="e", family="factual", prompt="p", answer=["W"], grader="exact")
    assert answers_equivalent(ex, "Answer: W", "reasoning\nAnswer: w") and not answers_equivalent(
        ex, "Answer: W", "Answer: Wo"
    )


def test_hard_math_generator_is_deterministic_and_loadable(tmp_path):
    import subprocess
    import sys as _sys

    out1, out2 = tmp_path / "a.jsonl", tmp_path / "b.jsonl"
    for out in (out1, out2):
        subprocess.run(
            [_sys.executable, "scripts/gen_hard_math.py", "--count", "20", "--seed", "3", "--out", str(out)],
            check=True,
            capture_output=True,
        )
    assert out1.read_bytes() == out2.read_bytes()
    tasks = load_tasks(out1)
    assert len(tasks) == 20 and all(t.grader == "numeric" and t.answer for t in tasks)
    assert all(b < 128 for b in out1.read_bytes())


def test_resume_dedupes_retries_and_redo_methods_discards(tmp_path):
    from cpo.eval import run_evaluation

    tasks = load_tasks(TASKS)[:2]
    cfg = HarnessConfig(budget=4, blind_draws=2, conditions=("clean",), concurrency=2)
    asyncio.run(run_evaluation(tasks, [SelfConsistency()], lambda: Fake(), cfg, tmp_path, resume=True))
    # forge a failed record for an existing run, as if an earlier attempt had errored
    lines = (tmp_path / "runs.jsonl").read_text().splitlines()
    first = json.loads(lines[0])
    failed = {**first, "error": "TimeoutError", "correct": None, "blind_supported": None}
    (tmp_path / "runs.jsonl").write_text(json.dumps(failed) + "\n" + "\n".join(lines) + "\n")
    s = asyncio.run(run_evaluation(tasks, [SelfConsistency()], lambda: Fake(), cfg, tmp_path, resume=True))
    assert (
        s["by_method_condition"]["self_consistency|clean"]["runs"] == 2
    )  # latest record per key, no inflation
    s2 = asyncio.run(
        run_evaluation(
            tasks,
            [SelfConsistency()],
            lambda: Fake(),
            cfg,
            tmp_path,
            resume=True,
            redo_methods=["self_consistency"],
        )
    )
    assert s2["by_method_condition"]["self_consistency|clean"]["runs"] == 2


def test_cpo_method_uses_evaluation_timeouts():
    from cpo.eval.baselines import CPOMethod

    cfg = CPOMethod("full")._config(12, 3)
    assert cfg.specialist_timeout_s >= 60 and cfg.request_timeout_s >= 300


def test_pool_shape_varies_specialist_count_at_fixed_budget():
    from cpo.config import CPOConfig
    from cpo.eval.baselines import CountingProvider, CPOMethod
    from cpo.eval.harness import roles_for
    from cpo.sketch import MarkerWeightedSigner

    base = CPOConfig(max_cycles=6, reconfirmation_rounds=0)
    roles = roles_for("clean", 0.34)
    for pool, cycles in [(12, 1), (6, 2), (4, 3), (2, 6)]:
        m = CPOMethod(
            "reconfirmation",
            config=base,
            signer=MarkerWeightedSigner(256),
            pool_size=pool,
            name=f"cpo_pool{pool}x{cycles}",
        )
        prov = CountingProvider(Fake(), 12)
        specs = m._make_specialists(prov, roles)
        cfg = m._config(12, len(specs))
        assert len(specs) == pool
        assert len({s.name for s in specs}) == pool  # unique names, orchestrator accepts them
        assert cfg.max_cycles == cycles  # budget split into the intended depth
        r = asyncio.run(m.run("What is 2 plus 50?", prov, roles))
        assert r.calls <= 12 and r.error is None


def test_judged_consensus_writer_picks_by_judge_and_falls_back():
    from cpo.focus_loop import ConsensusReport
    from cpo.models import Candidate, CandidateAssessment, SelectedCandidate
    from cpo.provider_specialist import JudgedConsensusWriter
    from cpo.sketch import Signature

    def sel(src, text):
        return SelectedCandidate(
            candidate=Candidate(source=src, content=text),
            assessment=CandidateAssessment(
                source=src,
                candidate_index=0,
                signature="00",
                resonance=0.9,
                binding=0.0,
                risk=0.0,
                weight=0.9,
            ),
        )

    selected = [sel("a", "wrong.\nAnswer: 60"), sel("b", "right.\nAnswer: 52")]
    report = ConsensusReport(Signature.of_text("x"), 0.5, 0)  # medoid would be candidate a

    class Judge(Fake):
        def __init__(self):
            super().__init__("right.\nAnswer: 52")

    out = asyncio.run(JudgedConsensusWriter(Judge()).write(selected, report, None, 1000))
    assert out.endswith("Answer: 52")  # judge's choice, not the medoid

    class Broken(Fake):
        async def generate(self, prompt, *, request_id):
            raise RuntimeError("down")

    out = asyncio.run(JudgedConsensusWriter(Broken()).write(selected, report, None, 1000))
    assert out.endswith("Answer: 60")  # fallback to medoid
    assert asyncio.run(JudgedConsensusWriter(Judge()).write(selected[:1], report, None, 1000)).endswith(
        "Answer: 60"
    )


def test_cpo_judged_reserves_judge_calls_within_budget():
    from cpo.eval.baselines import CPOMethod

    m = CPOMethod("full", judged=True, name="cpo_judged")
    cfg = m._config(12, 3)
    assert cfg.max_cycles == 2 and (3 + 1) * cfg.max_cycles + 3 * cfg.reconfirmation_rounds <= 12
    roles = roles_for("clean", 0.34)
    prov = CountingProvider(Fake(), 12)
    r = asyncio.run(m.run("What is 2 plus 50?", prov, roles))
    assert r.calls <= 12 and r.error is None


def test_drafting_mode_prompts_and_reductions():
    from cpo.eval.baselines import (
        ANSWER_FORMAT,
        DRAFT_FORMAT,
        Debate,
        _role_prompt,
        is_discrete,
        set_discrete,
    )

    set_discrete(False)
    try:
        assert not is_discrete()
        p = _role_prompt("role", "Design a rollback plan.")
        assert p.endswith(DRAFT_FORMAT) and "Answer:" not in p
        # debate in drafting mode reserves one call for a judge over the final round
        prov = CountingProvider(Fake("A complete plan."), budget=12)
        r = asyncio.run(Debate(agents=3).run("Design a rollback plan.", prov, roles_for("clean", 0.34)))
        assert r.detail.get("reduction") == "judge" and r.calls <= 12 and r.rounds == 3
    finally:
        set_discrete(True)
    assert _role_prompt("role", "2+2?").endswith(ANSWER_FORMAT)


def test_cpo_merge_uses_provider_writer_within_budget():
    from cpo.eval.baselines import CPOMethod

    m = CPOMethod("full", merge=True, name="cpo_merge")
    cfg = m._config(12, 3)
    assert (3 + 1) * cfg.max_cycles + 3 * cfg.reconfirmation_rounds <= 12
    prov = CountingProvider(Fake("Merged draft."), 12)
    r = asyncio.run(m.run("Design a rollback plan.", prov, roles_for("clean", 0.34)))
    assert r.error is None and r.calls <= 12 and r.answer


def _rubric_record(task_id: str, method: str) -> RunRecord:
    # A rubric task: graded later by rating, so correct is None; the lock metric is undefined by
    # design, so blind_supported is None while blind_distance is still recorded.
    return RunRecord(
        task_id=task_id,
        family="planning",
        method=method,
        condition="clean",
        seed=1,
        answer_excerpt="x" * 400,
        correct=None,
        blind_supported=None,
        blind_distance=0.3,
        calls=9,
        budget=12,
        rounds=3,
        prompt_tokens=10,
        completion_tokens=10,
        elapsed_s=0.1,
        answer_full="x" * 5000,
    )


def test_rubric_only_run_reports_h4_as_not_tested_not_refuted():
    records = [_rubric_record(f"p{i}", m) for i in range(5) for m in ("cpo", "best_of_n", "debate")]
    s = summarise(records)
    dec = s["preregistered_decision"]
    assert dec["comparisons_checked"] == 0
    assert dec["H4_supported"] is False
    assert dec["H4_status"] == "not_tested"
    assert "rubric" in dec["reason"]
    # a tested-and-refuted outcome must be labelled differently from an untested one
    tested = summarise(
        [
            RunRecord(
                task_id=f"t{i}",
                family="math",
                method=m,
                condition="clean",
                seed=1,
                answer_excerpt="a",
                correct=True,
                blind_supported=(m == "best_of_n"),  # cpo locks on every task, baseline never
                blind_distance=0.1,
                calls=9,
                budget=9,
                rounds=1,
                prompt_tokens=1,
                completion_tokens=1,
                elapsed_s=0.1,
            )
            for i in range(20)
            for m in ("cpo", "best_of_n")
        ]
    )
    assert tested["preregistered_decision"]["comparisons_checked"] == 1
    assert tested["preregistered_decision"]["H4_status"] == "not_supported"


def test_task_set_summary_flags_rubric_only_sets(tmp_path):
    from cpo.eval.harness import task_set_summary
    from cpo.eval.tasks import Task

    rubric = [Task(id=f"p{i}", family="planning", prompt="plan", answer="", grader="rubric") for i in range(3)]
    math = [Task(id=f"m{i}", family="math", prompt="2+2", answer="4", grader="numeric") for i in range(2)]
    assert task_set_summary(rubric)["h4_testable"] is False
    mixed = task_set_summary(rubric + math)
    assert mixed["h4_testable"] is True and mixed["discrete_graded"] == 2 and mixed["rubric_graded"] == 3


def test_rating_sheet_carries_the_full_answer_not_the_excerpt(tmp_path):
    # Regression for the 400-character rating sheet: raters must see the whole answer.
    import json as _json

    from cpo.eval.harness import RunRecord as _RR  # noqa: F401

    records = [_rubric_record("p1", "cpo")]
    sheet = [
        {"task_id": r.task_id, "run": r.key(), "answer": r.answer_full or r.answer_excerpt, "rating": None}
        for r in records
    ]
    (tmp_path / "rating_sheet.json").write_text(_json.dumps(sheet))
    loaded = _json.loads((tmp_path / "rating_sheet.json").read_text())
    assert len(loaded[0]["answer"]) == 5000


# --------------------------------------------------------------------------------------------
# 0.9.3 guard-rails: limits that are individually plausible and jointly wrong, truncation, p_sel
# --------------------------------------------------------------------------------------------


def test_preflight_rejects_a_per_run_timeout_below_the_worst_case():
    from cpo.eval.harness import HarnessConfig, preflight_limits

    # This is the 0.9.1 failure in miniature: 12 calls that may each take 180 s cannot fit in 300 s.
    bad = HarnessConfig(budget=12, blind_draws=3, per_run_timeout_s=300.0, call_timeout_s=180.0)
    problems = preflight_limits(bad)
    assert problems and any("per_run_timeout_s" in p for p in problems)

    good = HarnessConfig(budget=12, blind_draws=3, per_run_timeout_s=3000.0, call_timeout_s=180.0)
    assert preflight_limits(good) == []


def test_preflight_rejects_candidate_limit_smaller_than_the_model_can_emit():
    from cpo.eval.harness import HarnessConfig, preflight_limits

    cfg = HarnessConfig(max_output_tokens=8192, max_candidate_chars=4000)
    assert any("max_candidate_chars" in p for p in preflight_limits(cfg))


def test_run_evaluation_refuses_inconsistent_limits(tmp_path):
    from cpo.eval.harness import HarnessConfig, run_evaluation

    tasks = [Task(id="t1", family="math", prompt="2+2", answer="4", grader="numeric")]
    cfg = HarnessConfig(budget=12, blind_draws=3, per_run_timeout_s=60.0, call_timeout_s=180.0)
    with pytest.raises(ValueError, match="mutually inconsistent"):
        asyncio.run(run_evaluation(tasks, default_methods(), lambda: Fake(), cfg, tmp_path))


def test_anthropic_adapter_raises_on_max_tokens_truncation():
    import httpx
    from pydantic import SecretStr

    from cpo.providers import AnthropicMessagesConfig, AnthropicMessagesProvider, TruncatedOutput

    def handler(request):
        return httpx.Response(
            200,
            json={
                "content": [{"type": "text", "text": "The first mitigation is to"}],
                "stop_reason": "max_tokens",
                "usage": {"input_tokens": 10, "output_tokens": 64},
            },
            headers={"content-type": "application/json"},
        )

    client = httpx.AsyncClient(transport=httpx.MockTransport(handler))
    prov = AnthropicMessagesProvider(
        AnthropicMessagesConfig(model="m", api_key=SecretStr("k"), max_output_tokens=64),
        client=client,
    )
    # A truncated answer must never come back looking complete.
    with pytest.raises(TruncatedOutput):
        asyncio.run(prov.generate("write a long plan", request_id="r1"))
    asyncio.run(client.aclose())


def test_responses_api_truncation_guard():
    from cpo.providers.base import TruncatedOutput, raise_if_truncated

    with pytest.raises(TruncatedOutput):
        raise_if_truncated(
            {"status": "incomplete", "incomplete_details": {"reason": "max_output_tokens"}}, 512, "openai"
        )
    assert raise_if_truncated({"status": "completed"}, 512, "openai") == "completed"


def test_p_sel_is_measured_from_cycle_traces():
    from cpo.eval.harness import measure_selection_quality

    task = Task(id="m1", family="math", prompt="2+2", answer="4", grader="numeric")
    detail = {
        "cycles": [
            {  # pool has one right and two wrong; selection kept the two wrong ones
                "cycle": 1,
                "pool_texts": ["Answer: 4", "Answer: 5", "Answer: 6"],
                "selected_texts": ["Answer: 5", "Answer: 6"],
            }
        ]
    }
    q = measure_selection_quality(task, detail)
    assert q["p"] == pytest.approx(1 / 3, abs=1e-4)
    assert q["p_sel"] == 0.0
    assert q["p_sel_minus_p"] < 0  # error retention, the sign Proposition 1 predicts
    assert measure_selection_quality(
        Task(id="p1", family="planning", prompt="plan", answer="", grader="rubric"), detail
    ) is None


def test_summary_aggregates_selection_quality():
    recs = []
    for i in range(4):
        recs.append(
            RunRecord(
                task_id=f"t{i}", family="math", method="cpo", condition="clean", seed=1,
                answer_excerpt="a", correct=True, blind_supported=True, blind_distance=0.1,
                calls=9, budget=9, rounds=2, prompt_tokens=1, completion_tokens=1, elapsed_s=0.1,
                detail={"selection_quality": {
                    "pool_candidates": 6, "pool_correct": 3,
                    "selected_candidates": 4, "selected_correct": 1,
                }},
            )
        )
    sq = summarise(recs)["by_method_condition"]["cpo|clean"]["selection_quality"]
    assert sq["p"] == 0.5 and sq["p_sel"] == 0.25
    assert sq["selection_informative"] is False


def test_resume_refuses_a_changed_configuration_but_allows_new_seeds(tmp_path):
    from cpo.eval.harness import HarnessConfig, run_evaluation

    tasks = [Task(id=f"t{i}", family="math", prompt="2+2", answer="4", grader="numeric") for i in range(2)]
    methods = [m for m in default_methods() if m.name in {"cpo", "best_of_n"}]
    base = HarnessConfig(budget=9, conditions=("clean",), seeds=(1,))
    asyncio.run(run_evaluation(tasks, methods, lambda: Fake(), base, tmp_path, provenance={"model": "a"}))

    # adding a seed only adds record keys: allowed
    more = HarnessConfig(budget=9, conditions=("clean",), seeds=(1, 2))
    asyncio.run(run_evaluation(tasks, methods, lambda: Fake(), more, tmp_path, provenance={"model": "a"}))

    # a different model under the same keys would make records incomparable: refused
    with pytest.raises(ValueError, match="different configuration"):
        asyncio.run(run_evaluation(tasks, methods, lambda: Fake(), base, tmp_path, provenance={"model": "b"}))
    # so would a different budget
    with pytest.raises(ValueError, match="budget"):
        asyncio.run(
            run_evaluation(
                tasks, methods, lambda: Fake(), HarnessConfig(budget=12, conditions=("clean",)),
                tmp_path, provenance={"model": "a"},
            )
        )


def test_token_cap_stops_launching_runs(tmp_path):
    from cpo.eval.harness import HarnessConfig, run_evaluation

    tasks = [Task(id=f"t{i}", family="math", prompt="2+2", answer="4", grader="numeric") for i in range(6)]
    methods = [m for m in default_methods() if m.name == "best_of_n"]
    cfg = HarnessConfig(budget=9, conditions=("clean",), concurrency=1)
    s = asyncio.run(run_evaluation(tasks, methods, lambda: Fake(), cfg, tmp_path, max_total_tokens=1))
    assert s["runs_not_launched_by_token_cap"] >= 1


# --------------------------------------------------------------------------------------------
# 0.9.3 — fixes found by the offline replay, and the two convergence-gated methods
# --------------------------------------------------------------------------------------------
class _Scripted:
    """Returns pre-written answers in call order; judge calls get the given judge text."""

    provider_name = "scripted"

    def __init__(self, answers, judge_text="Answer: JUDGED"):
        self.answers, self.judge_text, self.i, self.prompts = list(answers), judge_text, 0, []

    async def generate(self, prompt, *, request_id):
        from cpo.providers.base import ProviderResult

        self.prompts.append((request_id, prompt))
        if "judge" in request_id:
            text = self.judge_text
        else:
            text = f"Working...\nAnswer: {self.answers[self.i]}"
            self.i += 1
        return ProviderResult(text=text, provider="scripted", model="m", request_id=request_id, usage={})


def test_answer_key_merges_formats_and_keeps_sign():
    from cpo.eval.tasks import answer_key

    # the same value written two ways must share one vote
    assert answer_key("Answer: 2,432.74", "numeric") == answer_key("Answer: 2432.74", "numeric")
    assert answer_key("Answer: $147.30", "numeric") == answer_key("Answer: 147.3", "numeric")
    # opposite signs must NOT share one (the old normalise() key merged them)
    assert answer_key("Answer: -0.88", "numeric") != answer_key("Answer: 0.88", "numeric")
    # non-numeric graders keep the previous behaviour
    assert answer_key("Answer: Paris", "exact") == answer_key("answer: paris!", "exact")


def test_final_answer_line_finds_an_indented_answer_like_the_grader():
    from cpo.eval.baselines import final_answer_line
    from cpo.eval.tasks import answer_line

    text = "Reasoning.\n   Answer: 42"
    assert final_answer_line(text) == answer_line(text) == "42"


def test_grader_context_is_isolated_between_concurrent_runs():
    from cpo.eval.baselines import current_grader, set_grader

    seen = {}

    async def run(name, grader):
        set_grader(grader)
        await asyncio.sleep(0.01)  # let the other run interleave
        seen[name] = current_grader()

    async def both():
        await asyncio.gather(run("a", "rubric"), run("b", "numeric"))

    asyncio.run(both())
    assert seen == {"a": "rubric", "b": "numeric"}


def test_self_consistency_no_longer_splits_one_value_across_vote_keys():
    from cpo.eval.baselines import set_grader

    async def go():
        set_grader("numeric")
        prov = CountingProvider(_Scripted(["2,432.74", "2432.74", "2432.74", "2,432.74", "99", "99", "99"]), 7)
        return await SelfConsistency().run("q", prov, {"a": "r"})

    run = asyncio.run(go())
    # four votes for 2432.74 in two spellings beat three for 99; the old key split them 2-2-3
    assert "2432.74" in run.answer.replace(",", "")


@pytest.mark.parametrize(
    "draws",
    [
        ["5", "5", "5", "7", "7", "7", "9", "9", "9"],  # unanimous first batch: stop at 3
        ["5", "7", "5", "5", "5", "7", "1", "2", "3"],  # reconfirmed after batch 2: stop at 6
        ["1", "2", "3", "4", "5", "6", "7", "8", "9"],  # never converges: all 9
        ["7", "5", "5", "7", "7", "1", "7", "7", "2"],
    ],
)
def test_adaptive_method_makes_the_same_decisions_as_the_replayed_rule(draws):
    """The live method must be the rule the replay evaluated, or the replay is not evidence for it."""
    import sys
    from pathlib import Path

    sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
    from offline_replay import d2_adaptive

    from cpo.eval.baselines import AdaptiveConsensus, set_grader
    from cpo.eval.tasks import answer_key

    async def go():
        set_grader("numeric")
        prov = CountingProvider(_Scripted(draws), 9)
        return await AdaptiveConsensus().run("q", prov, {"a": "r"}), prov.calls

    run, calls = asyncio.run(go())
    want_answer, want_used = d2_adaptive(draws)
    assert calls == want_used
    assert answer_key(run.answer, "numeric") == answer_key(f"Answer: {want_answer}", "numeric")


def test_gated_judge_skips_the_judge_when_converged_and_calls_it_on_the_whole_pool_otherwise():
    from cpo.eval.baselines import GatedJudge, set_grader

    async def go(draws):
        set_grader("numeric")
        inner = _Scripted(draws, judge_text="Picked [2].\nAnswer: 4")
        prov = CountingProvider(inner, 12)
        run = await GatedJudge().run("q", prov, {"a": "r"})
        return run, inner

    run, inner = asyncio.run(go(["5", "5", "5"] + ["x"] * 9))
    assert run.detail["converged"] and not run.detail["judge_called"]
    assert run.calls == 3  # converged on the first blind batch: 3 calls, not 12

    run, inner = asyncio.run(go([str(i) for i in range(1, 12)]))
    assert not run.detail["converged"] and run.detail["judge_called"]
    assert run.calls == 10  # 3 batches of 3 with one call reserved, then the judge
    judge_prompt_text = next(p for rid, p in inner.prompts if "judge" in rid)
    # the judge sees every candidate, not a pre-selected subset
    assert all(f"[{k}]" in judge_prompt_text for k in range(1, 10))
    assert run.answer.strip().endswith("4")


def test_lock_decomposition_separates_harmful_locks_from_false_alarms():
    def rec(i, correct, supported):
        return RunRecord(
            task_id=f"t{i}", family="math", method="m", condition="clean", seed=1, answer_excerpt="a",
            correct=correct, blind_supported=supported, blind_distance=0.1, calls=1, budget=1,
            rounds=1, prompt_tokens=1, completion_tokens=1, elapsed_s=0.1,
        )

    recs = [rec(0, False, False), rec(1, True, False), rec(2, True, True), rec(3, False, True)]
    ld = summarise(recs)["by_method_condition"]["m|clean"]["lock_decomposition"]
    assert ld["error_lock_rate"] == 0.25  # wrong and unsupported: the case H4 is about
    assert ld["false_alarm_rate"] == 0.25  # correct but unsupported: penalised by the raw lock rate


def test_every_method_declares_whether_it_selects_candidates():
    """Preflight checks p_sel only for selecting methods; a method that forgets to declare would be
    silently skipped, so every CPO-family method must say which it is."""
    for m in default_methods():
        if m.name.startswith("cpo"):
            assert hasattr(m, "selects_candidates"), m.name
    by = {m.name: getattr(m, "selects_candidates", None) for m in default_methods()}
    assert by["cpo"] is True and by["cpo_no_consensus"] is True
    assert by["cpo_adaptive"] is False and by["cpo_gated_judge"] is False


def test_not_applicable_rows_are_not_failures_in_a_mixed_task_file(tmp_path):
    """Regression: discrete-only methods on rubric tasks used to count as failures, be retried, and
    fail the preflight on any mixed-family task file (which Stage 2 of PROTOCOL_V2 requires)."""
    from cpo.eval.harness import HarnessConfig, run_evaluation

    tasks = [
        Task(id="m1", family="math", prompt="2+2", answer="4", grader="numeric"),
        Task(id="p1", family="planning", prompt="plan", answer="", grader="rubric"),
    ]
    methods = [m for m in default_methods() if m.name in {"best_of_n", "self_consistency", "cpo_adaptive"}]
    s = asyncio.run(run_evaluation(tasks, methods, lambda: Fake(), HarnessConfig(conditions=("clean",)), tmp_path))
    assert s["failures_by_method"] == {}
    assert s["not_applicable_runs"] == 2  # self_consistency and cpo_adaptive on the rubric task
    assert all(v["failures"] == 0 for v in s["by_method_condition"].values())
    # resuming does not re-plan the not-applicable rows
    s2 = asyncio.run(run_evaluation(tasks, methods, lambda: Fake(), HarnessConfig(conditions=("clean",)), tmp_path))
    assert s2["not_applicable_runs"] == 2


def test_paper_number_checker_parses_rows_behind_booktabs_rules():
    """Regression: a leading \\midrule once made the checker skip a whole table silently."""
    import sys
    from pathlib import Path

    sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
    from check_paper_numbers import cells, numbers, round_half_up

    assert cells("\\midrule\nclean & CPO & $\\mathbf{0.500}$")[0] == "clean"
    assert numbers("$\\mathbf{0.675}$ $[0.52,0.80]$")[0] == 0.675
    assert round_half_up(10.95, 1) == 11.0 and round_half_up(8.45, 1) == 8.5


def test_task_scripts_refuse_to_overwrite_evidence(tmp_path):
    """The runbook once pointed calibration at a name that collides with the paper's frozen task
    file; both task-writing scripts now refuse to overwrite an existing output without --force."""
    import sys
    from pathlib import Path

    sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
    import gen_hard_math

    existing = tmp_path / "frozen.jsonl"
    existing.write_text("original\n")
    with pytest.raises(SystemExit, match="refusing to overwrite"):
        gen_hard_math.main(["--count", "3", "--out", str(existing)])
    assert existing.read_text() == "original\n"
    gen_hard_math.main(["--count", "3", "--out", str(existing), "--force"])
    assert existing.read_text() != "original\n"


def test_truncation_sensitivity_reproduces_released_figures():
    """The output-ceiling audit of the live run is regenerated from the released records and its
    headline figures are the ones the paper's deviations appendix states."""
    import json
    import sys
    from pathlib import Path

    root = Path(__file__).resolve().parents[1]
    sys.path.insert(0, str(root / "scripts"))
    import truncation_sensitivity

    assert truncation_sensitivity.main() == 0
    r = json.loads((root / "eval" / "replay" / "truncation_sensitivity.json").read_text(encoding="utf-8"))
    assert (r["draws_without_answer_line"], r["self_consistency_draws"]) == (53, 960)
    assert r["heavily_affected_tasks"] == ["hmath-007", "hmath-039", "hmath-143"]
    assert all(v["failed_runs"] == 0 and v["dropped_specialist_candidates"] == 0
               for v in r["per_method"].values())
    q = r["quality"]
    for cond in ("clean", "history_locking"):
        gap = q[f"{cond}|best_of_n"]["excluding_heavy"] - q[f"{cond}|cpo"]["excluding_heavy"]
        assert gap > 0.1  # CPO still trails best-of-n with the affected tasks removed
