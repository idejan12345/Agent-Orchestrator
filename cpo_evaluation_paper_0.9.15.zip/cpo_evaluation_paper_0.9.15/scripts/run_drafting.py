"""Drafting families evaluation: planning + synthesis, rubric-rated.

    python scripts/run_drafting.py --provider anthropic --model claude-haiku-4-5-20251001 \
        --out eval/runs/drafting-haiku --yes

Takes the first N planning and N synthesis tasks from eval/tasks/main.jsonl, runs best_of_n,
debate, cpo (medoid), cpo_merge (model-merged consensus) and cpo_judged in the clean and
history-locking conditions at a 12-call budget.  Self-consistency is not applicable (no discrete
answer to vote on) and is omitted.  No blind test is run for rubric tasks.  Afterwards:

    python scripts/rate_with_model.py <out> --model claude-sonnet-5 --yes
    python scripts/apply_ratings.py <out> --threshold 2.0
"""

from __future__ import annotations

import argparse
import asyncio
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from cpo.eval import HarnessConfig, load_tasks, run_evaluation
from cpo.eval.baselines import BestOfN, CPOMethod, Debate, ThrottledProvider
from cpo.sketch import MarkerWeightedSigner


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Drafting families (planning, synthesis), rubric-rated")
    ap.add_argument("--provider", default="anthropic", choices=("anthropic", "openai"))
    ap.add_argument("--model", required=True)
    ap.add_argument("--api-key", default="")
    ap.add_argument("--tasks", default="eval/tasks/main.jsonl")
    ap.add_argument("--per-family", type=int, default=20)
    ap.add_argument("--out", required=True)
    ap.add_argument("--conditions", default="clean,history_locking")
    ap.add_argument("--concurrency", type=int, default=3)
    ap.add_argument("--max-inflight", type=int, default=4)
    ap.add_argument("--yes", action="store_true")
    a = ap.parse_args(argv)

    key = (
        a.api_key
        or os.environ.get("ANTHROPIC_API_KEY" if a.provider == "anthropic" else "OPENAI_API_KEY", "")
    ).strip()
    if not key:
        raise SystemExit("no API key")
    allt = load_tasks(a.tasks)
    tasks = [t for t in allt if t.family == "planning"][: a.per_family] + [
        t for t in allt if t.family == "synthesis"
    ][: a.per_family]
    print(
        f"{len(tasks)} rubric-graded drafting tasks. This script measures QUALITY ONLY (model/human "
        "rating afterwards); the history-locked convergence metric and H4 are not computed on rubric "
        "tasks -- use scripts/run_evaluation.py with the calibrated math set for H4."
    )
    signer = MarkerWeightedSigner(256)
    methods = [
        BestOfN(),
        Debate(agents=3),
        CPOMethod("full", signer=signer),
        CPOMethod("full", signer=signer, merge=True, name="cpo_merge"),
        CPOMethod("full", signer=signer, judged=True, name="cpo_judged"),
    ]
    cfg = HarnessConfig(
        budget=12,
        blind_draws=3,
        conditions=tuple(c.strip() for c in a.conditions.split(",") if c.strip()),
        seeds=(1,),
        concurrency=a.concurrency,
    )
    n = len(tasks) * len(methods) * len(cfg.conditions)
    print(
        f"{len(tasks)} drafting tasks x {len(methods)} methods x {len(cfg.conditions)} conditions = {n} runs; "
        f"up to {n * cfg.budget} provider calls (no blind test for rubric tasks)"
    )
    if not a.yes and input("proceed and spend on the API? [y/N] ").strip().lower() != "y":
        return 1

    from pydantic import SecretStr

    if a.provider == "anthropic":
        from cpo.providers import AnthropicMessagesConfig, AnthropicMessagesProvider

        shared = AnthropicMessagesProvider(
            AnthropicMessagesConfig(model=a.model, api_key=SecretStr(key), temperature=None)
        )
    else:
        from cpo.providers import OpenAIResponsesConfig, OpenAIResponsesProvider

        shared = OpenAIResponsesProvider(
            OpenAIResponsesConfig(model=a.model, api_key=SecretStr(key), temperature=0.7)
        )
    throttled = ThrottledProvider(shared, a.max_inflight)

    async def go():
        try:
            return await run_evaluation(tasks, methods, lambda: throttled, cfg, a.out, resume=True)
        finally:
            try:
                await shared.close()
            except Exception:
                pass

    summary = asyncio.run(go())
    fails = sum(v["failures"] for v in summary["by_method_condition"].values())
    print(f"\nruns complete; failures: {fails}; rating sheet: {a.out}/rating_sheet.json")
    print("next: python scripts/rate_with_model.py", a.out, "--model claude-sonnet-5 --yes")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
