"""Fill the pool-shape table in paper/evaluation/cpo_evaluation.tex from a completed sweep.

    python scripts/fill_poolshape.py eval/runs/poolshape-haiku

Replaces the [--] placeholders in section "Pool shape at a fixed budget" with the measured
quality, lock rate and mean calls for each shape, and prints a suggested reading sentence
(you write the final wording).  Idempotent: re-running with new data overwrites the numbers.
"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

SHAPES = [(12, 1, "a"), (6, 2, "b"), (4, 3, "c"), (3, 4, "d"), (2, 6, "e")]
PAPER = Path("paper/evaluation/cpo_evaluation.tex")


def cell(v, key):
    x = v.get(key)
    return "n/a" if x is None else (f"{x:.3f}" if key != "mean_calls" else f"{x:.1f}")


def main(argv=None) -> int:
    run_dir = Path((argv or sys.argv[1:])[0])
    summary = json.loads((run_dir / "summary.json").read_text(encoding="utf-8"))
    by = summary["by_method_condition"]
    s = PAPER.read_text(encoding="utf-8")
    rows = {}
    for p, c, tag in SHAPES:
        v = by.get(f"cpo_pool{p}x{c}|clean")
        if not v:
            print(f"missing cpo_pool{p}x{c}|clean in summary; is the run complete?")
            return 1
        s = s.replace(f"\\POOL{tag}Q_FILLED", "")  # no-op guard
        s = re.sub(
            rf"(\$?{p}\\times{c}\$?[^\n]*?&[^&]*&) \[--\] & \[--\] & \[--\]",
            rf"\1 ${cell(v, 'quality')}$ & ${cell(v, 'history_locked_convergence')}$ & ${cell(v, 'mean_calls')}$",
            s,
        )
        rows[(p, c)] = (v["quality"], v["history_locked_convergence"], v["mean_calls"])

    widest = rows[(12, 1)][0]
    narrowest = rows[(2, 6)][0]
    trend = (
        "rises toward best-of-n as the pool widens"
        if widest and narrowest and widest - narrowest > 0.05
        else "is flat across pool shapes"
    )
    reading = (
        f"Measured trend: quality {trend} "
        f"(pool 12x1: {widest}, pool 2x6: {narrowest}; best-of-n 0.675). "
        "Replace the bracketed reading in the paper with the appropriate sentence."
    )
    s = s.replace("\\POOLREADING", "")  # in case still present
    PAPER.write_text(s, encoding="utf-8")
    remaining = s.count("[--]")
    print(f"filled the pool-shape table; {remaining} placeholders remain")
    print(reading)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
