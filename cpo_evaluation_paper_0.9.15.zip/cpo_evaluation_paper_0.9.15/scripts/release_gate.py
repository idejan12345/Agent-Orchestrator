"""Fail-closed GO/NO-GO evaluator.  Missing evidence is a NO-GO, never a pass."""

import json
from pathlib import Path

from cpo.version import __version__

root = Path("release/evidence")


def get(name):
    p = root / name
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else None


tests = get("tests_summary.json")
census = get("census_report.json")
plane = get("plane_report.json")
security = get("security_scan.json")
load = get("load_test.json")
external = get("external_security_summary.json")
staging = get("staging_validation.json")
providers = get("provider_smoke_summary.json")
container = get("container_scan.json")
clean_tree = get("clean_tree.json")
preflight = get("preflight.json")
paper_numbers = get("paper_numbers.json")
theory_numbers = get("theory_numbers.json")

gates = {
    "unit_tests": bool(tests and tests.get("failed") == 0 and tests.get("passed", 0) > 0),
    "static_analysis_clean": bool(tests and tests.get("ruff") == "clean" and tests.get("mypy") == "clean"),
    "census_reproduces_structure": bool(
        census and all(s["fixed_point_rate"] >= 0.9 for s in census["seeds"])
    ),
    "plane_dissociation": bool(
        plane
        and plane["archetypes"]["dreamer"]["M_star"]["value"]
        > plane["archetypes"]["animal"]["M_star"]["value"]
        and plane["archetypes"]["animal"]["W"]["value"] > plane["archetypes"]["dreamer"]["W"]["value"]
    ),
    "local_security_scan": bool(security and security.get("high", 1) == 0),
    "sast_and_dependency_audit": bool(
        external and external.get("passed") and external.get("sbom", {}).get("generated")
    ),
    "release_tree_clean": bool(clean_tree and clean_tree.get("clean")),
    "evaluation_preflight": bool(preflight and preflight.get("passed")),
    "paper_numbers_match_data": bool(paper_numbers and paper_numbers.get("passed")),
    "theory_paper_numbers_match_data": bool(theory_numbers and theory_numbers.get("passed")),
    "local_load_test": bool(load and load.get("status_counts", {}).get("200") == load.get("requests")),
    "staging_validation_http": bool(staging and staging.get("passed")),
    # require credentials or infrastructure this environment does not have
    "provider_smoke_tests": bool(providers and providers.get("passed")),
    "container_image_scan": bool(container and container.get("passed") and container.get("critical", 1) == 0),
}
local = [k for k in gates if k not in {"provider_smoke_tests", "container_image_scan"}]
report = {
    "release_candidate": __version__,
    "gates": gates,
    "decision": "GO" if all(gates.values()) else "NO-GO",
    "missing_or_failed": [k for k, v in gates.items() if not v],
    "local_gates_passed": all(gates[k] for k in local),
    "note": "provider smoke tests need API credentials; the container scan needs an image registry and scanner",
}
(root / "go_no_go.json").write_text(json.dumps(report, indent=2))
print(json.dumps(report, indent=2))
raise SystemExit(0 if report["decision"] == "GO" else 3)
