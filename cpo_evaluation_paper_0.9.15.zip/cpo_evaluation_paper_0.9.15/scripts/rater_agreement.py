"""Agreement between the two human raters and between humans and the model rater.

    python scripts/rater_agreement.py eval/runs/drafting-haiku

Reads human_rating_subsample.csv (rater1_score, rater2_score filled in) and rating_sheet.json.
Reports exact agreement, Cohen's kappa (human-human) and weighted agreement human-vs-model.
"""

from __future__ import annotations

import csv
import json
import sys
from collections import Counter
from pathlib import Path


def kappa(a, b):
    n = len(a)
    po = sum(x == y for x, y in zip(a, b, strict=True)) / n
    ca, cb = Counter(a), Counter(b)
    pe = sum(ca[k] / n * cb[k] / n for k in set(ca) | set(cb))
    return (po - pe) / (1 - pe) if pe < 1 else 1.0, po


def main(argv=None) -> int:
    d = Path((argv or sys.argv[1:])[0])
    rows = list(csv.DictReader((d / "human_rating_subsample.csv").open(encoding="utf-8")))
    rows = [r for r in rows if r["rater1_score"].strip() and r["rater2_score"].strip()]
    if not rows:
        print("no completed human ratings found")
        return 1
    model = {
        e["run"]: e.get("rating") for e in json.loads((d / "rating_sheet.json").read_text(encoding="utf-8"))
    }
    key = json.loads((d / "human_subsample_key.json").read_text(encoding="utf-8"))
    for r in rows:
        r["run"] = key[r["item"]]
    h1 = [int(r["rater1_score"]) for r in rows]
    h2 = [int(r["rater2_score"]) for r in rows]
    k, po = kappa(h1, h2)
    print(f"{len(rows)} items rated by both humans; exact agreement {po:.2f}; Cohen's kappa {k:.3f}")
    hm = [
        (round((a + b) / 2), model[r["run"]])
        for a, b, r in zip(h1, h2, rows, strict=True)
        if model.get(r["run"]) is not None
    ]
    if hm:
        within1 = sum(abs(x - y) <= 1 for x, y in hm) / len(hm)
        exact = sum(x == y for x, y in hm) / len(hm)
        mean_diff = sum(y - x for x, y in hm) / len(hm)
        print(
            f"human-mean vs model rater on {len(hm)} items: exact {exact:.2f}, within one point {within1:.2f}, "
            f"model minus human mean {mean_diff:+.2f}"
        )
    print("(report kappa and the human-vs-model agreement in the paper; re-rate if kappa < 0.6)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
