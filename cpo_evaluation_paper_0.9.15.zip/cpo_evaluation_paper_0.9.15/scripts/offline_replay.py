"""Offline replay of aggregation and stopping rules on real, already-paid-for model draws.

Rules and predictions are fixed in docs/OFFLINE_REPLAY_PREREG.md, written before this script was
run.  No model is called.  See that file for what replay can and cannot test.

    python scripts/offline_replay.py [--orderings 2000] [--seed 1]
"""

from __future__ import annotations

import argparse
import json
import random
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from cpo.eval.tasks import load_tasks  # noqa: E402

RUNS = ROOT / "eval" / "runs" / "main-minimal-haiku" / "runs.jsonl"
TASKS = ROOT / "eval" / "tasks" / "main_math_calibrated_v2.jsonl"
OUT = ROOT / "eval" / "replay" / "offline_replay.json"
BLIND = 3
BUDGET = 9


def plurality(xs: list[str]) -> str:
    return Counter(xs).most_common(1)[0][0]  # ties: first appearance (random under the ordering)


# ------------------------------------------------------------------------------------- rules
def sc(draws: list[str], n: int) -> tuple[str, int]:
    return plurality(draws[:n]), n


def cpo_emul(draws: list[str], rng: random.Random, cycles: int = 3) -> tuple[str, int]:
    incumbent: str | None = None
    used = 0
    for _ in range(cycles):
        pool = draws[used : used + 3]
        used += 3
        if incumbent is None:
            selected = rng.sample(pool, 2)  # reference is the request: uninformative
        else:
            same = [x for x in pool if x == incumbent]
            other = [x for x in pool if x != incumbent]
            rng.shuffle(other)
            selected = (same + other)[:2]
        if selected[0] == selected[1]:
            incumbent = selected[0]
        elif incumbent is None:
            incumbent = rng.choice(selected)  # tie, nothing to retain: medoid of two is arbitrary
        # else: tie retains the incumbent
    assert incumbent is not None
    return incumbent, used


def d2_adaptive(draws: list[str]) -> tuple[str, int]:
    seen: list[str] = []
    previous: str | None = None
    for t in range(BUDGET // 3):
        batch = draws[3 * t : 3 * t + 3]
        seen += batch
        current = plurality(seen)
        if t == 0 and len(set(batch)) == 1:
            return current, len(seen)
        if t >= 1 and current == previous and sum(1 for x in batch if x == current) >= 2:
            return current, len(seen)
        previous = current
    return plurality(seen), len(seen)


def d3_acting_reconfirmation(draws: list[str], rng: random.Random) -> tuple[str, int]:
    converged, _ = cpo_emul(draws[:6], rng, cycles=2)
    blind = draws[6:9]
    if converged in blind:
        return converged, 9
    return plurality(draws[:9]), 9


# ------------------------------------------------------------------------------------- data
def load_pools() -> list[dict]:
    tasks = {t.id: t for t in load_tasks(str(TASKS))}
    pools = []
    for line in RUNS.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        r = json.loads(line)
        if r["method"] != "self_consistency" or r.get("error"):
            continue
        votes = r["detail"]["votes"]
        draws = [k for k, c in votes.items() for _ in range(c)]
        if len(draws) != 12:
            continue
        t = tasks[r["task_id"]]
        if str(t.answer).strip().startswith("-"):
            continue  # sign is unrecoverable from normalised keys: excluded (prereg amendment)
        target = float(str(t.answer).replace(",", ""))
        pools.append(
            {
                "task": r["task_id"],
                "condition": r["condition"],
                "draws": draws,
                "target": target,
                "recorded_correct": r["correct"],
            }
        )
    return pools


def key_value(key: str) -> float | None:
    """Recover the number from a normalised vote key.

    ``normalise`` maps both the decimal point and the thousands comma to a space and drops the sign,
    so "2,432.74" arrives as "2 432 74" and "147.30" as "147 30".  Read the trailing run of digit
    tokens: a final token of at most two digits is the fractional part; earlier tokens of exactly
    three digits are thousands groups.  Sign cannot be recovered, which is why tasks with negative
    answers are excluded (see the amendment in docs/OFFLINE_REPLAY_PREREG.md).
    """
    toks = key.split()
    if "answer" in toks:
        # prose key (the method gave no clean answer line): parse only what follows the last
        # "answer", which is where the instructed answer line ends up
        toks = toks[len(toks) - 1 - toks[::-1].index("answer") + 1 :]
    elif not all(t.isdigit() for t in toks):
        toks = toks[-2:]  # prose with no marker: at most "<int> <cents>"; no thousands joining
    run: list[str] = []
    for tok in reversed(toks):
        if tok.isdigit():
            run.insert(0, tok)
        else:
            break
    if not run:
        return None
    frac = ""
    if len(run) >= 2 and len(run[-1]) <= 2:
        frac = run.pop()
    while len(run) >= 2 and len(run[-1]) != 3:
        run = run[-1:]  # an earlier token that is not a thousands group is not part of this number
    whole = "".join(run)
    return float(f"{whole}.{frac}" if frac else whole)


def correct(answer: str, target: float) -> bool:
    v = key_value(answer)
    return v is not None and abs(v - target) <= 1e-6 * max(1.0, abs(target))


# ------------------------------------------------------------------------------------- main
def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--orderings", type=int, default=2000)
    ap.add_argument("--seed", type=int, default=1)
    a = ap.parse_args(argv)
    rng = random.Random(a.seed)
    pools = load_pools()

    # sanity: the key-level grader must agree with the harness on the recorded SC winners
    untied = []
    for p in pools:
        top = Counter(p["draws"]).most_common(2)
        if len(top) == 1 or top[0][1] > top[1][1]:
            untied.append(p)
    agree = sum(correct(Counter(p["draws"]).most_common(1)[0][0], p["target"]) == p["recorded_correct"] for p in untied)
    if agree != len(untied):
        raise SystemExit(f"grader validation failed: {agree}/{len(untied)} untied pools agree; results would be invalid")

    rules = [f"SC-{n}" for n in range(3, BUDGET + 1)] + ["CPO-emul", "D2-adaptive", "D3-acting", "Oracle-9"]
    acc = {k: 0.0 for k in rules}
    lock = {k: 0.0 for k in rules}
    cost = {k: 0.0 for k in rules}
    n = 0
    # exploratory analyses (not preregistered), on the same orderings so every number in the paper
    # is regenerated by this script rather than by ad-hoc code
    strata: dict[int, list[int]] = {}  # D2 stop point -> [runs, plurality correct, correct present]
    gated = {"acc": 0, "lock": 0, "correct": 0, "correct_locked": 0}
    for p in pools:
        for _ in range(a.orderings):
            d = p["draws"][:]
            rng.shuffle(d)
            method_draws, blind = d[:BUDGET], d[BUDGET:]
            results = {f"SC-{k}": sc(method_draws, k) for k in range(3, BUDGET + 1)}
            results["CPO-emul"] = cpo_emul(method_draws, rng)
            results["D2-adaptive"] = d2_adaptive(method_draws)
            results["D3-acting"] = d3_acting_reconfirmation(method_draws, rng)
            for k, (ans, used) in results.items():
                acc[k] += correct(ans, p["target"])
                lock[k] += ans not in blind
                cost[k] += used
            acc["Oracle-9"] += any(correct(x, p["target"]) for x in method_draws)
            ans, used = results["D2-adaptive"]
            st = strata.setdefault(used, [0, 0, 0])
            st[0] += 1
            st[1] += correct(ans, p["target"])
            st[2] += any(correct(x, p["target"]) for x in method_draws[:used])
            if used == BUDGET:  # did not converge: a perfect judge picks a correct candidate if any
                right = [x for x in method_draws if correct(x, p["target"])]
                ans = right[0] if right else ans
            ok = correct(ans, p["target"])
            locked = ans not in blind
            gated["acc"] += ok
            gated["lock"] += locked
            gated["correct"] += ok
            gated["correct_locked"] += ok and locked
            cost["Oracle-9"] += BUDGET
            n += 1
    table = {
        k: {
            "accuracy": round(acc[k] / n, 4),
            "lock_rate": round(lock[k] / n, 4) if k != "Oracle-9" else None,
            "mean_draws": round(cost[k] / n, 3),
        }
        for k in rules
    }

    def sc_at(m: float) -> float:
        lo, hi = int(m), min(BUDGET, int(m) + 1)
        lo = max(3, lo)
        if lo == hi:
            return table[f"SC-{lo}"]["accuracy"]
        w = m - lo
        return (1 - w) * table[f"SC-{lo}"]["accuracy"] + w * table[f"SC-{hi}"]["accuracy"]

    m = table["D2-adaptive"]["mean_draws"]
    verdict = {
        "R1_cpo_emul_below_sc9": table["CPO-emul"]["accuracy"] < table["SC-9"]["accuracy"],
        "R2_adaptive_vs_sc_at_matched_cost": {
            "D2_accuracy": table["D2-adaptive"]["accuracy"],
            "SC_at_same_mean_cost": round(sc_at(m), 4),
            "mean_cost": m,
            "holds": table["D2-adaptive"]["accuracy"] >= sc_at(m)
            and table["SC-9"]["accuracy"] - table["D2-adaptive"]["accuracy"] <= 0.02
            and m < BUDGET,
        },
        "R3_acting_reconfirmation_lowers_lock": table["D3-acting"]["lock_rate"] < table["CPO-emul"]["lock_rate"]
        and table["D3-acting"]["accuracy"] >= table["CPO-emul"]["accuracy"],
        "R4_nothing_beats_sc9_by_more_than_0.02": all(
            table[k]["accuracy"] <= table["SC-9"]["accuracy"] + 0.02
            for k in rules
            if k != "Oracle-9"
        ),
    }
    total_err = sum(v[0] - v[1] for v in strata.values())
    nonconv = strata.get(BUDGET, [0, 0, 0])
    # vote-key defect: one numeric value split across several stored keys
    split = 0
    sc12_lossy = sc12_value = 0
    for p in pools:
        lossy = Counter(p["draws"])
        byval: Counter = Counter()
        for k, c in lossy.items():
            v = key_value(k)
            byval[round(v, 6) if v is not None else k] += c
        split += len(byval) < len(lossy)
        sc12_lossy += correct(lossy.most_common(1)[0][0], p["target"])
        w = byval.most_common(1)[0][0]
        sc12_value += isinstance(w, float) and abs(w - p["target"]) <= 1e-6 * max(1.0, abs(p["target"]))
    exploratory = {
        "label": "EXPLORATORY - not preregistered",
        "d2_stop_strata": {
            str(k): {
                "share": round(v[0] / n, 4),
                "plurality_accuracy": round(v[1] / v[0], 4),
                "correct_present": round(v[2] / v[0], 4),
            }
            for k, v in sorted(strata.items())
        },
        "share_of_errors_in_nonconverged_runs": round((nonconv[0] - nonconv[1]) / total_err, 4) if total_err else None,
        "perfect_gated_judge": {
            "accuracy": round(gated["acc"] / n, 4),
            "lock_rate": round(gated["lock"] / n, 4),
            "share_of_correct_answers_flagged_locked": round(gated["correct_locked"] / gated["correct"], 4),
            "judge_called_on_share": round(nonconv[0] / n, 4),
        },
        "vote_key_defect": {
            "pools_with_one_value_split_across_keys": split,
            "sc12_accuracy_lossy_keys": round(sc12_lossy / len(pools), 4),
            "sc12_accuracy_value_aware_keys": round(sc12_value / len(pools), 4),
        },
    }
    report = {
        "pools": len(pools),
        "orderings_per_pool": a.orderings,
        "grader_agrees_with_recorded_sc_winner_untied_pools": f"{agree}/{len(untied)}",
        "excluded_tasks_negative_answer": 9,
        "table": table,
        "verdict": verdict,
        "exploratory": exploratory,
    }
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
