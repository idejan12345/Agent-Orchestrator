"""Fold blind human ratings into an evaluation and recompute the summary.

    python scripts/apply_ratings.py eval/runs/main-mid --threshold 2.0

Reads <dir>/runs.jsonl and <dir>/rating_sheet.json (with the `rating` fields filled in as a
number or a list of numbers per rater on the 0-3 scale), writes <dir>/runs_rated.jsonl and
<dir>/summary_rated.json.  The original files are left untouched.
"""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import asdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from cpo.eval import apply_ratings, summarise
from cpo.eval.harness import RunRecord


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("run_dir")
    ap.add_argument(
        "--threshold",
        type=float,
        default=2.0,
        help="mean rating at or above which a rubric answer counts as correct",
    )
    a = ap.parse_args(argv)
    d = Path(a.run_dir)
    records = [
        RunRecord(**json.loads(line))
        for line in (d / "runs.jsonl").read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    sheet = json.loads((d / "rating_sheet.json").read_text(encoding="utf-8"))
    rated = apply_ratings(records, sheet, pass_threshold=a.threshold)
    newly = sum(
        1
        for before, after in zip(records, rated, strict=True)
        if before.correct is None and after.correct is not None
    )
    unrated = sum(1 for e in sheet if e.get("rating") is None)
    (d / "runs_rated.jsonl").write_text("".join(json.dumps(asdict(r)) + "\n" for r in rated))
    summary = summarise(rated)
    (d / "summary_rated.json").write_text(json.dumps(summary, indent=2, default=str))
    print(f"{newly} rubric answers graded from ratings; {unrated} sheet entries still unrated")
    print(json.dumps(summary["preregistered_decision"], indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
