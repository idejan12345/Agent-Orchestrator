"""Credentialed provider smoke test.

    export ANTHROPIC_API_KEY=... ANTHROPIC_MODEL=...
    PYTHONPATH=src python scripts/provider_smoke_test.py anthropic

Sends one short request, verifies the reply, and records the result WITHOUT any credential
in release/evidence/provider_smoke_summary.json (the file the release gate reads).  Run it once
per provider you intend to use; results accumulate per provider in the same summary.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import time
from pathlib import Path

from cpo.providers import (
    AnthropicMessagesConfig,
    AnthropicMessagesProvider,
    AzureResponsesConfig,
    AzureResponsesProvider,
    OpenAIResponsesConfig,
    OpenAIResponsesProvider,
)


def build(provider: str):
    if provider == "openai":
        return OpenAIResponsesProvider(
            OpenAIResponsesConfig(
                model=os.environ["OPENAI_MODEL"], api_key=os.environ["OPENAI_API_KEY"], max_output_tokens=64
            )
        )
    if provider == "azure":
        kwargs: dict = {
            "model": os.environ["AZURE_OPENAI_DEPLOYMENT"],
            "endpoint": os.environ["AZURE_OPENAI_ENDPOINT"],
            "max_output_tokens": 64,
        }
        if os.environ.get("AZURE_OPENAI_API_KEY"):
            kwargs["api_key"] = os.environ["AZURE_OPENAI_API_KEY"]
        else:
            kwargs["bearer_token"] = os.environ["AZURE_OPENAI_AUTH_TOKEN"]
        return AzureResponsesProvider(AzureResponsesConfig(**kwargs))
    return AnthropicMessagesProvider(
        AnthropicMessagesConfig(
            model=os.environ["ANTHROPIC_MODEL"], api_key=os.environ["ANTHROPIC_API_KEY"], max_output_tokens=64
        )
    )


async def main() -> int:
    parser = argparse.ArgumentParser(description="Credentialed provider smoke test (writes release evidence)")
    parser.add_argument("provider", choices=["openai", "azure", "anthropic"])
    parser.add_argument("--output", default="release/evidence/provider_smoke_summary.json")
    args = parser.parse_args()
    try:
        p = build(args.provider)
    except KeyError as exc:
        print(f"missing environment variable {exc}")
        return 2
    started = time.perf_counter()
    result_row: dict = {"provider": args.provider, "passed": False, "credentials_logged": False}
    try:
        result = await p.generate(
            "Return exactly: CPO_PROVIDER_SMOKE_OK", request_id=f"smoke-{int(time.time())}"
        )
        result_row.update(
            {
                "model": result.model,
                "provider_request_id": result.request_id,
                "elapsed_s": round(time.perf_counter() - started, 3),
                "text_match": "CPO_PROVIDER_SMOKE_OK" in result.text,
                "usage": dict(result.usage),
            }
        )
        result_row["passed"] = bool(result_row["text_match"])
        if not result_row["passed"]:
            result_row["error"] = "unexpected provider output"
    except Exception as exc:
        result_row["error"] = f"{type(exc).__name__}: {str(exc)[:200]}"
    finally:
        await p.close()

    path = Path(args.output)
    path.parent.mkdir(parents=True, exist_ok=True)
    summary: dict = {"providers": {}, "passed": False}
    if path.exists():
        try:
            summary = json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            pass
    summary.setdefault("providers", {})[args.provider] = result_row
    summary["passed"] = all(r.get("passed") for r in summary["providers"].values())
    summary["note"] = "one request per provider; no credential is written to this file"
    path.write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary, indent=2))
    return 0 if result_row["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
