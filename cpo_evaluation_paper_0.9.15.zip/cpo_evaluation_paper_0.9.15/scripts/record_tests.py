"""Record the test, lint and type-check outcome as release evidence."""

import json
import re
import subprocess
import sys
from pathlib import Path


def sh(cmd):
    return subprocess.run(
        cmd, capture_output=True, text=True, env={"PYTHONPATH": "src", "PATH": "/usr/bin:/usr/local/bin:/bin"}
    )  # nosec B603


t = sh([sys.executable, "-m", "pytest", "-q", "-o", "addopts=", "-W", "ignore"])
line = t.stdout.strip().splitlines()[-1] if t.stdout.strip() else ""
passed = int(m.group(1)) if (m := re.search(r"(\d+) passed", line)) else 0
failed = int(m.group(1)) if (m := re.search(r"(\d+) failed", line)) else 0
ruff = sh(["ruff", "check", "src", "tests", "scripts", "examples"])
mypy = sh([sys.executable, "-m", "mypy", "src/cpo"])
summary = {
    "passed": passed,
    "failed": failed,
    "pytest_line": line,
    "ruff": "clean" if ruff.returncode == 0 else "findings",
    "mypy": "clean" if mypy.returncode == 0 else "findings",
    "python": sys.version.split()[0],
}
Path("release/evidence/tests_summary.json").write_text(json.dumps(summary, indent=2))
Path("release/evidence/tests_output.txt").write_text(t.stdout)
print(json.dumps(summary, indent=2))
