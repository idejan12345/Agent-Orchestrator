"""How much did the 2048-token output ceiling touch the paper's live run, and does it matter?

The minimal-profile run (eval/runs/main-minimal-haiku) was executed before 0.9.3 made truncation
detectable: every call ran at the then-default max_output_tokens=2048 and stop_reason was not
recorded, so a call cut off at the ceiling was graded as a complete answer. Per-call texts were not
stored either. What the records do allow:

  * Self-consistency stores the vote key of each of its twelve draws. A draw that never reached an
    ``Answer:`` line has a prose key (it contains letters) instead of a number. That is the
    operational proxy for "cut off before answering"; it cannot distinguish truncation from a
    formatting failure, so it is an upper bound on truncation among those draws.
  * Every run stores completion tokens and calls, so mean tokens per call can be compared across
    arms: an arm whose calls ran longer would be exposed to the ceiling more often. The recorded
    tokens include the three blind-test draws, which the recorded call count does not, so the
    divisor is calls + BLIND_DRAWS.
  * Failures and dropped specialist candidates are recorded per run.

A task is "heavily affected" when at least a quarter of its 24 self-consistency draws (12 per
condition) have no answer line. The sensitivity analysis recomputes quality without those tasks.

    python scripts/truncation_sensitivity.py   # writes eval/replay/truncation_sensitivity.json
"""

from __future__ import annotations

import json
import re
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RUNS = ROOT / "eval" / "runs" / "main-minimal-haiku" / "runs.jsonl"
OUT = ROOT / "eval" / "replay" / "truncation_sensitivity.json"
METHODS = ["best_of_n", "self_consistency", "debate", "cpo"]
CONDITIONS = ["clean", "history_locking"]
HEAVY_SHARE = 0.25
BLIND_DRAWS = 3  # the run's blind support test; its tokens are in the record, its calls are not


def latest_records(path: Path) -> list[dict]:
    """One record per run; a retried run's later record supersedes the earlier one."""
    by_key: dict[tuple, dict] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.strip():
            r = json.loads(line)
            by_key[(r["task_id"], r["method"], r["condition"], r["seed"])] = r
    return list(by_key.values())


def is_failure(r: dict) -> bool:
    return r.get("error") not in (None, "None", "")


def main() -> int:
    rs = latest_records(RUNS)
    tasks = sorted({r["task_id"] for r in rs})

    no_answer: Counter[str] = Counter()
    draws: Counter[str] = Counter()
    for r in rs:
        if r["method"] != "self_consistency":
            continue
        for key, n in r["detail"]["votes"].items():
            draws[r["task_id"]] += n
            if re.search(r"[a-z]", key):
                no_answer[r["task_id"]] += n
    heavy = sorted(t for t in tasks if no_answer[t] >= HEAVY_SHARE * draws[t])
    kept = [t for t in tasks if t not in heavy]

    per_method: dict[str, dict] = {}
    by_method: dict[str, list[dict]] = defaultdict(list)
    for r in rs:
        by_method[r["method"]].append(r)
    for m, runs in sorted(by_method.items()):
        per_call = [int(r["completion_tokens"]) / (int(r["calls"]) + BLIND_DRAWS) for r in runs]
        per_method[m] = {
            "runs": len(runs),
            "failed_runs": sum(map(is_failure, runs)),
            "dropped_specialist_candidates": sum(
                int((r.get("detail") or {}).get("specialist_failures_total") or 0) for r in runs
            ),
            "mean_completion_tokens_per_call": round(sum(per_call) / len(per_call), 1),
        }

    def quality(method: str, condition: str, subset: list[str]) -> float:
        s = set(subset)
        sel = [r for r in rs if r["method"] == method and r["condition"] == condition and r["task_id"] in s]
        return sum(str(r["correct"]) == "True" for r in sel) / len(sel)

    sensitivity = {
        f"{c}|{m}": {"all_tasks": quality(m, c, tasks), "excluding_heavy": quality(m, c, kept)}
        for c in CONDITIONS
        for m in METHODS
    }
    report = {
        "source": str(RUNS.relative_to(ROOT)),
        "max_output_tokens_in_run": 2048,
        "self_consistency_draws": sum(draws.values()),
        "draws_without_answer_line": sum(no_answer.values()),
        "tasks_with_any_such_draw": sum(1 for t in tasks if no_answer[t]),
        "heavy_share_threshold": HEAVY_SHARE,
        "heavily_affected_tasks": heavy,
        "tasks_total": len(tasks),
        "tasks_kept": len(kept),
        "per_method": per_method,
        "quality": sensitivity,
    }
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(
        f"{report['draws_without_answer_line']}/{report['self_consistency_draws']} self-consistency draws "
        f"without an answer line; heavily affected: {', '.join(heavy)}"
    )
    for k, v in sensitivity.items():
        print(f"  {k:32s} all={v['all_tasks']:.3f}  excl={v['excluding_heavy']:.3f}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
