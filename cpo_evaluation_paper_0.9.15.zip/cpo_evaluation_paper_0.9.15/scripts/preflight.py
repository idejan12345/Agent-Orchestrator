"""Verify-before-spend gate: everything that can fail for free, before anything costs money.

    python scripts/preflight.py --tasks eval/tasks/main_math_calibrated_v2.jsonl --budget 12 \
        --methods best_of_n,self_consistency,debate,cpo,cpo_no_consensus,cpo_no_reconfirmation

It runs, in order:

  1. the unit tests;
  2. the limit preflight for the exact HarnessConfig the paid run will use;
  3. a mock dry run of the exact command, on the exact task file;
  4. assertions on the dry-run summary that the paid run would otherwise fail silently on --
     every run completed, the hypothesis is actually testable on this task file, CPO-vs-baseline
     comparisons were formed, and the p_sel instrumentation produced numbers.

Only after this passes is a `--limit 3` smoke on the real provider worth doing.  The 0.9.1
drafting run would have failed check 4 (`H4_status: not_tested`) for nothing.
"""

from __future__ import annotations

import argparse
import json
import subprocess  # nosec B404 - fixed argv, no shell
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from cpo.eval import HarnessConfig, load_tasks  # noqa: E402
from cpo.eval.harness import preflight_limits, task_set_summary  # noqa: E402

EVIDENCE = ROOT / "release" / "evidence" / "preflight.json"


def _run(argv: list[str]) -> tuple[int, str]:
    proc = subprocess.run(  # nosec B603 - fixed argv, no shell
        argv, cwd=ROOT, capture_output=True, text=True, check=False
    )
    return proc.returncode, (proc.stdout + proc.stderr)


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Verify-before-spend preflight")
    ap.add_argument("--tasks", required=True)
    ap.add_argument("--budget", type=int, default=12)
    ap.add_argument("--blind-draws", type=int, default=3)
    ap.add_argument("--call-timeout", type=float, default=180.0)
    ap.add_argument("--max-output-tokens", type=int, default=8192)
    ap.add_argument("--methods", default="")
    ap.add_argument("--conditions", default="clean,history_locking")
    ap.add_argument("--dry-tasks", type=int, default=6, help="tasks to use for the mock dry run")
    ap.add_argument("--skip-tests", action="store_true")
    a = ap.parse_args(argv)

    checks: list[dict] = []

    def record(name: str, ok: bool, detail: str) -> None:
        checks.append({"check": name, "passed": bool(ok), "detail": detail})
        print(f"[{'PASS' if ok else 'FAIL'}] {name}: {detail}")

    # 1 -------------------------------------------------------------- unit tests
    if a.skip_tests:
        record("unit_tests", True, "skipped by request")
    else:
        code, out = _run([sys.executable, "-m", "pytest", "-q", "-o", "addopts="])
        line = next((ln for ln in out.splitlines()[::-1] if "passed" in ln or "failed" in ln), "")
        record("unit_tests", code == 0, line.strip() or f"exit {code}")

    # 2 ------------------------------------------------------------ limit sanity
    cfg = HarnessConfig(
        budget=a.budget,
        blind_draws=a.blind_draws,
        call_timeout_s=a.call_timeout,
        max_output_tokens=a.max_output_tokens,
        conditions=tuple(c.strip() for c in a.conditions.split(",") if c.strip()),
    )
    problems = preflight_limits(cfg)
    record(
        "limits_consistent",
        not problems,
        "; ".join(problems)
        if problems
        else f"per-run {cfg.per_run_timeout_s:.0f}s >= worst case {cfg.worst_case_run_seconds():.0f}s",
    )

    # 3 ------------------------------------------------- task file can test what you think
    ts = task_set_summary(load_tasks(a.tasks))
    record(
        "task_file_can_test_h4",
        ts["h4_testable"],
        f"{ts['tasks']} tasks, {ts['discrete_graded']} discrete-graded, families {ts['families']}"
        + ("" if ts["h4_testable"] else " -- rubric-only files cannot test H4"),
    )

    # 4 ------------------------------------------------------------- mock dry run
    with tempfile.TemporaryDirectory() as tmp:
        argv_dry = [
            sys.executable, "scripts/run_evaluation.py",
            "--provider", "mock", "--tasks", a.tasks, "--out", tmp, "--yes",
            "--budget", str(a.budget), "--blind-draws", str(a.blind_draws),
            "--limit", str(a.dry_tasks), "--conditions", a.conditions,
            "--call-timeout", str(a.call_timeout),
            "--max-output-tokens", str(a.max_output_tokens),
        ]
        if a.methods:
            argv_dry += ["--methods", a.methods]
        code, out = _run(argv_dry)
        record("mock_dry_run", code == 0, f"exit {code}" + ("" if code == 0 else f": {out[-400:]}"))
        summary_path = Path(tmp) / "summary.json"
        if not summary_path.exists():
            record("dry_run_summary", False, "no summary.json produced")
        else:
            s = json.loads(summary_path.read_text())
            dec = s.get("preregistered_decision", {})
            status = dec.get("H4_status")
            record(
                "hypothesis_is_testable",
                status != "not_tested",
                f"H4_status={status}, comparisons_checked={dec.get('comparisons_checked')}"
                + (f" -- {dec.get('reason', '')}" if status == "not_tested" else ""),
            )
            cells = s.get("by_method_condition", {})
            failures = sum(c.get("failures", 0) for c in cells.values())
            record("no_run_failures", failures == 0, f"{failures} failed run(s) in the dry run")
            # Only methods that discard candidates before deciding have a p_sel; the adaptive and
            # gated methods keep the whole pool by design.  Each method declares which it is, so the
            # check does not guess from names.
            selecting = set(s.get("selecting_methods", []))
            sel_cells = [v for k, v in cells.items() if k.split("|")[0] in selecting]
            with_psel = [c for c in sel_cells if c.get("selection_quality")]
            record(
                "p_sel_instrumented",
                bool(sel_cells) and len(with_psel) == len(sel_cells),
                f"{len(with_psel)}/{len(sel_cells)} cells of selecting methods carry p_sel"
                + ("" if with_psel else " -- Stage 1 of PROTOCOL_V2 needs this"),
            )

    ok = all(c["passed"] for c in checks)
    EVIDENCE.parent.mkdir(parents=True, exist_ok=True)
    EVIDENCE.write_text(json.dumps({"passed": ok, "checks": checks}, indent=2), encoding="utf-8")
    print("\n" + ("PREFLIGHT PASSED — a --limit 3 smoke on the real provider is the next step."
                  if ok else "PREFLIGHT FAILED — do not spend. Fix the checks above."))
    return 0 if ok else 5


if __name__ == "__main__":
    raise SystemExit(main())
