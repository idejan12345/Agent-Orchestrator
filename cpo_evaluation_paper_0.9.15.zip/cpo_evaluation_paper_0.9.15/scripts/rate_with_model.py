"""Blind model rating of rubric answers, plus a human-validation subsample.

    python scripts/rate_with_model.py eval/runs/drafting-haiku --provider anthropic \
        --model claude-sonnet-5 --human-subsample 0.25 --yes

For every entry in <dir>/rating_sheet.json, a rater model (which must differ from the specialist
model) scores the answer 0-3 against eval/RUBRIC.md, seeing the task prompt and the answer but
NOT the method name.  Scores are written into the sheet's `rating` field.  A random subsample
(default 25%) is exported to <dir>/human_rating_subsample.csv for two human raters; run
scripts/rater_agreement.py afterwards to report agreement between humans and the model rater.

Then: python scripts/apply_ratings.py <dir> --threshold 2.0
"""

from __future__ import annotations

import argparse
import asyncio
import csv
import json
import os
import random
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from cpo.eval.baselines import ThrottledProvider
from cpo.eval.tasks import load_tasks


def build(kind: str, model: str, api_key: str):
    from pydantic import SecretStr

    if kind == "anthropic":
        from cpo.providers import AnthropicMessagesConfig, AnthropicMessagesProvider

        return AnthropicMessagesProvider(
            AnthropicMessagesConfig(
                model=model,
                api_key=SecretStr(api_key),
                temperature=None,
                max_output_tokens=2048,
                timeout_s=180.0,
            )
        )
    from cpo.providers import OpenAIResponsesConfig, OpenAIResponsesProvider

    return OpenAIResponsesProvider(
        OpenAIResponsesConfig(
            model=model,
            api_key=SecretStr(api_key),
            temperature=0.0,
            max_output_tokens=2048,
            timeout_s=180.0,
        )
    )


RATER_PROMPT = """You are grading an answer to a technical question against a fixed rubric. You do not know which system produced the answer.

Rubric:
{rubric}

Question:
{question}

Answer to grade:
{answer}

Reply with one sentence of justification and then, on the last line, exactly: Score: <digit>   where <digit> is 0, 1, 2 or 3. Do not use markdown formatting. The answer you are grading is complete as shown; do not assume it was truncated."""


async def main_async(a) -> int:
    d = Path(a.run_dir)
    sheet = json.loads((d / "rating_sheet.json").read_text(encoding="utf-8"))

    def save() -> None:
        tmp = d / "rating_sheet.json.tmp"
        tmp.write_text(json.dumps(sheet, indent=2), encoding="utf-8")
        tmp.replace(d / "rating_sheet.json")  # atomic: never a half-written sheet
    rubric = Path("eval/RUBRIC.md").read_text(encoding="utf-8")
    tasks = {t.id: t for t in load_tasks(a.tasks)}
    todo = [e for e in sheet if e.get("rating") is None]
    print(f"{len(sheet)} rubric answers; {len(todo)} unrated; rater model {a.model}")
    if not a.yes and input("proceed and spend on the API? [y/N] ").strip().lower() != "y":
        return 1
    key = a.api_key or os.environ.get(
        "ANTHROPIC_API_KEY" if a.provider == "anthropic" else "OPENAI_API_KEY", ""
    )
    if not key:
        raise SystemExit("no API key")
    shared = build(a.provider, a.model, key)
    prov = ThrottledProvider(shared, a.max_inflight)
    sem = asyncio.Semaphore(a.concurrency)
    done = 0

    async def rate(entry):
        nonlocal done
        task = tasks.get(entry["task_id"])
        if task is None:
            return
        prompt = RATER_PROMPT.format(rubric=rubric, question=task.prompt, answer=entry["answer"])
        async with sem:
            try:
                r = await prov.generate(prompt, request_id=f"rate-{entry['run']}")
                m = re.search(r"Score\W{0,6}([0-3])\b", r.text)
                how = "explicit"
                if not m:
                    # A bare trailing digit is a weaker signal (it could be the end of a sentence);
                    # accept it, but mark it so it can be audited or excluded.
                    m = re.search(r"\b([0-3])\s*(?:/\s*3)?\s*$", r.text.strip())
                    how = "fallback"
                entry["rating"] = int(m.group(1)) if m else None
                entry["rating_parse"] = how if m else "unparsed"
                entry["rater_note"] = r.text.strip()[:300]
                entry["rater_model"] = a.model
            except Exception as exc:
                entry["rater_error"] = str(exc)[:160]
        done += 1
        if done % 25 == 0:
            print(f"  {done}/{len(todo)} rated")
            save()  # checkpoint: an interruption must not lose ratings already paid for

    try:
        await asyncio.gather(*(rate(e) for e in todo))
    finally:
        save()  # always, including on Ctrl-C or a provider failure
        try:
            await shared.close()
        except Exception:
            pass
    rated = sum(1 for e in sheet if e.get("rating") is not None)
    fallback = sum(1 for e in sheet if e.get("rating_parse") == "fallback")
    print(
        f"rated {rated}/{len(sheet)}; failures {sum(1 for e in sheet if e.get('rater_error'))}; "
        f"{fallback} parsed by the weaker trailing-digit fallback (audit these)"
    )

    # human-validation subsample, shuffled, method hidden
    rng = random.Random(a.seed)  # nosec B311 - sampling
    sample = rng.sample(sheet, max(1, int(len(sheet) * a.human_subsample)))
    rng.shuffle(sample)
    # The run key embeds the method name, so the CSV carries only an item number; the mapping
    # item -> run goes to a separate key file that raters must not see.
    with (d / "human_rating_subsample.csv").open("w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["item", "question", "answer", "rater1_score", "rater2_score"])
        for i, e in enumerate(sample, 1):
            t = tasks.get(e["task_id"])
            w.writerow([i, t.prompt if t else "", e["answer"], "", ""])
    (d / "human_subsample_key.json").write_text(
        json.dumps({str(i): e["run"] for i, e in enumerate(sample, 1)}, indent=2), encoding="utf-8"
    )
    print(
        f"human subsample: {len(sample)} items -> {d / 'human_rating_subsample.csv'} (fill rater1_score, rater2_score)"
    )
    print(f"item->run key (keep away from raters): {d / 'human_subsample_key.json'}")
    return 0


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Blind model rating of rubric answers")
    ap.add_argument("run_dir")
    ap.add_argument("--tasks", default="eval/tasks/main.jsonl")
    ap.add_argument("--provider", default="anthropic", choices=("anthropic", "openai"))
    ap.add_argument("--model", required=True, help="rater model; must differ from the specialist model")
    ap.add_argument("--api-key", default="")
    ap.add_argument("--human-subsample", type=float, default=0.25)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--concurrency", type=int, default=3)
    ap.add_argument("--max-inflight", type=int, default=4)
    ap.add_argument("--yes", action="store_true")
    return asyncio.run(main_async(ap.parse_args(argv)))


if __name__ == "__main__":
    raise SystemExit(main())
