"""Pool-shape sweep at a fixed call budget (paper section "Pool shape at fixed budget").

Spends the same 12-call budget as breadth (a large pool decided in few cycles) or depth (a small
pool iterated over many cycles), to test whether CPO's quality moves toward best-of-n as the pool
widens.  Each configuration is one CPO variant; the budget is held constant so the comparison is
call-for-call.

    python scripts/run_poolshape.py --provider anthropic --model claude-haiku-4-5-20251001 \
        --tasks eval/tasks/main_math_calibrated_v2.jsonl --out eval/runs/poolshape-haiku --yes

Configurations (budget 12, blind reconfirmation off so the whole budget is candidates):
    pool 12 x 1 cycle   (pure breadth)
    pool  6 x 2 cycles
    pool  4 x 3 cycles
    pool  3 x 4 cycles
    pool  2 x 6 cycles  (near-pure depth)
"""

from __future__ import annotations

import argparse
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from cpo.config import CPOConfig
from cpo.eval import HarnessConfig, load_tasks, run_evaluation
from cpo.eval.baselines import CPOMethod
from cpo.sketch import MarkerWeightedSigner

SHAPES = [(12, 1), (6, 2), (4, 3), (3, 4), (2, 6)]


def build_factory(kind: str, model: str, api_key: str, max_inflight: int):
    from pydantic import SecretStr

    from cpo.eval.baselines import ThrottledProvider

    if kind == "anthropic":
        from cpo.providers import AnthropicMessagesConfig, AnthropicMessagesProvider

        shared = AnthropicMessagesProvider(
            AnthropicMessagesConfig(model=model, api_key=SecretStr(api_key), temperature=None)
        )
    elif kind == "openai":
        from cpo.providers import OpenAIResponsesConfig, OpenAIResponsesProvider

        shared = OpenAIResponsesProvider(
            OpenAIResponsesConfig(model=model, api_key=SecretStr(api_key), temperature=0.7)
        )
    else:
        raise SystemExit(f"unsupported provider {kind!r}")
    throttled = ThrottledProvider(shared, max_inflight)
    return (lambda: throttled), shared


def main(argv=None) -> int:
    import os

    ap = argparse.ArgumentParser(description="Pool-shape sweep at fixed budget")
    ap.add_argument("--provider", default="anthropic", choices=("anthropic", "openai"))
    ap.add_argument("--model", required=True)
    ap.add_argument("--api-key", default="")
    ap.add_argument("--tasks", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--budget", type=int, default=12)
    ap.add_argument("--conditions", default="clean")
    ap.add_argument("--concurrency", type=int, default=3)
    ap.add_argument("--max-inflight", type=int, default=4)
    ap.add_argument("--yes", action="store_true")
    ap.add_argument(
        "--decisive",
        action="store_true",
        help="run only the decisive test: pool 11, judge over the whole pool, selection disabled",
    )
    a = ap.parse_args(argv)

    key = (
        a.api_key
        or os.environ.get("ANTHROPIC_API_KEY" if a.provider == "anthropic" else "OPENAI_API_KEY", "")
    ).strip()
    if not key:
        raise SystemExit("no API key: use --api-key or set the provider's environment variable")

    tasks = load_tasks(a.tasks)
    signer = MarkerWeightedSigner(256)
    # blind reconfirmation off so the entire budget is spent on candidates, isolating pool shape
    base = CPOConfig(max_cycles=max(c for _, c in SHAPES), reconfirmation_rounds=0)
    methods = [
        CPOMethod("reconfirmation", config=base, signer=signer, pool_size=p, name=f"cpo_pool{p}x{c}")
        for p, c in SHAPES
    ]
    if a.decisive:
        # The decisive test (paper, "Pool shape at a fixed budget"): whole pool judged, selection off.
        # phi=1 selects every candidate, so the judge sees all of them; one cycle; no reconfirmation.
        methods = [
            CPOMethod(
                "reconfirmation",
                config=CPOConfig(
                    max_cycles=1,
                    reconfirmation_rounds=0,
                    phi=1.0,
                    k_min=1,
                    k_max=64,
                    occupancy_control_enabled=False,
                ),
                signer=signer,
                pool_size=11,
                judged=True,
                name="cpo_pool11x1_judged_nosel",
            )
        ]
    cfg = HarnessConfig(
        budget=a.budget,
        blind_draws=3,
        conditions=tuple(c.strip() for c in a.conditions.split(",") if c.strip()),
        seeds=(1,),
        concurrency=a.concurrency,
    )
    n = len(tasks) * len(methods) * len(cfg.conditions)
    print(
        f"{len(tasks)} tasks x {len(methods)} pool shapes x {len(cfg.conditions)} conditions = {n} runs; "
        f"up to {n * (a.budget + cfg.blind_draws)} provider calls"
    )
    for m in methods:
        print(f"  {m.name}")
    if not a.yes and input("proceed and spend on the API? [y/N] ").strip().lower() != "y":
        return 1

    factory, shared = build_factory(a.provider, a.model, key, a.max_inflight)

    async def go():
        try:
            return await run_evaluation(tasks, methods, factory, cfg, a.out, resume=True)
        finally:
            try:
                await shared.close()
            except Exception:
                pass

    summary = asyncio.run(go())
    print("\nquality and lock rate by pool shape (wider pool = more breadth):")
    names = [m.name for m in methods]
    for name in names:
        for cond in cfg.conditions:
            v = summary["by_method_condition"].get(f"{name}|{cond}")
            if v:
                q = v["quality"]
                lk = v["history_locked_convergence"]
                print(
                    f"  {name:26s} [{cond:15s}] q={q if q is None else round(q, 3)} "
                    f"lock={lk if lk is None else round(lk, 3)} calls={round(v['mean_calls'], 1)} "
                    f"fail={v['failures']}"
                )
    print(f"\nwritten to {a.out}/summary.json")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
