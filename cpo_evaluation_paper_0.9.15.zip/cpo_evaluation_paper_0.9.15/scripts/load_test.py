from __future__ import annotations

import asyncio
import hashlib
import hmac
import json
import math
import statistics
import time
from pathlib import Path

import httpx

from cpo import api
from cpo.gateway import InMemoryQuotaManager

TOTAL = 500
CONCURRENCY = 25
SECRET = "load-secret"


def percentile(values, p):
    values = sorted(values)
    i = min(len(values) - 1, max(0, math.ceil(p * len(values)) - 1))
    return values[i]


def signed(body, principal, timestamp):
    canonical = "\n".join(
        [principal, str(timestamp), "POST", "/v1/orchestrate", hashlib.sha256(body).hexdigest()]
    )
    return hmac.new(SECRET.encode(), canonical.encode(), hashlib.sha256).hexdigest()


async def main():
    api.identity.secret = SECRET
    api.identity._seen.clear()
    api.quotas = InMemoryQuotaManager(
        units_per_minute=1_000_000, burst=10_000, max_concurrent=CONCURRENCY + 5
    )
    transport = httpx.ASGITransport(app=api.app)
    sem = asyncio.Semaphore(CONCURRENCY)
    latencies = []
    statuses = {}
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:

        async def one(i):
            body = json.dumps(
                {"input": f"Summarize pilot item {i}", "max_cycles": 2}, separators=(",", ":")
            ).encode()
            principal = f"load{i % 10}"
            timestamp = int(time.time())
            headers = {
                "content-type": "application/json",
                "x-cpo-principal": principal,
                "x-cpo-timestamp": str(timestamp),
                "x-cpo-signature": signed(body, principal, timestamp),
                "x-cpo-roles": "user",
            }
            async with sem:
                started = time.perf_counter()
                r = await client.post("/v1/orchestrate", content=body, headers=headers)
                latencies.append((time.perf_counter() - started) * 1000)
                statuses[r.status_code] = statuses.get(r.status_code, 0) + 1

        started = time.perf_counter()
        await asyncio.gather(*(one(i) for i in range(TOTAL)))
        elapsed = time.perf_counter() - started
    report = {
        "kind": "local_in_process_asgi",
        "requests": TOTAL,
        "concurrency": CONCURRENCY,
        "elapsed_s": elapsed,
        "throughput_rps": TOTAL / elapsed,
        "status_counts": statuses,
        "latency_ms": {
            "min": min(latencies),
            "mean": statistics.mean(latencies),
            "p50": percentile(latencies, 0.5),
            "p95": percentile(latencies, 0.95),
            "p99": percentile(latencies, 0.99),
            "max": max(latencies),
        },
        "limitations": [
            "echo specialists only",
            "no external provider latency",
            "single process",
            "in-process ASGI transport",
        ],
    }
    Path("reports/load_test.json").write_text(json.dumps(report, indent=2))
    print(json.dumps(report, indent=2))
    if statuses.get(200) != TOTAL:
        raise SystemExit(1)


asyncio.run(main())
