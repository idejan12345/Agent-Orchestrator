"""Automated pilot: smoke test → dry run → real pilot → inspection report.

    python scripts/run_pilot.py --provider anthropic --model claude-sonnet-5 --api-key sk-ant-...

Everything before the real pilot costs nothing.  The real pilot uses 12 tasks,
all 8 methods, 3 conditions = 288 runs, up to ~4 300 provider calls.
Writes a human-readable report to eval/runs/pilot-<model>/PILOT_REPORT.txt
and prints it to the screen.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
import time
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))


# ------------------------------------------------------------------ helpers --


def section(title: str) -> None:
    print()
    print("=" * 60)
    print(f"  {title}")
    print("=" * 60)


def ok(msg: str) -> None:
    print(f"  [OK]  {msg}")


def warn(msg: str) -> None:
    print(f"  [!!]  {msg}")


def fail(msg: str) -> None:
    print(f"  [XX]  {msg}")


def stop(msg: str) -> None:
    fail(msg)
    print()
    print("Pilot stopped.  Fix the issue above and re-run.")
    sys.exit(1)


# ------------------------------------------------------------------ steps ---


def step_smoke(
    provider: str,
    model: str,
    api_key: str,
    openai_key: str,
    azure_endpoint: str,
    azure_key: str,
    azure_deployment: str,
) -> None:
    section("Step 1 of 4: provider smoke test (1 API call)")

    # Set env vars so the smoke script picks them up
    if provider == "anthropic":
        os.environ["ANTHROPIC_API_KEY"] = api_key
        os.environ["ANTHROPIC_MODEL"] = model
    elif provider == "openai":
        os.environ["OPENAI_API_KEY"] = openai_key or api_key
        os.environ["OPENAI_MODEL"] = model
    elif provider == "azure":
        os.environ["AZURE_OPENAI_API_KEY"] = azure_key or api_key
        os.environ["AZURE_OPENAI_ENDPOINT"] = azure_endpoint
        os.environ["AZURE_OPENAI_DEPLOYMENT"] = azure_deployment or model

    import subprocess

    result = subprocess.run(
        [sys.executable, "scripts/provider_smoke_test.py", provider],
        capture_output=True,
        text=True,
    )
    try:
        report = json.loads(result.stdout)
    except json.JSONDecodeError:
        stop(f"Smoke test produced no JSON output.\n{result.stdout}\n{result.stderr}")

    prov = report.get("providers", {}).get(provider, {})
    if not prov.get("passed"):
        error = prov.get("error", "unknown error")
        if "401" in error:
            stop("Provider rejected the API key (HTTP 401). Check --api-key and try again.")
        if "404" in error:
            stop(f"Model not found (HTTP 404). Check --model and try again.\n  Got: {error}")
        stop(f"Smoke test failed: {error}")

    ok(f"Provider: {prov.get('provider')}  model: {prov.get('model')}")
    ok(f"Latency: {prov.get('elapsed_s', 0):.2f}s  tokens: {prov.get('usage', {})}")


def step_dryrun() -> None:
    section("Step 2 of 4: dry run — full pipeline, zero cost")

    from cpo.eval import HarnessConfig, default_methods, load_tasks, run_evaluation
    from cpo.providers.base import ProviderResult

    class MockProvider:
        provider_name = "mock"

        async def generate(self, prompt, *, request_id):
            await asyncio.sleep(0)
            question = ""
            for block in prompt.split("\n\n"):
                if block.startswith("Question:"):
                    question = block[9:].strip()
            digits = [c for c in question if c.isdigit()]
            answer = digits[-1] if digits else "unknown"
            return ProviderResult(
                f"Working through it.\nAnswer: {answer}",
                "mock",
                "mock",
                request_id,
                {"input_tokens": 10, "output_tokens": 5},
            )

        async def readiness(self):
            return True, "mock"

        async def close(self):
            return None

    tasks = load_tasks("eval/tasks/main.jsonl")[:4]
    methods = default_methods()
    cfg = HarnessConfig(budget=12, blind_draws=2, conditions=("clean",), concurrency=4)
    # Use a temp folder so dry-run records never appear in the pilot output
    import tempfile

    out = Path(tempfile.mkdtemp(prefix="cpo-dryrun-"))
    out.mkdir(parents=True, exist_ok=True)

    summary = asyncio.run(run_evaluation(tasks, methods, lambda: MockProvider(), cfg, out, resume=False))
    failures = sum(v["failures"] for v in summary["by_method_condition"].values())
    methods_found = sorted({k.split("|")[0] for k in summary["by_method_condition"]})

    if failures:
        stop(f"Dry run had {failures} failures. Something is wrong with the harness setup.")
    ok(f"Dry run completed: {len(tasks)} tasks x {len(methods_found)} methods, 0 failures")
    ok(f"Methods: {methods_found}")
    import shutil

    shutil.rmtree(out, ignore_errors=True)


def step_pilot(
    provider: str, model: str, api_key: str, concurrency: int, max_inflight: int, out_dir: Path
) -> dict:
    section("Step 3 of 4: real pilot — 12 tasks, all methods and conditions")
    print(f"  Provider: {provider}  model: {model}")
    print(f"  Output:   {out_dir}")
    print()

    # Quick pre-flight: one real generation call to catch 400s before the full run
    print("  Pre-flight: sending one test generation...")
    try:
        if provider == "anthropic":
            from pydantic import SecretStr

            from cpo.providers import AnthropicMessagesConfig, AnthropicMessagesProvider

            test_p = AnthropicMessagesProvider(
                AnthropicMessagesConfig(model=model, api_key=SecretStr(api_key), temperature=None)
            )
        elif provider == "openai":
            from pydantic import SecretStr

            from cpo.providers import OpenAIResponsesConfig, OpenAIResponsesProvider

            test_p = OpenAIResponsesProvider(
                OpenAIResponsesConfig(model=model, api_key=SecretStr(api_key), temperature=0.7)
            )
        else:
            test_p = None
        if test_p:

            async def preflight_call():
                try:
                    return await test_p.generate(
                        "You are a helpful assistant. Reply with exactly: PREFLIGHT_OK",
                        request_id="preflight",
                    )
                finally:
                    try:
                        await test_p.close()
                    except Exception:
                        pass  # best-effort; the result is already in hand

            result = asyncio.run(preflight_call())
            if "PREFLIGHT_OK" in result.text or len(result.text) > 0:
                ok(f"Pre-flight passed — model responded ({len(result.text)} chars)")
            else:
                stop("Pre-flight failed: model returned empty response")
    except Exception as exc:
        stop(
            f"Pre-flight failed: {exc}\n\n"
            "The pilot would fail the same way on every run, so it was not started.\n"
            "Common causes:\n"
            "  - Wrong model name (check your provider console for exact model IDs)\n"
            "  - Model not available on your account tier\n"
            "  - anthropic-version header rejected by this model\n"
            "  - max_tokens value incompatible with this model\n"
            "  - a parameter this model rejects (the adapter drops temperature automatically)"
        )

    from cpo.eval import HarnessConfig, default_methods, load_tasks, run_evaluation

    if provider == "anthropic":
        from pydantic import SecretStr

        from cpo.eval.baselines import ThrottledProvider
        from cpo.providers import AnthropicMessagesConfig, AnthropicMessagesProvider

        shared = AnthropicMessagesProvider(
            AnthropicMessagesConfig(model=model, api_key=SecretStr(api_key), temperature=None)
        )
        throttled = ThrottledProvider(shared, max_inflight)

        def factory():
            return throttled
    elif provider == "openai":
        from pydantic import SecretStr

        from cpo.eval.baselines import ThrottledProvider
        from cpo.providers import OpenAIResponsesConfig, OpenAIResponsesProvider

        shared = OpenAIResponsesProvider(
            OpenAIResponsesConfig(model=model, api_key=SecretStr(api_key), temperature=0.7)
        )
        throttled = ThrottledProvider(shared, max_inflight)

        def factory():
            return throttled
    elif provider == "azure":
        from cpo.eval.baselines import ThrottledProvider
        from cpo.providers import AzureResponsesConfig, AzureResponsesProvider

        shared = AzureResponsesProvider(
            AzureResponsesConfig(
                model=os.environ["AZURE_OPENAI_DEPLOYMENT"],
                endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],
                api_key=api_key,
                temperature=0.7,
            )
        )
        throttled = ThrottledProvider(shared, max_inflight)

        def factory():
            return throttled
    else:
        stop(f"Unknown provider {provider!r}")

    tasks = load_tasks("eval/tasks/main.jsonl")[:12]
    methods = default_methods()
    cfg = HarnessConfig(budget=12, blind_draws=3, concurrency=concurrency)

    print(
        f"  Running {len(tasks)} tasks x {len(methods)} methods x 3 conditions = "
        f"{len(tasks) * len(methods) * 3} runs"
    )
    print(f"  Up to {len(tasks) * len(methods) * 3 * 15} provider calls")
    print()

    started = time.time()

    async def run_and_close():
        try:
            return await run_evaluation(tasks, methods, factory, cfg, out_dir, resume=True)
        finally:
            try:
                await shared.close()
            except Exception:
                pass  # closing is best-effort; results are already written

    summary = asyncio.run(run_and_close())
    elapsed = time.time() - started

    ok(f"Pilot finished in {elapsed / 60:.1f} minutes")
    return summary


def step_inspect(summary: dict, out_dir: Path, model: str) -> list[str]:
    section("Step 4 of 4: inspection report")

    lines: list[str] = []
    issues: list[str] = []

    def add(msg: str, issue: str | None = None) -> None:
        lines.append(msg)
        print(f"  {msg}")
        if issue:
            issues.append(issue)

    add(f"Model: {model}")
    add(f"Output: {out_dir}")
    add("")

    by = summary["by_method_condition"]

    # Failures
    total_fail = sum(v["failures"] for v in by.values())
    if total_fail == 0:
        add("Failures: 0  [good]")
    else:
        add(
            f"Failures: {total_fail}  [needs investigation]",
            f"{total_fail} runs failed — check eval/runs/pilot-.../runs.jsonl for error fields",
        )

    # Budget
    over_budget = [
        (k, v["mean_calls"]) for k, v in by.items() if v["mean_calls"] is not None and v["mean_calls"] > 12.5
    ]
    if not over_budget:
        add("Budget: all methods within 12 calls  [good]")
    else:
        for k, c in over_budget:
            add(
                f"Budget: {k} used {c:.1f} calls  [over budget]",
                f"{k} exceeded the 12-call budget — check the concurrency / provider setup",
            )

    # Convergence: CPO terminal kinds
    try:
        runs = [
            json.loads(ln)
            for ln in (out_dir / "runs.jsonl").read_text(encoding="utf-8").splitlines()
            if ln.strip()
        ]
        cpo_runs = [r for r in runs if r["method"] == "cpo" and not r["error"]]
        kinds = Counter(r["detail"].get("terminal_kind") for r in cpo_runs)
        budget_ex = kinds.get("budget_exhausted", 0)
        fixed = kinds.get("fixed_point", 0)
        total_cpo = len(cpo_runs)
        add(
            f"CPO convergence: {fixed}/{total_cpo} fixed_point, "
            f"{budget_ex}/{total_cpo} budget_exhausted, "
            f"{kinds.get('cycle', 0)}/{total_cpo} cycle"
        )
        if total_cpo and budget_ex / total_cpo > 0.5:
            add(
                "  → majority budget_exhausted: epsilon may be too tight for this model",
                "CPO mostly budget_exhausted — consider raising --epsilon in the main run (record the change)",
            )
        elif total_cpo and fixed / total_cpo < 0.5:
            add(
                "  → fewer than half converged: worth investigating before the main run",
                "CPO convergence below 50% — check change signals in runs.jsonl",
            )
        else:
            add("  → convergence looks healthy  [good]")

        # Change signals
        last_signals = [
            r["detail"].get("change_signals", [])[-1] for r in cpo_runs if r["detail"].get("change_signals")
        ]
        if last_signals:
            p75 = sorted(last_signals)[int(0.75 * len(last_signals))]
            add(f"CPO last change signal p75: {p75:.4f}  (epsilon={0.06:.2f})")
            if p75 > 0.06:
                add(
                    f"  → p75 above epsilon: consider raising epsilon to ~{p75 * 1.2:.2f} for the main run",
                    f"Consider raising epsilon to ~{p75 * 1.2:.2f} (record in PREREGISTRATION.md)",
                )
            else:
                add("  → epsilon looks appropriate  [good]")
    except Exception as exc:
        add(f"Could not parse runs.jsonl: {exc}")

    # Blind test coverage
    add("")
    add("Blind test coverage (math+factual tasks):")
    for k, v in sorted(by.items()):
        if "|clean" not in k:
            continue
        method = k.split("|")[0]
        tested = v.get("blind_tested", 0)
        runs_n = v.get("runs", 0)
        graded = v.get("graded", 0)
        lock = v.get("history_locked_convergence")
        lock_str = f"{lock:.2f}" if lock is not None else "n/a"
        add(f"  {method:30s}  tested={tested}/{runs_n}  graded={graded}  lock={lock_str}")
    add("")

    # Lock rate sanity
    cpo_lock = by.get("cpo|clean", {}).get("history_locked_convergence")
    baseline_locks = [
        by.get(f"{m}|clean", {}).get("history_locked_convergence")
        for m in ("best_of_n", "self_consistency", "debate")
    ]
    baseline_locks = [v for v in baseline_locks if v is not None]
    if cpo_lock is not None and baseline_locks:
        if all(v == 0.0 for v in [cpo_lock, *baseline_locks]):
            add(
                "Lock rates: all 0.0 — blind theta may be too loose or sample too small",
                "All lock rates 0.0 — try --blind-theta 0.10 in the main run",
            )
        elif cpo_lock < min(baseline_locks):
            add(
                f"Lock rates: CPO ({cpo_lock:.2f}) below baselines {[round(v, 2) for v in baseline_locks]}  "
                f"[direction matches H4]"
            )
        else:
            add(
                f"Lock rates: CPO ({cpo_lock:.2f}) not below all baselines "
                f"{[round(v, 2) for v in baseline_locks]}  [H4 direction not yet visible]"
            )
        add("  (12 tasks is not enough for a conclusion — this is a sanity check only)")

    # Quality spot-check
    add("")
    add("Quality (math+factual, clean condition):")
    for method in (
        "best_of_n",
        "self_consistency",
        "debate",
        "cpo",
        "cpo_no_consensus",
        "cpo_no_reconfirmation",
        "cpo_plain_simhash",
    ):
        v = by.get(f"{method}|clean", {})
        q = v.get("quality")
        add(f"  {method:30s}  q={q:.2f}" if q is not None else f"  {method:30s}  q=n/a")

    add("")
    if not issues:
        add("VERDICT: pilot looks healthy — proceed to the main run (Step 11)")
    else:
        add(f"VERDICT: {len(issues)} issue(s) to resolve before the main run:")
        for issue in issues:
            add(f"  - {issue}")

    return lines


def write_report(lines: list[str], out_dir: Path, model: str) -> None:
    report_path = out_dir / "PILOT_REPORT.txt"
    report_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print()
    print(f"Full report written to: {report_path}")


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Automated pilot: smoke → dry run → real pilot → report")
    ap.add_argument("--provider", default="anthropic", choices=("anthropic", "openai", "azure"))
    ap.add_argument("--model", required=True, help="model ID, e.g. claude-sonnet-5")
    ap.add_argument("--api-key", default="", help="API key (or set env var ANTHROPIC/OPENAI_API_KEY)")
    ap.add_argument("--openai-key", default="", help="OpenAI key if --provider openai")
    ap.add_argument("--azure-endpoint", default="", help="Azure endpoint if --provider azure")
    ap.add_argument("--azure-key", default="", help="Azure key if --provider azure")
    ap.add_argument("--azure-deployment", default="", help="Azure deployment if --provider azure")
    ap.add_argument("--concurrency", type=int, default=4)
    ap.add_argument("--max-inflight", type=int, default=8)
    ap.add_argument("--out", default="", help="output folder; default: eval/runs/pilot-<model>")
    a = ap.parse_args(argv)

    # Resolve API key from argument or environment
    env_key = (
        os.environ.get("ANTHROPIC_API_KEY") if a.provider == "anthropic" else os.environ.get("OPENAI_API_KEY")
    )
    key = (a.api_key or env_key or "").strip()
    if not key and a.provider in ("anthropic", "openai"):
        stop("No API key provided. Use --api-key or set ANTHROPIC_API_KEY / OPENAI_API_KEY.")
    print(f"Key:      {key[:12]}... ({len(key)} characters)")
    if a.api_key and env_key and a.api_key.strip() != env_key.strip():
        warn(
            "--api-key differs from the environment variable; using --api-key. "
            "If the pilot fails with 401, re-run WITHOUT --api-key to use the environment key."
        )
    if a.provider == "anthropic" and not key.startswith("sk-ant-"):
        warn("Anthropic keys start with 'sk-ant-'; this one does not. Check for a truncated paste.")

    out_dir = Path(a.out) if a.out else Path(f"eval/runs/pilot-{a.model.replace('/', '-')}")
    out_dir.mkdir(parents=True, exist_ok=True)

    print()
    print("CPO Automated Pilot")
    print(f"Provider: {a.provider}  Model: {a.model}")
    print(f"Output:   {out_dir}")

    step_smoke(a.provider, a.model, key, a.openai_key, a.azure_endpoint, a.azure_key, a.azure_deployment)
    step_dryrun()
    summary = step_pilot(a.provider, a.model, key, a.concurrency, a.max_inflight, out_dir)
    lines = step_inspect(summary, out_dir, a.model)
    write_report(lines, out_dir, a.model)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
