"""Generate hard multi-step math tasks with machine-computed answers.

    python scripts/gen_hard_math.py --count 120 --seed 7 --out eval/tasks/candidates_math_v3.jsonl

Every answer is computed by the generator, not typed by hand, so the reference is
correct by construction.  Difficulty comes from chaining four to six operations,
awkward numbers, unit conversions, and constraints that must be tracked (remainders,
rounding rules, compound rates).  Feed the output to calibrate_tasks.py to keep the
items the target model does not solve every time.
"""

from __future__ import annotations

import argparse
import json
import math
import random
from fractions import Fraction
from pathlib import Path


def fmt(x) -> str:
    if isinstance(x, Fraction):
        x = float(x)
    if isinstance(x, float):
        if abs(x - round(x)) < 1e-9:
            return str(round(x))
        return f"{x:.2f}".rstrip("0").rstrip(".")
    return str(x)


def g_compound(r: random.Random):
    p = r.choice([2000, 3500, 4800, 6250, 7200])
    rate = r.choice([3, 4, 5, 6, 8])
    years = r.choice([3, 4, 5])
    fee = r.choice([25, 40, 60])
    amount = p
    for _ in range(years):
        amount = amount * (1 + rate / 100) - fee
    return (
        f"An account starts with ${p}. Each year it earns {rate}% interest on the balance, and then a ${fee} "
        f"fee is deducted after the interest is added. What is the balance after {years} years, to the nearest cent? "
        f"Give only the number.",
        round(amount, 2),
    )


def g_remainder(r: random.Random):
    a, b, c = r.sample([3, 4, 5, 7, 8, 9, 11], 3)
    ra, rb = r.randrange(1, a), r.randrange(1, b)
    lo, hi = r.choice([(200, 300), (300, 500), (500, 800)])
    sols = [n for n in range(lo, hi + 1) if n % a == ra and n % b == rb]
    if not sols:
        return None
    n = sols[0]
    return (
        f"Find the smallest integer between {lo} and {hi} inclusive that leaves a remainder of {ra} when divided by {a} "
        f"and a remainder of {rb} when divided by {b}. Then give the remainder when that integer is divided by {c}.",
        n % c,
    )


def g_mixture(r: random.Random):
    v1, c1 = r.choice([(6, 20), (8, 15), (12, 30), (5, 40)])
    v2, c2 = r.choice([(4, 60), (10, 45), (3, 70), (9, 55)])
    drain = r.choice([2, 3, 4])
    total = v1 + v2
    conc = (v1 * c1 + v2 * c2) / total
    remaining = total - drain
    salt = remaining * conc / 100
    return (
        f"A tank holds {v1} litres of a {c1}% salt solution. {v2} litres of a {c2}% salt solution are added and mixed "
        f"thoroughly. Then {drain} litres are drained off. How many litres of salt remain in the tank? Round to two decimals.",
        round(salt, 2),
    )


def g_work_rate(r: random.Random):
    a, b = r.sample([6, 8, 9, 10, 12, 15], 2)
    solo = r.choice([1, 2, 3])
    rate_a, rate_b = Fraction(1, a), Fraction(1, b)
    done = rate_a * solo
    remaining = 1 - done
    t = remaining / (rate_a + rate_b)
    total = solo + t
    return (
        f"Pipe A can fill a pool in {a} hours and pipe B in {b} hours. Pipe A runs alone for {solo} hour(s), then both "
        f"run together until the pool is full. How many hours in total does filling take? Give the exact answer as a "
        f"decimal rounded to two places.",
        round(float(total), 2),
    )


def g_schedule(r: random.Random):
    start_h, start_m = r.choice([(8, 15), (9, 40), (13, 25), (16, 50)])
    legs = [r.choice([35, 48, 72, 95, 110]) for _ in range(3)]
    breaks = [r.choice([10, 15, 25]) for _ in range(2)]
    tz = r.choice([-2, -1, 1, 2])
    total = sum(legs) + sum(breaks)
    mins = start_h * 60 + start_m + total + tz * 60
    mins %= 24 * 60
    h, m = divmod(mins, 60)
    return (
        f"A journey starts at {start_h:02d}:{start_m:02d}. It has three legs of {legs[0]}, {legs[1]} and {legs[2]} minutes "
        f"with breaks of {breaks[0]} and {breaks[1]} minutes between them. The destination is in a time zone "
        f"{'+' if tz > 0 else ''}{tz} hours from the start. What is the local arrival time? Answer in 24-hour HHMM format "
        f"as a single number (for example 1430).",
        h * 100 + m,
    )


def g_percent_chain(r: random.Random):
    price = r.choice([240, 360, 450, 720, 880])
    up = r.choice([15, 20, 25, 40])
    down = r.choice([10, 30, 35, 45])
    tax = r.choice([5, 8, 12])
    v = price * (1 + up / 100) * (1 - down / 100) * (1 + tax / 100)
    return (
        f"An item costs ${price}. Its price is increased by {up}%, then discounted by {down}% from the increased price, "
        f"then sales tax of {tax}% is applied to the discounted price. What is the final price, to the nearest cent?",
        round(v, 2),
    )


def g_digits(r: random.Random):
    n = r.choice([3, 4])
    lo, hi = 10 ** (n - 1), 10**n - 1
    ds = r.choice([12, 15, 18, 21])
    k = r.choice([7, 11, 13])
    sols = [x for x in range(lo, hi + 1) if sum(map(int, str(x))) == ds and x % k == 0]
    if len(sols) < 2:
        return None
    return (
        f"How many {n}-digit positive integers have digits that sum to {ds} and are divisible by {k}?",
        len(sols),
    )


def g_combinatorics(r: random.Random):
    n = r.choice([7, 8, 9, 10])
    k = r.choice([3, 4])
    forced = r.choice([1, 2])
    # committees of size k from n people that include at least `forced` of two specific people
    total = math.comb(n, k)
    without_both = math.comb(n - 2, k)
    exactly_one = 2 * math.comb(n - 2, k - 1)
    if forced == 1:
        ans = total - without_both
        cond = "at least one of Ana and Ben"
    else:
        ans = total - without_both - exactly_one
        cond = "both Ana and Ben"
    return (
        f"A committee of {k} is chosen from {n} people, two of whom are Ana and Ben. How many committees include {cond}?",
        ans,
    )


def g_speed(r: random.Random):
    d = r.choice([180, 240, 315, 420])
    v1 = r.choice([45, 60, 70])
    v2 = r.choice([80, 90, 105])
    stop = r.choice([20, 30, 45])
    frac = r.choice([Fraction(1, 3), Fraction(2, 5), Fraction(3, 7)])
    d1 = d * frac
    d2 = d - d1
    t = float(d1) / v1 + float(d2) / v2 + stop / 60
    avg = d / t
    return (
        f"A driver covers a {d} km route. The first {frac.numerator}/{frac.denominator} of the distance is driven at "
        f"{v1} km/h and the rest at {v2} km/h, with one {stop}-minute stop. What is the average speed for the whole "
        f"trip including the stop, in km/h, rounded to one decimal place?",
        round(avg, 1),
    )


def g_inventory(r: random.Random):
    start = r.choice([340, 512, 760])
    days = r.choice([5, 6, 7])
    daily_sale = r.choice([37, 48, 55])
    restock_every = r.choice([2, 3])
    restock = r.choice([90, 120, 150])
    stock = start
    for day in range(1, days + 1):
        stock -= daily_sale
        if stock < 0:
            stock = 0
        if day % restock_every == 0:
            stock += restock
    return (
        f"A shop starts the week with {start} units. Every day it sells {daily_sale} units (or all it has, if fewer). "
        f"At the end of every {restock_every}{'nd' if restock_every == 2 else 'rd'} day, after the sale, a delivery of "
        f"{restock} units arrives. How many units are in stock at the end of day {days}?",
        stock,
    )


GENERATORS = [
    g_compound,
    g_remainder,
    g_mixture,
    g_work_rate,
    g_schedule,
    g_percent_chain,
    g_digits,
    g_combinatorics,
    g_speed,
    g_inventory,
]


# ---- generators aimed at error modes of language models: long chains, enumeration,
# ---- inclusion-exclusion, recurrences, and rounding applied at every step.


def g_long_ledger(r: random.Random):
    """12-16 transactions with a per-step rounding rule; one slip propagates."""
    n = r.choice([12, 14, 16])
    bal = r.choice([1250.00, 2480.50, 3175.25])
    ops = []
    b = bal
    for _ in range(n):
        kind = r.choice(["dep", "wd", "fee", "int"])
        if kind == "dep":
            v = r.choice([84.30, 129.99, 210.45, 377.10])
            b += v
            ops.append(f"deposit ${v:.2f}")
        elif kind == "wd":
            v = r.choice([56.75, 149.20, 233.80])
            b -= v
            ops.append(f"withdrawal ${v:.2f}")
        elif kind == "fee":
            pct = r.choice([1.5, 2.25])
            f = round(b * pct / 100, 2)
            b -= f
            ops.append(f"fee of {pct}% of the current balance, rounded to the cent")
        else:
            pct = r.choice([0.8, 1.2])
            f = round(b * pct / 100, 2)
            b += f
            ops.append(f"interest of {pct}% of the current balance, rounded to the cent")
        b = round(b, 2)
    listing = "; ".join(f"({i + 1}) {o}" for i, o in enumerate(ops))
    return (
        f"An account starts at ${bal:.2f}. Apply these transactions in order, rounding to the cent after "
        f"each one: {listing}. What is the final balance? Give only the number.",
        round(b, 2),
    )


def g_inclusion_exclusion(r: random.Random):
    lo, hi = r.choice([(1, 600), (100, 900), (1, 1000)])
    a, b, c = r.sample([3, 4, 5, 6, 7, 9, 11], 3)
    count = sum(1 for n in range(lo, hi + 1) if (n % a == 0 or n % b == 0) and n % c != 0)
    return (
        f"How many integers from {lo} to {hi} inclusive are divisible by {a} or by {b} but not by {c}?",
        count,
    )


def g_recurrence(r: random.Random):
    a0, a1 = r.choice([(2, 5), (3, 1), (1, 4), (5, 2)])
    p, q, k = r.choice([(2, -1, 3), (1, 2, -4), (3, -2, 5), (2, 3, -7)])
    n = r.choice([8, 9, 10])
    seq = [a0, a1]
    for _ in range(n - 1):
        seq.append(p * seq[-1] + q * seq[-2] + k)
    return (
        f"A sequence has a(0) = {a0} and a(1) = {a1}, and for n >= 2, a(n) = {p}*a(n-1) + ({q})*a(n-2) + ({k}). "
        f"What is a({n})?",
        seq[n],
    )


def g_enumeration(r: random.Random):
    digits = r.sample(range(1, 10), r.choice([4, 5]))
    k = r.choice([3, 4])
    div = r.choice([4, 6, 8, 12])
    from itertools import permutations

    count = sum(1 for perm in permutations(digits, k) if int("".join(map(str, perm))) % div == 0)
    ds = ", ".join(map(str, digits))
    return (
        f"Using the digits {ds}, each at most once, how many {k}-digit numbers can be formed that are divisible by {div}?",
        count,
    )


def g_calendar(r: random.Random):
    start_day = r.choice(["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"])
    days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    every = r.choice([3, 4, 5, 6])
    horizon = r.choice([60, 75, 90])
    skip = r.choice(["Sunday", "Saturday"])
    idx = days.index(start_day)
    count = 0
    d = 0
    while d <= horizon:
        if days[(idx + d) % 7] != skip:
            count += 1
        d += every
    return (
        f"A shipment arrives on day 0, which is a {start_day}, and every {every} days after that, up to and including "
        f"day {horizon}. Shipments that would fall on a {skip} are cancelled, not moved. How many shipments arrive in total?",
        count,
    )


def g_tiered_pricing(r: random.Random):
    units = r.choice([1370, 2215, 3480, 4790])
    t1, t2 = r.choice([(500, 1500), (800, 2000), (1000, 2500)])
    p1, p2, p3 = r.choice([(0.12, 0.09, 0.06), (0.25, 0.18, 0.11), (0.40, 0.31, 0.22)])
    disc = r.choice([5, 8, 12])
    cost = min(units, t1) * p1 + max(0, min(units, t2) - t1) * p2 + max(0, units - t2) * p3
    cost = round(cost, 2)
    if units > t2:
        cost = round(cost * (1 - disc / 100), 2)
    return (
        f"Electricity costs ${p1:.2f} per unit for the first {t1} units, ${p2:.2f} per unit for units {t1 + 1} to {t2}, "
        f"and ${p3:.2f} per unit above {t2}. If total usage exceeds {t2} units, a {disc}% discount is applied to the "
        f"whole bill after it is computed and rounded to the cent. What is the bill for {units} units, to the nearest cent?",
        cost,
    )


def g_expected_value(r: random.Random):
    from fractions import Fraction as F

    n = r.choice([6, 8, 10])
    payout = r.choice([12, 15, 20])
    cost = r.choice([4, 5, 6])
    # roll an n-sided die twice; win `payout` if the sum is at least win+n-... simple: sum >= threshold
    thr = r.choice([n + 2, n + 4, n + 5])
    good = sum(1 for a in range(1, n + 1) for b in range(1, n + 1) if a + b >= thr)
    ev = F(good, n * n) * payout - cost
    return (
        f"A game costs ${cost} to play. You roll a fair {n}-sided die twice and win ${payout} if the sum is at least {thr}, "
        f"otherwise nothing. What is the expected net gain per game in dollars, to the nearest cent (negative if a loss)?",
        round(float(ev), 2),
    )


def g_two_stage_rounding(r: random.Random):
    people = r.choice([37, 53, 68, 91])
    cost = r.choice([1284.70, 2061.35, 3399.99])
    share = math.ceil(cost / people * 100) / 100  # each pays share rounded UP to the cent
    collected = round(share * people, 2)
    tip_pct = r.choice([12, 15, 18])
    tip = round(collected * tip_pct / 100, 2)
    total = round(collected + tip, 2)
    return (
        f"A bill of ${cost:.2f} is split among {people} people; each pays an equal share rounded UP to the next cent. "
        f"The total collected is then increased by a {tip_pct}% tip computed on the collected amount and rounded to the cent. "
        f"How much is handed over in total? Give the number to the cent.",
        total,
    )


GENERATORS += [
    g_long_ledger,
    g_inclusion_exclusion,
    g_recurrence,
    g_enumeration,
    g_calendar,
    g_tiered_pricing,
    g_expected_value,
    g_two_stage_rounding,
]


# The LLM-error-mode generators are sampled three times as often as the arithmetic ones.
WEIGHTED = GENERATORS[:10] + GENERATORS[10:] * 3


FROZEN_NOTE = (
    "Task files are evidence: the paper reports results on eval/tasks/main_math_calibrated_v2.jsonl "
    "and records its SHA-256, and the calibration drew on candidates_math_v2.jsonl. Write new task "
    "sets to new names; pass --force only if you are certain nothing cites the existing file."
)


def refuse_overwrite(path: str, force: bool) -> None:
    if Path(path).exists() and not force:
        raise SystemExit(f"refusing to overwrite existing {path}.\n{FROZEN_NOTE}")

def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--count", type=int, default=120)
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--out", default="eval/tasks/candidates_math_v3.jsonl")
    ap.add_argument("--force", action="store_true", help="overwrite an existing output file")
    a = ap.parse_args(argv)
    refuse_overwrite(a.out, a.force)
    r = random.Random(a.seed)  # nosec B311 - task generation
    seen, rows = set(), []
    attempts = 0
    while len(rows) < a.count and attempts < a.count * 20:
        attempts += 1
        gen = WEIGHTED[len(rows) % len(WEIGHTED)]
        item = gen(r)
        if item is None or item[0] in seen:
            continue
        prompt, ans = item
        seen.add(prompt)
        rows.append(
            {
                "id": f"hmath-{len(rows) + 1:03d}",
                "family": "math",
                "prompt": prompt,
                "answer": fmt(ans),
                "grader": "numeric",
                "metadata": {"source": "gen_hard_math", "generator": gen.__name__, "seed": a.seed},
            }
        )
    Path(a.out).parent.mkdir(parents=True, exist_ok=True)
    Path(a.out).write_text("\n".join(json.dumps(x, ensure_ascii=True) for x in rows) + "\n", encoding="ascii")
    print(f"wrote {len(rows)} tasks to {a.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
