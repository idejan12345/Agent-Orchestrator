"""Security evidence beyond the stdlib pattern scan.

* SAST: bandit over src/ (JSON report).
* Dependency audit: the package is installed into a fresh virtual environment from the
  built wheel, so pip-audit sees exactly the runtime closure, not the developer machine.
* SBOM: CycloneDX JSON for that environment.
* Container scan: recorded as not run unless a scanner and a daemon are available.

Writes release/evidence/external_security_summary.json.  Exit 0 iff SAST has no
high/medium findings and the audit reports no vulnerabilities in the runtime closure.
"""

from __future__ import annotations

import json
import shutil
import subprocess
import sys
from pathlib import Path

EVID = Path("release/evidence")
EVID.mkdir(parents=True, exist_ok=True)


def run(cmd: list[str], **kw) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, capture_output=True, text=True, **kw)  # nosec B603 - fixed argv


def main() -> int:
    summary: dict = {"tooling": {}, "limitations": []}

    # SAST
    run([sys.executable, "-m", "bandit", "-r", "src", "-q", "-f", "json", "-o", str(EVID / "bandit.json")])
    b = json.loads((EVID / "bandit.json").read_text(encoding="utf-8"))
    sev = {k.split(".")[1].lower(): v for k, v in b["metrics"]["_totals"].items() if k.startswith("SEVERITY")}
    summary["sast"] = {"tool": "bandit", "findings_by_severity": sev, "results": len(b["results"])}
    summary["tooling"]["bandit"] = run([sys.executable, "-m", "bandit", "--version"]).stdout.split("\n")[0]

    # Clean venv with the wheel
    wheels = sorted(Path("dist").glob("cpo_orchestrator-*.whl"))
    if not wheels:
        raise SystemExit("build the wheel first (python -m build --wheel)")
    venv = Path("build/audit-venv")
    shutil.rmtree(venv, ignore_errors=True)
    run([sys.executable, "-m", "venv", str(venv)])
    py = venv / "bin" / "python"
    inst = run([str(py), "-m", "pip", "install", "-q", "--disable-pip-version-check", str(wheels[-1])])
    if inst.returncode:
        raise SystemExit("wheel install failed: " + inst.stderr[-500:])
    freeze = run([str(py), "-m", "pip", "freeze"]).stdout
    runtime = sorted(line for line in freeze.splitlines() if line)
    run([str(py), "-m", "pip", "install", "-q", "--disable-pip-version-check", "pip-audit", "cyclonedx-bom"])
    req = Path("build/runtime-requirements.txt")
    req.write_text("\n".join(runtime) + "\n")
    run(
        [
            str(py),
            "-m",
            "pip_audit",
            "-r",
            str(req),
            "--format",
            "json",
            "--progress-spinner",
            "off",
            "-o",
            str(EVID / "pip_audit.json"),
        ]
    )
    audit_json = (
        json.loads((EVID / "pip_audit.json").read_text(encoding="utf-8"))
        if (EVID / "pip_audit.json").exists()
        else {"dependencies": []}
    )
    vulns = [
        (d["name"], d["version"], v["id"], v.get("fix_versions"))
        for d in audit_json.get("dependencies", [])
        for v in d.get("vulns", [])
    ]
    summary["dependency_audit"] = {
        "tool": "pip-audit",
        "scope": "runtime closure of the wheel in a clean venv",
        "packages": len(runtime),
        "requirements": runtime,
        "vulnerabilities": vulns,
    }
    summary["tooling"]["pip-audit"] = run([str(py), "-m", "pip_audit", "--version"]).stdout.strip()

    # SBOM
    sbom = run(
        [
            str(venv / "bin" / "cyclonedx-py"),
            "environment",
            "--of",
            "JSON",
            "-o",
            str(EVID / "sbom.cdx.json"),
            str(py),
        ]
    )
    summary["sbom"] = {
        "tool": "cyclonedx-bom",
        "file": "sbom.cdx.json",
        "generated": sbom.returncode == 0,
        "note": None if sbom.returncode == 0 else sbom.stderr[-300:],
    }

    # Container scan
    docker = shutil.which("docker")
    summary["container_scan"] = {
        "run": False,
        "reason": "no container daemon in this environment" if not docker else "scanner not configured",
    }
    summary["limitations"] += [
        "container image not scanned",
        "no penetration test",
        "no secrets-manager integration test",
    ]

    high = sev.get("high", 0)
    medium = sev.get("medium", 0)
    summary["passed"] = high == 0 and medium == 0 and not vulns
    summary["critical"], summary["high"] = 0 if not vulns else None, high
    (EVID / "external_security_summary.json").write_text(json.dumps(summary, indent=2))
    print(json.dumps({k: summary[k] for k in ("sast", "passed")}, indent=2))
    print("vulnerabilities:", vulns)
    print("sbom generated:", summary["sbom"]["generated"])
    return 0 if summary["passed"] else 1


if __name__ == "__main__":
    sys.exit(main())
