"""Run the preregistered H4/H5 evaluation.

Dry run (no credentials, no spend) -- validates tasks, methods, budget and output:

    PYTHONPATH=src python scripts/run_evaluation.py --provider mock \
        --tasks eval/tasks/example.jsonl --out eval/runs/dryrun

Real run:

    export ANTHROPIC_API_KEY=...  ANTHROPIC_MODEL=...
    PYTHONPATH=src python scripts/run_evaluation.py --provider anthropic \
        --tasks eval/tasks/my_tasks.jsonl --out eval/runs/2026-09-15-anthropic \
        --budget 12 --temperature 0.7 --concurrency 4 --yes

The run is resumable: re-running the same command skips completed runs.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from cpo.eval import HarnessConfig, default_methods, load_tasks, run_evaluation
from cpo.eval.harness import preflight_limits, task_set_summary
from cpo.providers.base import ProviderResult


class MockProvider:
    """Offline stand-in. Deterministic per prompt; optionally echoes a shared draft so a
    dry run exercises the history-locking path without any network call."""

    provider_name = "mock"

    def __init__(self, seed: int = 0, lock: bool = False):
        self.rng = random.Random(seed)  # nosec B311 - offline fixture
        self.lock = lock

    async def generate(self, prompt: str, *, request_id: str) -> ProviderResult:
        await asyncio.sleep(0)
        draft = ""
        if "shared workspace" in prompt or "Other specialists answered" in prompt:
            draft = prompt.split("\n\n")[-1][:200]
        question = ""
        for block in prompt.split("\n\n"):
            if block.startswith("Question:"):
                question = block[len("Question:") :].strip()
        digits = [c for c in question if c.isdigit()]
        answer = digits[-1] if digits else "unknown"
        if self.lock and draft:
            body = f"Building on the shared draft: {draft}"
        else:
            body = f"Working through the question: {question[:160]}"
        return ProviderResult(
            text=f"{body}\nAnswer: {answer}",
            provider="mock",
            model="mock-1",
            request_id=request_id,
            usage={"input_tokens": len(prompt) // 4, "output_tokens": 24},
        )

    async def readiness(self):
        return True, "mock"

    async def close(self):
        return None


def _env(name: str) -> str:
    value = os.environ.get(name)
    if not value:
        raise SystemExit(f"environment variable {name} is required for this provider")
    return value


def build_factory(kind: str, temperature: float, *, max_output_tokens: int = 8192,
                  call_timeout_s: float = 180.0):
    """Returns (factory, shared_provider_or_None).  Real providers are one shared client.

    The adapter limits must match the harness limits: an adapter that times out sooner than the
    orchestrator, or that caps output below what the task needs, removes candidates from the pool
    instead of failing the run.  Both are passed in rather than left at the library defaults.
    """
    if kind == "mock":
        return (lambda: MockProvider()), None
    common = {"max_output_tokens": max_output_tokens, "timeout_s": call_timeout_s}
    if kind == "anthropic":
        from cpo.providers import AnthropicMessagesConfig, AnthropicMessagesProvider

        shared = AnthropicMessagesProvider(
            AnthropicMessagesConfig(
                model=_env("ANTHROPIC_MODEL"), api_key=_env("ANTHROPIC_API_KEY"), temperature=None,
                **common,
            )
        )
    elif kind == "openai":
        from cpo.providers import OpenAIResponsesConfig, OpenAIResponsesProvider

        shared = OpenAIResponsesProvider(
            OpenAIResponsesConfig(
                model=_env("OPENAI_MODEL"), api_key=_env("OPENAI_API_KEY"), temperature=temperature,
                **common,
            )
        )
    elif kind == "azure":
        from cpo.providers import AzureResponsesConfig, AzureResponsesProvider

        shared = AzureResponsesProvider(
            AzureResponsesConfig(
                model=_env("AZURE_OPENAI_DEPLOYMENT"),
                endpoint=_env("AZURE_OPENAI_ENDPOINT"),
                api_key=_env("AZURE_OPENAI_API_KEY"),
                temperature=temperature,
                **common,
            )
        )
    else:
        raise SystemExit(f"unknown provider {kind!r}")
    return (lambda: shared), shared


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Preregistered H4/H5 evaluation")
    ap.add_argument("--tasks", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--provider", default="mock", choices=("mock", "anthropic", "openai", "azure"))
    ap.add_argument("--budget", type=int, default=12, help="provider calls per run, all methods")
    ap.add_argument("--temperature", type=float, default=0.7, help="sampling temperature for real providers")
    ap.add_argument("--yes", action="store_true", help="skip the spend confirmation prompt")
    ap.add_argument("--blind-draws", type=int, default=3)
    ap.add_argument("--blind-theta", type=float, default=0.15)
    ap.add_argument("--conditions", default="clean,noisy,history_locking")
    ap.add_argument("--methods", default="", help="comma-separated subset; default is all eleven (see cpo.eval.default_methods)")
    ap.add_argument(
        "--signer", default="marker", choices=("marker", "simhash"), help="signature backend for cpo rows"
    )
    ap.add_argument("--seeds", default="1")
    ap.add_argument("--concurrency", type=int, default=4, help="runs in flight at once")
    ap.add_argument(
        "--max-inflight", type=int, default=8, help="provider requests in flight at once, across all runs"
    )
    ap.add_argument("--limit", type=int, default=0, help="use only the first N tasks")
    ap.add_argument(
        "--profile",
        default="full",
        choices=("full", "minimal"),
        help=(
            "minimal = the cheapest configuration that still tests H4 and the central H5 claim: "
            "9 methods (all but cpo_plain_simhash and cpo_no_occupancy, which need larger pools or a second "
            "signer to mean anything), conditions clean + history_locking, "
            "one seed. Record the deviation from the full protocol in PREREGISTRATION.md."
        ),
    )
    ap.add_argument("--no-resume", action="store_true")
    ap.add_argument("--per-run-timeout", type=float, default=None,
                    help="seconds for one whole run; default derives from budget x call timeout")
    ap.add_argument("--call-timeout", type=float, default=180.0,
                    help="seconds for one provider call inside the orchestrator")
    ap.add_argument("--max-output-tokens", type=int, default=8192,
                    help="output-token ceiling; truncation is detected and fails the run")
    ap.add_argument("--max-candidate-chars", type=int, default=120_000,
                    help="an over-long candidate is DROPPED from the pool, so keep this generous")
    ap.add_argument("--retry-failed", type=int, default=1,
                    help="automatic re-run passes for errored runs (0 disables)")
    ap.add_argument("--max-total-tokens", type=int, default=0,
                    help="hard stop: no new run is launched once usage reaches this (0 = no cap)")
    ap.add_argument("--skip-ping", action="store_true",
                    help="skip the one-call provider check made before a real sweep")
    ap.add_argument("--price-in", type=float, default=0.0,
                    help="USD per 1M input tokens, for the spend estimate only")
    ap.add_argument("--price-out", type=float, default=0.0,
                    help="USD per 1M output tokens, for the spend estimate only")
    ap.add_argument(
        "--redo-methods",
        default="",
        help="comma-separated methods whose existing records are discarded and re-run",
    )
    a = ap.parse_args(argv)

    tasks = load_tasks(a.tasks)
    if a.limit:
        tasks = tasks[: a.limit]
    ts = task_set_summary(tasks)
    print(
        f"task set: {ts['tasks']} tasks, {ts['discrete_graded']} discrete-graded, "
        f"{ts['rubric_graded']} rubric-graded; families {ts['families']}"
    )
    if not ts["h4_testable"]:
        print(
            "\nWARNING: every task in this file is rubric-graded. The history-locked convergence "
            "metric is defined only for discrete-grader tasks, so this run CANNOT test H4 -- it "
            "measures quality only, and quality needs a rating pass afterwards. For H4 use a task "
            "file with exact/numeric/contains graders (e.g. eval/tasks/main_math_calibrated_v2.jsonl)."
        )
        if a.provider != "mock" and not a.yes:
            reply = input("continue with a quality-only run? [y/N] ").strip().lower()
            if reply != "y":
                return 1
    if a.profile == "minimal":
        if not a.methods:
            a.methods = (
                "best_of_n,self_consistency,debate,cpo,cpo_judged,cpo_no_consensus,cpo_no_reconfirmation,cpo_adaptive,cpo_gated_judge"
            )
        if a.conditions == "clean,noisy,history_locking":
            a.conditions = "clean,history_locking"
        a.seeds = "1"
        print("profile: minimal (9 methods, conditions clean + history_locking, 1 seed)")
    from cpo.sketch import MarkerWeightedSigner, SimHashSigner

    methods = default_methods(
        signer=MarkerWeightedSigner(256) if a.signer == "marker" else SimHashSigner(256)
    )
    if a.methods:
        wanted = {m.strip() for m in a.methods.split(",")}
        methods = [m for m in methods if m.name in wanted]
        missing = wanted - {m.name for m in methods}
        if missing:
            raise SystemExit(f"unknown methods: {sorted(missing)}")
    cfg = HarnessConfig(
        budget=a.budget,
        blind_draws=a.blind_draws,
        blind_theta=a.blind_theta,
        conditions=tuple(c.strip() for c in a.conditions.split(",") if c.strip()),
        seeds=tuple(int(s) for s in a.seeds.split(",")),
        concurrency=a.concurrency,
        per_run_timeout_s=a.per_run_timeout,
        call_timeout_s=a.call_timeout,
        max_output_tokens=a.max_output_tokens,
        max_candidate_chars=a.max_candidate_chars,
        retry_failed_runs=a.retry_failed,
    )
    problems = preflight_limits(cfg)
    if problems:
        print("\nLIMIT PREFLIGHT FAILED — these would corrupt the run:")
        for p_ in problems:
            print(f"  - {p_}")
        print("\nFix the flags above and re-run. Nothing has been spent.")
        return 2
    print(
        f"limits ok: per-run {cfg.per_run_timeout_s:.0f}s (worst case "
        f"{cfg.worst_case_run_seconds():.0f}s), call {cfg.call_timeout_s:.0f}s, "
        f"max_output_tokens {cfg.max_output_tokens}, retry passes {cfg.retry_failed_runs}"
    )
    planned = len(tasks) * len(methods) * len(cfg.conditions) * len(cfg.seeds)
    print(
        f"{len(tasks)} tasks x {len(methods)} methods x {len(cfg.conditions)} conditions "
        f"x {len(cfg.seeds)} seeds = {planned} runs; "
        f"up to {planned * (cfg.budget + cfg.blind_draws)} provider calls"
    )
    # Projected spend, from the measured ~11.4k tokens per run at a 12-call budget (eval/runs/main-minimal-haiku),
    # scaled by this run's budget.  Prompt/completion split is close to 50/50 in that data.
    per_run_tok = 11_400 * ((cfg.budget + cfg.blind_draws) / 15)
    tok = planned * per_run_tok
    shown = f"{tok/1e6:.2f}M" if tok >= 1e6 else f"{tok/1e3:.0f}k"
    est = f"{shown} tokens projected (~{per_run_tok/1000:.1f}k/run)"
    if a.price_in or a.price_out:
        usd = (tok / 2 / 1e6) * a.price_in + (tok / 2 / 1e6) * a.price_out
        est += f"; ~${usd:,.0f} at the prices given"
    else:
        est += "; pass --price-in/--price-out for a dollar estimate"
    print(est)
    hours = planned * cfg.worst_case_run_seconds() / max(1, cfg.concurrency) / 3600
    print(f"wall clock at concurrency {cfg.concurrency}: up to {hours:.1f} h worst case")
    if a.provider != "mock" and not a.yes:
        reply = input("proceed and spend on the API? [y/N] ").strip().lower()
        if reply != "y":
            return 1
    factory, shared = build_factory(
        a.provider, a.temperature,
        max_output_tokens=cfg.max_output_tokens, call_timeout_s=cfg.call_timeout_s,
    )
    if shared is not None:
        from cpo.eval.baselines import ThrottledProvider

        throttled = ThrottledProvider(shared, a.max_inflight)
        factory = lambda: throttled  # noqa: E731

    import hashlib

    provenance = {
        "provider": a.provider,
        "model": os.environ.get(
            {"anthropic": "ANTHROPIC_MODEL", "openai": "OPENAI_MODEL",
             "azure": "AZURE_OPENAI_DEPLOYMENT"}.get(a.provider, ""), "mock"
        ),
        "signer": a.signer,
        "task_file_sha256": hashlib.sha256(Path(a.tasks).read_bytes()).hexdigest()[:16],
    }

    async def ping() -> str | None:
        """One minimal call before the sweep.  A wrong key, a wrong model name, a missing
        permission or an exhausted quota then costs one call and a clear message, instead of
        every run in the sweep failing one by one and being recorded as errors."""
        if shared is None or a.skip_ping:
            return None
        try:
            r = await shared.generate("Reply with the single word: ready", request_id="cpo-ping")
            return None if r.text.strip() else "provider returned an empty response"
        except Exception as exc:  # report any failure, then stop
            return f"{type(exc).__name__}: {exc}"

    async def go():
        try:
            problem = await ping()
            if problem:
                raise SystemExit(
                    f"provider check failed before any run was launched: {problem}\n"
                    "Check the API key, the model name and the account's quota. Nothing else was spent."
                )
            if shared is not None and not a.skip_ping:
                print("provider check: ok")
            return await run_evaluation(
                tasks,
                methods,
                factory,
                cfg,
                a.out,
                resume=not a.no_resume,
                redo_methods=[m.strip() for m in a.redo_methods.split(",") if m.strip()],
                provenance=provenance,
                max_total_tokens=a.max_total_tokens or None,
            )
        finally:
            if shared is not None:
                await shared.close()

    try:
        summary = asyncio.run(go())
    except ValueError as exc:
        # configuration problems (inconsistent limits, a resume into a different configuration)
        # are user errors with a clear fix; print the message, not a traceback
        print(f"\nREFUSED: {exc}")
        return 2
    print(json.dumps(summary["by_method_condition"], indent=2, default=str))
    print(json.dumps(summary["preregistered_decision"], indent=2))
    dec = summary["preregistered_decision"]
    if dec.get("H4_status") == "not_tested":
        print("\n" + dec["reason"])
    if summary.get("failure_asymmetry_warning"):
        print("\nWARNING: " + summary["failure_asymmetry_warning"])
        print(json.dumps(summary["failures_by_method"], indent=2))
    if summary.get("runs_not_launched_by_token_cap"):
        print(
            f"\n{summary['runs_not_launched_by_token_cap']} run(s) were not launched because "
            f"--max-total-tokens was reached; rerun the same command to resume them."
        )
    print(f"\ntokens spent: {summary.get('tokens_spent', 0):,}")
    print(f"written to {a.out}/runs.jsonl and {a.out}/summary.json")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
