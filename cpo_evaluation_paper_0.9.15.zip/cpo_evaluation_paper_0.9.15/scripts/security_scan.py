from __future__ import annotations

import ast
import json
import re
import stat
from pathlib import Path

ROOT = Path(__file__).parents[1]
issues = []
for path in [*ROOT.glob("src/**/*.py"), *ROOT.glob("scripts/*.py")]:
    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    for node in ast.walk(tree):
        if (
            isinstance(node, ast.Call)
            and isinstance(node.func, ast.Name)
            and node.func.id in {"eval", "exec", "compile"}
        ):
            issues.append(
                {
                    "severity": "high",
                    "file": str(path.relative_to(ROOT)),
                    "line": node.lineno,
                    "issue": node.func.id,
                }
            )
        if (
            isinstance(node, ast.Call)
            and isinstance(node.func, ast.Attribute)
            and node.func.attr in {"system", "popen"}
        ):
            issues.append(
                {
                    "severity": "high",
                    "file": str(path.relative_to(ROOT)),
                    "line": node.lineno,
                    "issue": node.func.attr,
                }
            )
secret_patterns = [re.compile(r'(?i)(api[_-]?key|password|secret|token)\s*=\s*["\'][^"\']{12,}["\']')]
for path in ROOT.rglob("*"):
    if not path.is_file() or any(x in path.parts for x in (".pytest_cache", "__pycache__")):
        continue
    if path.name in ("census_report.json", "plane_report.json"):
        continue
    try:
        text = path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        continue
    for pattern in secret_patterns:
        if pattern.search(text) and path.suffix not in {".md", ".example"}:
            issues.append(
                {
                    "severity": "medium",
                    "file": str(path.relative_to(ROOT)),
                    "issue": "possible hardcoded secret",
                }
            )
world_writable = []
for path in ROOT.rglob("*"):
    if path.is_file() and path.stat().st_mode & stat.S_IWOTH:
        world_writable.append(str(path.relative_to(ROOT)))
report = {
    "scanner": "stdlib-ast-and-patterns",
    "high": sum(i["severity"] == "high" for i in issues),
    "medium": sum(i["severity"] == "medium" for i in issues),
    "issues": issues,
    "world_writable_files": world_writable,
    "limitations": ["not a dependency CVE database", "not a container scan", "not a penetration test"],
}
(ROOT / "reports/security_scan.json").write_text(json.dumps(report, indent=2))
print(json.dumps(report, indent=2))
raise SystemExit(1 if report["high"] else 0)
