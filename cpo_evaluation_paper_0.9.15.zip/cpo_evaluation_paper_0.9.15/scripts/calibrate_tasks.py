"""Difficulty calibration for the task set (pilot stage only).

    python scripts/calibrate_tasks.py --provider anthropic --model claude-sonnet-5 \
        --candidates eval/tasks/candidates_math_v3.jsonl --keep 40 --probes 3 \
        --out eval/tasks/main_math_calibrated_v3.jsonl

For each candidate task the target model is asked ``--probes`` times as a single clean
specialist.  A task is *discriminating* if the model gets it wrong at least once; the
first ``--keep`` discriminating tasks (in file order) are written out, and a record of
the rule and every probe result is saved beside them.  The rule is fixed here so the task
set is selected by procedure, not by hand.  Run once, record the output file's SHA-256 in
the preregistration, and do not run again after the main evaluation starts.

Cost: candidates x probes provider calls.
"""

from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from cpo.eval.baselines import CountingProvider, ThrottledProvider, _role_prompt
from cpo.eval.harness import CLEAN_ROLES
from cpo.eval.tasks import Task, grade, load_tasks


def build_provider(kind: str, model: str, api_key: str):
    from pydantic import SecretStr

    if kind == "anthropic":
        from cpo.providers import AnthropicMessagesConfig, AnthropicMessagesProvider

        return AnthropicMessagesProvider(
            AnthropicMessagesConfig(
                model=model,
                api_key=SecretStr(api_key),
                temperature=None,
                max_output_tokens=8192,
                timeout_s=180.0,
            )
        )
    if kind == "openai":
        from cpo.providers import OpenAIResponsesConfig, OpenAIResponsesProvider

        return OpenAIResponsesProvider(
            OpenAIResponsesConfig(
                model=model,
                api_key=SecretStr(api_key),
                temperature=0.7,
                max_output_tokens=8192,
                timeout_s=180.0,
            )
        )
    raise SystemExit(f"unsupported provider {kind!r} for calibration")


FROZEN_NOTE = (
    "Task files are evidence: the paper reports results on eval/tasks/main_math_calibrated_v2.jsonl "
    "and records its SHA-256, and the calibration drew on candidates_math_v2.jsonl. Write new task "
    "sets to new names; pass --force only if you are certain nothing cites the existing file."
)


def refuse_overwrite(path: str, force: bool) -> None:
    if Path(path).exists() and not force:
        raise SystemExit(f"refusing to overwrite existing {path}.\n{FROZEN_NOTE}")

async def probe(task: Task, provider, probes: int, errors: list[str]) -> list[bool | None]:
    """One probe = one single-specialist answer.  A provider failure is recorded as None
    (unknown), never as a wrong answer; tasks with any unknown probe are not selected."""
    counter = CountingProvider(provider, probes)
    names = list(CLEAN_ROLES)
    results: list[bool | None] = []
    for i in range(probes):
        role = CLEAN_ROLES[names[i % len(names)]]
        try:
            r = await counter.generate(_role_prompt(role, task.prompt), request_id=f"cal-{task.id}-{i}")
            results.append(bool(grade(task, r.text)))
        except Exception as exc:
            errors.append(f"{task.id} probe {i}: {str(exc)[:120]}")
            results.append(None)
    return results


async def main_async(a) -> int:
    refuse_overwrite(a.out, a.force)
    import os

    key = a.api_key or os.environ.get(
        "ANTHROPIC_API_KEY" if a.provider == "anthropic" else "OPENAI_API_KEY", ""
    )
    if not key:
        raise SystemExit("no API key: use --api-key or set the provider's environment variable")
    tasks = load_tasks(a.candidates)
    prepend: list[Task] = load_tasks(a.prepend) if a.prepend else []
    pre_ids = {t.id for t in prepend}
    graded = [t for t in tasks if t.grader != "rubric" and t.id not in pre_ids]
    if prepend:
        print(f"{len(prepend)} previously calibrated tasks kept without re-probing")
    print(f"{len(graded)} gradable candidates; {a.probes} probes each = up to {len(graded) * a.probes} calls")
    if not a.yes:
        if input("proceed and spend on the API? [y/N] ").strip().lower() != "y":
            return 1
    shared = build_provider(a.provider, a.model, key)
    throttled = ThrottledProvider(shared, a.max_inflight)
    sem = asyncio.Semaphore(a.concurrency)
    record: dict[str, list[bool | None]] = {}
    errors: list[str] = []

    # Checkpoint.  An interrupted calibration (quota, network, Ctrl-C) must not throw away probes
    # already paid for.  Resuming is the *same* calibration run -- same model, same probe count --
    # so it does not violate "run once"; a checkpoint from a different model or probe count is
    # refused rather than merged.
    ckpt = Path(a.out).with_suffix(".probes_partial.json")
    ident = {"model": a.model, "provider": a.provider, "probes": a.probes, "candidates": a.candidates}
    if ckpt.exists():
        prev = json.loads(ckpt.read_text(encoding="utf-8"))
        if prev.get("ident") != ident:
            raise SystemExit(
                f"{ckpt} was written by a different calibration ({prev.get('ident')}); "
                "delete it to start over, or rerun with the original settings to resume."
            )
        record.update(prev.get("record", {}))
        print(f"resuming calibration: {len(record)} task(s) already probed")
    resumed_from = len(record)

    def save_ckpt() -> None:
        tmp = ckpt.with_suffix(".tmp")
        tmp.write_text(json.dumps({"ident": ident, "record": record}, indent=2), encoding="utf-8")
        tmp.replace(ckpt)

    async def one(t: Task):
        if t.id in record:
            return
        async with sem:
            record[t.id] = await probe(t, throttled, a.probes, errors)
            n = len(record)
            if n % 10 == 0:
                print(f"  {n}/{len(graded)} probed")
                save_ckpt()

    try:
        await asyncio.gather(*(one(t) for t in graded))
    finally:
        save_ckpt()
        try:
            await shared.close()
        except Exception:
            pass

    complete = [t for t in graded if None not in record[t.id]]
    incomplete = len(graded) - len(complete)
    discriminating = [t for t in complete if not all(record[t.id])]
    always_right = len(complete) - len(discriminating)
    kept = (prepend + discriminating)[: a.keep]
    if errors:
        print(f"\n{len(errors)} probe errors (first 5):")
        for e in errors[:5]:
            print("  " + e)
    if incomplete:
        print(f"\n{incomplete} tasks had at least one failed probe and were EXCLUDED from selection")
        if incomplete > len(graded) // 4:
            print(
                "  More than a quarter failed: this is rate limiting. Re-run with lower --concurrency "
                "(e.g. 1) and --max-inflight (e.g. 2)."
            )
    out = Path(a.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(
        "\n".join(
            json.dumps(
                {
                    "id": t.id,
                    "family": t.family,
                    "prompt": t.prompt,
                    "answer": t.answer,
                    "grader": t.grader,
                    "metadata": {**t.metadata, "calibration_probes": record[t.id]},
                },
                ensure_ascii=True,
            )
            for t in kept
        )
        + "\n",
        encoding="ascii",
    )
    digest = hashlib.sha256(out.read_bytes()).hexdigest()
    report = {
        "resumed_from_checkpoint": resumed_from,  # disclosed: 0 means one uninterrupted pass
        "rule": f"keep the first {a.keep} candidates (file order) that the model answers incorrectly at least once in {a.probes} single-specialist probes",
        "provider": a.provider,
        "model": a.model,
        "candidates": len(graded),
        "probes": a.probes,
        "always_correct": always_right,
        "discriminating": len(discriminating),
        "kept": len(kept),
        "excluded_incomplete": incomplete,
        "probe_errors": errors,
        "output": str(out),
        "output_sha256": digest,
        "probe_results": record,
    }
    rep_path = out.with_suffix(".calibration.json")
    rep_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print()
    print(
        f"always correct: {always_right}/{len(graded)}   discriminating: {len(discriminating)}   kept: {len(kept)}"
    )
    print(f"wrote {out}  (sha256 {digest[:16]}...)")
    print(f"calibration record: {rep_path}")
    if len(kept) < a.keep:
        print(
            f"WARNING: only {len(kept)} discriminating tasks found; generate more candidates (larger --count) and re-run"
        )
    return 0


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Difficulty calibration of candidate tasks")
    ap.add_argument("--provider", default="anthropic", choices=("anthropic", "openai"))
    ap.add_argument("--model", required=True)
    ap.add_argument("--api-key", default="")
    ap.add_argument("--candidates", required=True)
    ap.add_argument("--keep", type=int, default=40)
    ap.add_argument("--probes", type=int, default=3)
    ap.add_argument("--out", required=True)
    ap.add_argument("--force", action="store_true", help="overwrite an existing output file")
    ap.add_argument(
        "--prepend",
        default="",
        help="already-calibrated task file whose tasks are kept first without re-probing",
    )
    ap.add_argument("--concurrency", type=int, default=2, help="tasks probed at once; keep low, rate limits")
    ap.add_argument("--max-inflight", type=int, default=3, help="provider requests in flight at once")
    ap.add_argument("--yes", action="store_true")
    return asyncio.run(main_async(ap.parse_args(argv)))


if __name__ == "__main__":
    raise SystemExit(main())
