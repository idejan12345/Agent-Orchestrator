"""Check that the manuscript's numbers are the numbers in the data.

Recomputes, from the released records, every figure in the tables most likely to drift and compares
it with what the evaluation paper, paper/evaluation/cpo_evaluation.tex, prints:

  * the live-results table      <- eval/runs/main-minimal-haiku/runs.jsonl
  * the fixed-budget decomposition <- eval/runs/poolshape-haiku/runs.jsonl
  * the offline-replay table    <- eval/replay/offline_replay.json
  * the output-ceiling sensitivity table and its draw count <- eval/replay/truncation_sensitivity.json
  * the version string and the test count quoted in the implementation appendix

A hand audit in 0.9.4 found five discrepancies of this kind (two rounding slips, two third-decimal
values from an ad-hoc seed, a stale test count); this makes the audit a gate instead of a chore.

    python scripts/check_paper_numbers.py        # exit 0 = every checked number matches
"""

from __future__ import annotations

import json
import re
import subprocess  # nosec B404 - fixed argv, no shell
import sys
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TEX = ROOT / "paper" / "evaluation" / "cpo_evaluation.tex"
EVIDENCE = ROOT / "release" / "evidence" / "paper_numbers.json"

LIVE_NAMES = {
    "best-of-$n$ (judge)": "best_of_n",
    "debate": "debate",
    "self-consistency": "self_consistency",
    "CPO": "cpo",
    "CPO $-$ consensus": "cpo_no_consensus",
    "CPO $-$ reconfirmation": "cpo_no_reconfirmation",
    "CPO, judged writer": "cpo_judged",
}
POOL_NAMES = {
    r"$12\times1$": "cpo_pool12x1",
    r"$6\times2$": "cpo_pool6x2",
    r"$4\times3$": "cpo_pool4x3",
    r"$3\times4$": "cpo_pool3x4",
    r"$2\times6$": "cpo_pool2x6",
    r"$11\times1$": "cpo_pool11x1_judged_nosel",
}


def table_body(tex: str, label: str) -> str:
    lab = tex.index(f"\\label{{{label}}}")
    # the tabular inside the same table environment, whether the caption sits above or below it
    env = tex.rindex("\\begin{table}", 0, lab)
    env_end = tex.index("\\end{table}", lab)
    start = tex.index("\\begin{tabular}", env, env_end)
    return tex[start : tex.index("\\end{tabular}", start)]


def cells(row: str) -> list[str]:
    """Split one tabular row; drop booktabs rules that the split glues onto the first cell (a
    leading "\\midrule" once made this checker silently skip the whole live-results table)."""
    row = re.sub(r"\\(toprule|midrule|bottomrule)\b", "", row)
    return [c.strip() for c in row.split("&")]


def numbers(cell: str) -> list[float]:
    cell = cell.replace("\\mathbf", "")
    return [float(x) for x in re.findall(r"(?<![\w.])\d+\.\d+|(?<![\w.])\d+(?![\w.])", cell)]


def recompute(path: Path) -> dict[tuple[str, str], dict]:
    latest = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.strip():
            r = json.loads(line)
            latest[(r["task_id"], r["method"], r["condition"], r["seed"])] = r
    cells: dict = defaultdict(lambda: {"n": 0, "ok": 0, "ln": 0, "lk": 0, "calls": 0, "tok": 0})
    for r in latest.values():
        if r.get("error"):
            continue
        c = cells[(r["condition"], r["method"])]
        c["n"] += 1
        c["ok"] += bool(r["correct"])
        c["calls"] += r["calls"]
        c["tok"] += r["prompt_tokens"] + r["completion_tokens"]
        if r.get("blind_supported") is not None:
            c["ln"] += 1
            c["lk"] += not r["blind_supported"]
    return {
        k: {
            "quality": c["ok"] / c["n"],
            "lock": c["lk"] / c["ln"] if c["ln"] else None,
            "calls": c["calls"] / c["n"],
            "ktok": c["tok"] / c["n"] / 1000,
        }
        for k, c in cells.items()
    }


def round_half_up(x: float, places: int) -> float:
    q = 10**places
    return int(x * q + 0.5 + 1e-9) / q


def main() -> int:
    tex = TEX.read_text(encoding="utf-8")
    problems: list[str] = []
    checked = 0
    rows_seen = {"live": 0, "poolshape": 0, "replay": 0, "truncation": 0}

    def same(label: str, printed: float, actual: float | None, places: int) -> None:
        nonlocal checked
        checked += 1
        if actual is None or abs(printed - round_half_up(actual, places)) > 10 ** (-places) / 2:
            problems.append(f"{label}: paper prints {printed}, data gives {actual}")

    # ---- live-results table
    live = recompute(ROOT / "eval" / "runs" / "main-minimal-haiku" / "runs.jsonl")
    condition = None
    for row in table_body(tex, "tab:live").split("\\\\"):
        cols = cells(row)
        if len(cols) < 6:
            continue
        if cols[0] == "clean":
            condition = "clean"
        elif cols[0].startswith("history"):
            condition = "history_locking"
        name = re.sub(r"\s*\(\\S\\ref\{[^}]*\}\)", "", cols[1]).strip()
        method = LIVE_NAMES.get(name)
        if not method or condition is None:
            continue
        rows_seen["live"] += 1
        got = live.get((condition, method))
        q, lock = numbers(cols[2])[0], numbers(cols[3])[0]
        calls, ktok = numbers(cols[4])[0], numbers(cols[5])[0]
        tag = f"live {condition}/{method}"
        same(f"{tag} quality", q, got and got["quality"], 3)
        same(f"{tag} lock", lock, got and got["lock"], 3)
        same(f"{tag} calls", calls, got and got["calls"], 1)
        same(f"{tag} tokens", ktok, got and got["ktok"], 1)

    # ---- fixed-budget decomposition
    pool = recompute(ROOT / "eval" / "runs" / "poolshape-haiku" / "runs.jsonl")
    for row in table_body(tex, "tab:poolshape").split("\\\\"):
        cols = cells(row)
        if len(cols) < 5:
            continue
        key = next((v for k, v in POOL_NAMES.items() if cols[0].startswith(k)), None)
        if not key:
            continue
        rows_seen["poolshape"] += 1
        got = pool.get(("clean", key))
        tag = f"poolshape {key}"
        same(f"{tag} quality", numbers(cols[2])[0], got and got["quality"], 3)
        same(f"{tag} lock", numbers(cols[3])[0], got and got["lock"], 3)
        same(f"{tag} calls", numbers(cols[4])[0], got and got["calls"], 1)

    # ---- offline replay table
    replay = json.loads((ROOT / "eval" / "replay" / "offline_replay.json").read_text(encoding="utf-8"))["table"]
    rows = {
        "plurality of 3 draws": "SC-3",
        "plurality of 6 draws": "SC-6",
        "plurality of 9 draws": "SC-9",
        "CPO selection rule": "CPO-emul",
        "adaptive: stop": "D2-adaptive",
        "CPO, acting": "D3-acting",
        "correct answer present": "Oracle-9",
    }
    for row in table_body(tex, "tab:replay").split("\\\\"):
        cols = cells(row)
        key = next((v for k, v in rows.items() if cols[0].startswith(k)), None)
        if not key or len(cols) < 4:
            continue
        rows_seen["replay"] += 1
        r = replay[key]
        same(f"replay {key} accuracy", numbers(cols[1])[0], r["accuracy"], 3)
        if r["lock_rate"] is not None:
            same(f"replay {key} lock", numbers(cols[2])[0], r["lock_rate"], 3)
        nd = numbers(cols[3])[0]
        same(f"replay {key} draws", nd, r["mean_draws"], 2 if nd != int(nd) else 0)

    # ---- output-ceiling sensitivity table (Appendix: deviations)
    trunc = json.loads(
        (ROOT / "eval" / "replay" / "truncation_sensitivity.json").read_text(encoding="utf-8")
    )
    trunc_rows = {
        "best-of-$n$ (judge)": "best_of_n",
        "debate": "debate",
        "self-consistency": "self_consistency",
        "CPO": "cpo",
    }
    for row in table_body(tex, "tab:truncation").split("\\\\"):
        cols = cells(row)
        method = trunc_rows.get(cols[0]) if len(cols) == 5 else None
        if not method:
            continue
        rows_seen["truncation"] += 1
        for col, (cond, which) in zip(
            cols[1:],
            [("clean", "all_tasks"), ("clean", "excluding_heavy"),
             ("history_locking", "all_tasks"), ("history_locking", "excluding_heavy")],
        ):
            same(f"truncation {cond}/{method} {which}", numbers(col)[0],
                 trunc["quality"][f"{cond}|{method}"][which], 3)
    m_draws = re.search(r"Of the \$(\d+)\$ self-consistency draws, \$(\d+)\$", tex)
    checked += 1
    if not (m_draws and int(m_draws.group(1)) == trunc["self_consistency_draws"]
            and int(m_draws.group(2)) == trunc["draws_without_answer_line"]):
        problems.append("output-ceiling draw counts in the deviations appendix do not match the data")

    # ---- version and test count
    sys.path.insert(0, str(ROOT / "src"))
    from cpo.version import __version__

    checked += 1
    if f"cpo-orchestrator {__version__}" not in tex:
        problems.append(f"paper does not name cpo-orchestrator {__version__}")
    out = subprocess.run(  # nosec B603 - fixed argv, no shell
        [sys.executable, "-m", "pytest", "--collect-only", "-q", "-o", "addopts="],
        cwd=ROOT, capture_output=True, text=True, check=False,
    ).stdout
    m = re.search(r"(\d+) tests? collected", out)
    stated = re.search(r"Verification: (\d+) tests", tex)
    checked += 1
    if not (m and stated and int(m.group(1)) == int(stated.group(1))):
        problems.append(
            f"paper states {stated and stated.group(1)} tests; the suite collects {m and m.group(1)}"
        )

    # A checker that silently parses fewer rows than the tables contain is worse than none.
    expected = {"live": 14, "poolshape": 6, "replay": 7, "truncation": 4}
    for table, want in expected.items():
        if rows_seen[table] != want:
            problems.append(f"parsed {rows_seen[table]} rows of the {table} table, expected {want}")
    report = {"checked": checked, "rows_parsed": rows_seen, "mismatches": problems, "passed": not problems}
    EVIDENCE.parent.mkdir(parents=True, exist_ok=True)
    EVIDENCE.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(f"{checked} numbers checked; {len(problems)} mismatch(es)")
    for p in problems:
        print("  -", p)
    return 0 if not problems else 6


if __name__ == "__main__":
    raise SystemExit(main())
