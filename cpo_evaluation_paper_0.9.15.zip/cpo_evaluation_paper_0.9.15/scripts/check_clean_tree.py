"""Fail if the working tree carries runtime artifacts that must not ship in a release.

The .gitignore already excludes these, but a release built by archiving the working directory
(rather than by `git archive`) will happily include them, which is how `.ruff_cache/` and a live
`cpo-traces.jsonl` reached the 0.9.2 zip.  This check is part of the release gate so that the
mistake fails loudly instead of shipping.

Usage:  python scripts/check_clean_tree.py [--fix]
"""

from __future__ import annotations

import argparse
import json
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / "release" / "evidence" / "clean_tree.json"

# (glob, why it must not ship)
FORBIDDEN: list[tuple[str, str]] = [
    (".ruff_cache", "linter cache"),
    (".pytest_cache", "test cache"),
    (".mypy_cache", "type-checker cache"),
    ("__pycache__", "compiled bytecode"),
    ("build", "build scratch directory"),
    ("*.egg-info", "build metadata"),
    ("*.pyc", "compiled bytecode"),
    ("cpo-traces.jsonl", "live trace log from a local run"),
    ("*.jsonl.lock", "trace lock file"),
    ("reports/staging-traces-*.jsonl", "staging trace log"),
    (".venv", "virtual environment"),
    (".env", "local environment file, may hold credentials"),
    ("*.probes_partial.json", "interrupted-calibration checkpoint"),
    ("*.json.tmp", "half-written checkpoint"),
]


def offenders() -> list[dict]:
    found: list[dict] = []
    for pattern, why in FORBIDDEN:
        for path in ROOT.rglob(pattern):
            if ".git/" in str(path):
                continue
            found.append(
                {
                    "path": str(path.relative_to(ROOT)),
                    "reason": why,
                    "bytes": path.stat().st_size if path.is_file() else None,
                }
            )
    return sorted(found, key=lambda d: d["path"])


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Release-tree cleanliness check")
    ap.add_argument("--fix", action="store_true", help="delete the offending paths instead of only reporting")
    a = ap.parse_args(argv)

    found = offenders()
    if a.fix:
        for entry in found:
            target = ROOT / entry["path"]
            if target.is_dir():
                shutil.rmtree(target, ignore_errors=True)
            elif target.exists():
                target.unlink()
        found = offenders()

    report = {"clean": not found, "offenders": found}
    EVIDENCE.parent.mkdir(parents=True, exist_ok=True)
    EVIDENCE.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
    if found:
        print(
            f"\n{len(found)} artifact(s) must not ship. Remove them (or rerun with --fix), "
            "then regenerate SHA256SUMS.",
            file=sys.stderr,
        )
    return 0 if not found else 4


if __name__ == "__main__":
    raise SystemExit(main())
