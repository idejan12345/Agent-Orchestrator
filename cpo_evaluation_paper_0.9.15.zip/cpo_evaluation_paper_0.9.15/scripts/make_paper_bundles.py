"""Build the two release bundles, one per paper, each with the code that paper needs.

  cpo_theory_paper_<version>/      theory paper + the package without the evaluation harness, the
                                   theory tests, and the scripts that regenerate and check every
                                   table and figure of that paper. Self-contained: tests, number
                                   check and LaTeX build all run inside it.
  cpo_evaluation_paper_<version>/  evaluation paper + the whole SDK: evaluation harness, run
                                   records, replay, audit scripts and number check. It also carries
                                   the theory paper, which the evaluation paper cites throughout.

The two overlap in the package itself (src/cpo), as they should: both papers describe one system.

    python scripts/make_paper_bundles.py --out dist/bundles
"""

from __future__ import annotations

import argparse
import hashlib
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from cpo.version import __version__  # noqa: E402

SKIP_PARTS = {"__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache", "build", ".venv", "bundles"}
SKIP_SUFFIXES = {".pyc", ".aux", ".log", ".out"}

THEORY_FILES = [
    "LICENSE",
    "pyproject.toml",
    "src",
    "tests",
    "examples",
    "docs/THEORY_MAPPING.md",
    "docs/ARCHITECTURE.md",
    "scripts/paper_experiments.py",
    "scripts/paper_figures.py",
    "scripts/check_theory_numbers.py",
    "scripts/check_pdf_refs.py",
    "paper/theory",
]
THEORY_EXCLUDE = {"src/cpo/eval", "tests/test_eval.py"}

THEORY_MAKEFILE = """PY ?= python3

.PHONY: install test lint type experiments figures census plane papercheck paper check

install:   ## editable install with dev tools
\t$(PY) -m pip install -e ".[dev]"

test:
\t$(PY) -m pytest -q -o addopts="" -W ignore

lint:
\truff check src tests scripts examples

type:
\tmypy src

check: lint type test

# Every table and figure of the controlled-experiments section, from fixed seeds (~2.5 min).
experiments:
\t$(PY) scripts/paper_experiments.py > /dev/null && $(PY) scripts/paper_figures.py

figures:
\t$(PY) scripts/paper_figures.py

# Appendix B: the source model's census and information coordinates, reimplemented.
census:
\t$(PY) -m cpo.cli --out census_report.json

plane:
\t$(PY) -c "from cpo.cli import plane_main; plane_main(['--out','plane_report.json','--length','200000','--offsets','100000'])"

# Every value in the experiment tables, the version and the test count, against the data.
papercheck:
\t$(PY) scripts/check_theory_numbers.py

paper:
\tcd paper/theory && for i in 1 2 3; do pdflatex -interaction=nonstopmode cpo_theory.tex >/dev/null; done
\t$(PY) scripts/check_pdf_refs.py paper/theory/cpo_theory.pdf
\trm -f paper/theory/*.aux paper/theory/*.log paper/theory/*.out
"""

THEORY_README = """# Select-consensus dynamics for multi-agent orchestration — theory paper and code

Manuscript: `paper/theory/cpo_theory.tex` (PDF alongside). Package: `cpo-orchestrator {version}`,
without its evaluation harness, which ships with the companion evaluation paper.

The paper states a select-consensus dynamical system on binary registers, proves the results it
uses, transfers the map to text-level orchestration with each result classified by what survives,
specifies the Chosen-Pattern Orchestrator, states when selection toward a reference can help a
decision (Proposition 1), and tests H1-H3 on fully specified synthetic pools. It makes no claim
about language-model tasks; those are the subject of the companion paper.

| what | where |
|---|---|
| register formalism and theorem tests | `src/cpo/focus/`, `tests/test_register_theorems.py` |
| transferred loop, occupancy cap, blind reconfirmation | `src/cpo/focus_loop.py`, `occupancy.py`, `reconfirmation.py` |
| orchestrator and service | `src/cpo/orchestrator.py`, `api.py`, `gateway.py` |
| controlled experiments (Section 6) | `scripts/paper_experiments.py` -> `paper/theory/experiments.json` |
| figures | `scripts/paper_figures.py` -> `paper/theory/figures/` |
| census and coordinates (Appendix B) | `cpo-census`, `cpo-plane` |
| every table value checked against the data | `scripts/check_theory_numbers.py` |

```bash
pip install -e ".[dev]"
make test          # the theory and system tests
make experiments   # regenerate experiments.json and the figures from fixed seeds (~2.5 min)
make papercheck    # every printed table value, the version and the test count, against the data
make paper         # compile the manuscript
```

`SHA256SUMS` lists a checksum for every file in this bundle.
"""


def wanted(rel: Path) -> bool:
    if any(part in SKIP_PARTS for part in rel.parts) or rel.suffix in SKIP_SUFFIXES:
        return False
    return not any(rel.as_posix() == x or rel.as_posix().startswith(x + "/") for x in THEORY_EXCLUDE)


def copy_tree(items: list[str], dest: Path, filt) -> None:
    for item in items:
        src = ROOT / item
        paths = [src] if src.is_file() else sorted(p for p in src.rglob("*") if p.is_file())
        for p in paths:
            rel = p.relative_to(ROOT)
            if filt(rel):
                (dest / rel).parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(p, dest / rel)


def checksums(dest: Path) -> None:
    lines = []
    for p in sorted(x for x in dest.rglob("*") if x.is_file() and x.name != "SHA256SUMS"):
        lines.append(f"{hashlib.sha256(p.read_bytes()).hexdigest()}  ./{p.relative_to(dest).as_posix()}")
    (dest / "SHA256SUMS").write_text("\n".join(lines) + "\n", encoding="utf-8")


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--out", default="dist/bundles")
    a = ap.parse_args(argv)
    # Refuse to bundle a manuscript whose PDF has unresolved references (run `make paper` first).
    sys.path.insert(0, str(ROOT / "scripts"))
    from check_pdf_refs import problems

    bad = [
        p
        for pdf in ("paper/theory/cpo_theory.pdf", "paper/evaluation/cpo_evaluation.pdf")
        for p in problems(ROOT / pdf)
    ]
    if bad:
        print("\n".join(bad) + "\nrefusing to bundle; run `make paper` first", file=sys.stderr)
        return 2
    out = (ROOT / a.out).resolve()
    out.mkdir(parents=True, exist_ok=True)

    theory = out / f"cpo_theory_paper_{__version__}"
    shutil.rmtree(theory, ignore_errors=True)
    copy_tree(THEORY_FILES, theory, wanted)
    (theory / "Makefile").write_text(THEORY_MAKEFILE, encoding="utf-8")
    (theory / "README.md").write_text(THEORY_README.format(version=__version__), encoding="utf-8")
    checksums(theory)

    evaluation = out / f"cpo_evaluation_paper_{__version__}"
    shutil.rmtree(evaluation, ignore_errors=True)
    top = [p.name for p in ROOT.iterdir() if p.name not in {"dist", ".git"} | SKIP_PARTS]
    copy_tree(
        top,
        evaluation,
        lambda rel: not any(part in SKIP_PARTS for part in rel.parts) and rel.suffix not in SKIP_SUFFIXES,
    )
    if (ROOT / "dist").is_dir():  # the built wheel and sdist, not the bundles themselves
        copy_tree(
            [f"dist/{p.name}" for p in (ROOT / "dist").iterdir() if p.is_file()], evaluation, lambda rel: True
        )
    checksums(evaluation)

    for b in (theory, evaluation):
        n = sum(1 for x in b.rglob("*") if x.is_file())
        print(f"{b.name}: {n} files")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
