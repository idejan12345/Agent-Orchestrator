# Evaluation runs

New runs written here are local and ignored by git (`eval/runs/*` in `.gitignore`).

Two directories are **released evidence** and are tracked explicitly:

| directory | what it is | used by |
|---|---|---|
| `main-minimal-haiku/` | the preregistered minimal-profile run (Claude Haiku 4.5, 40 calibrated arithmetic tasks, 6 methods + judged writer, clean and history-locking) | the paper's live-results table; `scripts/offline_replay.py`; `scripts/check_paper_numbers.py` |
| `poolshape-haiku/` | the fixed-budget decomposition (pool x cycles at 12 calls, and the selection-disabled row) | the paper's decomposition table; `scripts/check_paper_numbers.py` |

Each holds `runs.jsonl` (one record per run; a retried run's later record supersedes the earlier
one) and `summary.json`. Do not edit them: `make papercheck` recomputes the paper's tables from
these files and fails on any difference, and the replay's grader validation reads them too.

Write new runs to a fresh directory (`--out eval/runs/<name>`); resuming into a directory written
under a different budget, blind test, signature, output ceiling or model is refused.
