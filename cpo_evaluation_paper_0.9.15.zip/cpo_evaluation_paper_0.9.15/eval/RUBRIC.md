# Rating rubric for drafting tasks (planning, synthesis) — fixed before rating

Score each answer 0-3 on the question asked, blind to method.

| score | meaning |
|---|---|
| 3 | Correct and complete; specific, concrete, well organised; addresses every part of the question; no factual or technical errors. |
| 2 | Largely correct and useful; minor omission, vagueness, or one small error; organisation adequate. |
| 1 | Partially relevant; generic, incomplete, or contains a substantive error; would need significant work to use. |
| 0 | Off-topic, empty, incoherent, or fundamentally wrong. |

Word-limit tasks: exceeding the limit by more than 25% caps the score at 2.
Multi-part questions ("give two mitigations and the order"): missing a part caps the score at 1.

Pass threshold for "quality" in the summary: mean rating >= 2.0.
