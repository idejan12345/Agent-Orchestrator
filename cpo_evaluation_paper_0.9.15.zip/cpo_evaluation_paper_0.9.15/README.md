# Chosen-Pattern Orchestrator (CPO) SDK 0.9.15

An agent-orchestration SDK whose control loop is a *select–consensus dynamical system*: candidates
are scored by similarity to a shared reference, the resonant subset is selected, the selected
signatures are voted into a new reference, the loop iterates to a fixed point, and the fixed point
is then tested by re-querying the specialists *blind*. The system's properties are theorems on
binary registers (selection alone only erodes order; consensus creates it; self-sustaining fixed
points exist and are detectable by a blind re-draw); on text they are hypotheses, and the package
ships the harness that tests them against best-of-n, self-consistency and debate at matched budget.

The dynamical system was formulated in *A model for consciousness from binary sequences: You are the ordering that the world must have to hold you* (D. Stojkovic, manuscript, September 2026) for an
unrelated purpose. This package uses its mathematics and nothing else; nothing here measures or
claims anything about that manuscript's subject matter, and response fields carry the status
string `engineering_quantities_not_consciousness_measurements`. The package supersedes the SGWM
Orchestrator SDK 0.7.1 (see `MIGRATION_0.7_TO_0.8.md`).

## The two papers

The work is reported in two manuscripts, each built and number-checked from this repository.

| | theory paper | evaluation paper |
|---|---|---|
| file | `paper/theory/cpo_theory.tex` | `paper/evaluation/cpo_evaluation.tex` |
| subject | the select–consensus map, its theorems, the transfer to text, the algorithm, Proposition 1, controlled tests of H1–H3 | the preregistered live run, the fixed-budget decomposition, the offline replay, deviations, the next protocol |
| data | `paper/theory/experiments.json`, figures | `eval/runs/`, `eval/replay/` |
| regenerate | `make experiments`, `make census`, `make plane` | `scripts/offline_replay.py`, `scripts/truncation_sensitivity.py` |
| number check | `scripts/check_theory_numbers.py` | `scripts/check_paper_numbers.py` |

`make papercheck` runs both checks; `make paper` compiles both. The theory paper makes no claim about
language-model tasks. A release bundle of each paper with the code it needs is built by
`scripts/make_paper_bundles.py`.

**What the evidence shows so far.** On single-answer arithmetic with one model (evaluation paper), CPO does
*not* beat the baselines; a fixed-budget decomposition attributes the deficit to one step,
reference-relative selection, which discards correct dissenters when the reference carries no
information about correctness. Whether selection toward a reference helps where the reference is a
draft worth preserving is the open experiment (`docs/PROTOCOL_V2.md`).

**What convergence is good for instead (offline replay, 0.9.4).** Replaying the run's own stored
draws under rules fixed in advance (`docs/OFFLINE_REPLAY_PREREG.md`, `scripts/offline_replay.py`):
the convergence criterion used as a *stopping rule* over blind batches matches plurality voting at
70% of the draws, and failing to converge locates most of the errors a verifier could fix. Two
methods built on that — `cpo_adaptive` and `cpo_gated_judge` — are preregistered (H6, H7) for the
next run; neither has been run against a live model yet.

## The loop

```
0. fix a reference      the request itself seeds the reference signature
1. resonate             score every candidate relative to the reference (1 - d_H/n)
2. select               keep the top-phi fraction, capped by the capacity theorem at current occupancy
3. consensus            position-wise majority vote, ties retaining the previous bit
4. iterate              until the reference is a fixed point, a cycle appears, or the budget ends
5. reconfirm            re-query specialists blind; does a fresh pool re-select the same fixed point?
```

Step 2 alone can only erode order (the paper's affine selection law); the loop never skips step 3
and warns when a cycle degenerates to a single selection.

## Two layers

| layer | module | fidelity |
|---|---|---|
| register formalism (bit sequences) | `cpo.focus` | exact: theorems reproduced and tested |
| text orchestration (specialist candidates) | `cpo.orchestrator`, `cpo.focus_loop` | signatures via SimHash; direct Hamming resonance; binding as a min-cut overlap proxy |

`docs/THEORY_MAPPING.md` lists every construct with an *exact / proxy / not transferred* label.

## Reproduce the paper's computed tables

```bash
pip install -e ".[dev]"
pytest                                   # theorem tests cite the theory paper's results
cpo-census --out release/evidence/census_report.json     # ~30 s; 600 runs at n=24, N=2e4
cpo-plane  --out release/evidence/plane_report.json      # ~15 s; six archetypes in the (W, M*) plane
```

Shipped evidence (`release/evidence/`, all produced by the shipped code — see `release/evidence/README.md`): census over three seeds gives 99.5–100 % fixed points,
non-motif fixed points in 3–7 % of runs (pooled 5.5 %, exact 95 % CI [3.8 %, 7.6 %]), settling in
~2 iterations, and non-motif attractors at mean Hamming distance 2.3–2.7 from the nearest chimera
against 6.7–6.9 for random sequences. The archetype plane dissociates: dreamer (W≈0.00, M\*≈0.57),
animal (W≈0.81, M\*≈0.07), noise at the origin. Absolute M\* values differ from the paper's table,
as the paper says to expect.

## Signature backends

Resonance is computed on binary signatures. The default `SimHashSigner` hashes word shingles;
`ThresholdedVectorSigner(embed, n)` adapts any deterministic embedding function so the loop's
algebra is unchanged while the kernel becomes semantic. Pass `signer=` to `Orchestrator`
(its length must equal `signature_bits`).

## Command line

```bash
cpo-run "Summarize the incident review and propose mitigations." --compact   # focus loop with echo specialists
cpo-census --out release/evidence/census_report.json                        # attractor census
cpo-plane  --out release/evidence/plane_report.json                         # (W, M*) archetype plane
make check         # ruff + mypy + pytest
make evidence      # regenerate every local evidence file and evaluate the release gate
make paper         # compile both manuscripts (paper/theory, paper/evaluation)
```

## Evaluation with real models

The preregistered H4/H5 protocol is executable. Dry-run it offline first:

```bash
PYTHONPATH=src python scripts/run_evaluation.py --provider mock \
  --tasks eval/tasks/example.jsonl --out eval/runs/dryrun
```

Then see `docs/EVALUATION_RUNBOOK.md` for the phased procedure, cost model and reporting checklist.
Seven methods (best-of-n, self-consistency, debate, CPO and three ablations) run under a shared
call budget; the blind support test that defines history-locked convergence is applied identically
to all of them.

## Run the API

```bash
CPO_GATEWAY_SECRET=... CPO_METRICS_TOKEN=... cpo-api
```

Endpoints: `POST /v1/orchestrate`, `GET /health/live`, `GET /health/ready`, `GET /metrics`.
Requests must carry a gateway assertion signed with `CPO_GATEWAY_SECRET` over principal,
timestamp, method, path and body SHA-256 (headers `x-cpo-principal`, `x-cpo-timestamp`,
`x-cpo-signature`, `x-cpo-roles`). Per-principal token-bucket and concurrency quotas apply.

## Response anatomy

- `workspace.terminal_kind`: `fixed_point | cycle | budget_exhausted`
- `workspace.occupancy`: register occupancy, holdable alternatives, regime, selection cap
- `cycles[].reference_delta`: XOR of consecutive references (the reference-independent map)
- `reconfirmation.status`: `reconfirmed | not_reconfirmed | untested | unavailable` (tie-retaining test, biased toward acceptance)
- `reconfirmation.strict_status`: the recommended verdict; `reconfirmed` only if `status` is and `blind_consensus_distance` (expected distance to the whole fresh pool's majority under random tie-breaking) is within `reconfirmation_theta`
- `diagnostics.plane_proxy`: bitwise W / M\* trajectory proxies (null below three cycles)

## Approved pilot scope

Single tenant, non-sensitive internal drafting, summarization, analysis and planning, with human
review before external action. High-impact decisions, credential actions, sensitive personal data
and consciousness claims remain prohibited by `EnterpriseKnowledgeWorkPolicy`.

## Release gates (0.9.0)

| gate | status |
|---|---|
| unit tests (91), ruff, mypy | GO |
| census structure, plane dissociation | GO |
| bandit SAST, pip-audit of the wheel's runtime closure, CycloneDX SBOM | GO |
| local load test, staging validation over real HTTP (16 checks) | GO |
| provider smoke tests (need API credentials) | pending |
| container image scan (needs registry + scanner) | pending |

`scripts/release_gate.py` is fail-closed: the decision stays NO-GO until the last two have
evidence. See `docs/DEPLOYMENT_GATES.md` and `release/evidence/go_no_go.json`.

`CPO_QUOTA_BURST` must be at least `max_cycles + reconfirmation_rounds` (7 by default); the
service logs a warning at startup otherwise.
