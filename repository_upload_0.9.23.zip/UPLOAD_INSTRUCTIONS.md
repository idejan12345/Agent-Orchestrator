# Updating https://github.com/idejan12345/Agent-Orchestrator to version 0.9.23

The folder Agent-Orchestrator/ is the repository root: put its contents at the top level of the
repository, so that README.md, Makefile, src/, tests/, scripts/ and papers/ are browsable on GitHub.

1. Delete cpo_evaluation_paper_0.9.15.zip from the repository. It is outdated and contains the
   evaluation-paper draft that the submitted paper no longer refers to. (If you want to keep it,
   move it to a private repository.)
2. Upload the contents of Agent-Orchestrator/. On the GitHub website: "Add file" -> "Upload files",
   drag in everything inside the folder, and commit. With git:
       git clone https://github.com/idejan12345/Agent-Orchestrator.git
       cd Agent-Orchestrator && git rm cpo_evaluation_paper_0.9.15.zip
       (copy the contents of Agent-Orchestrator/ here)
       git add -A && git commit -m "cpo-orchestrator 0.9.23: code and data for the theory paper"
       git push
3. The package's LICENSE replaces the repository's current one. Both are MIT; the new one names
   D. Stojkovic as copyright holder instead of the GitHub user name.
4. Create a release tagged v0.9.23 (GitHub: "Releases" -> "Draft a new release"), so the paper's
   version number points at a fixed snapshot. Optionally connect the repository to Zenodo first,
   and the release gets a DOI automatically.
