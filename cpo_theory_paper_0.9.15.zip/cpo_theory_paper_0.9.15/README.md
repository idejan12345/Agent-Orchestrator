# Select-consensus dynamics for multi-agent orchestration — theory paper and code

Manuscript: `paper/theory/cpo_theory.tex` (PDF alongside). Package: `cpo-orchestrator 0.9.15`,
without its evaluation harness, which ships with the companion evaluation paper.

The paper states a select-consensus dynamical system on binary registers, proves the results it
uses, transfers the map to text-level orchestration with each result classified by what survives,
specifies the Chosen-Pattern Orchestrator, states when selection toward a reference can help a
decision (Proposition 1), and tests H1-H3 on fully specified synthetic pools. It makes no claim
about language-model tasks; those are the subject of the companion paper.

| what | where |
|---|---|
| register formalism and theorem tests | `src/cpo/focus/`, `tests/test_register_theorems.py` |
| transferred loop, occupancy cap, blind reconfirmation | `src/cpo/focus_loop.py`, `occupancy.py`, `reconfirmation.py` |
| orchestrator and service | `src/cpo/orchestrator.py`, `api.py`, `gateway.py` |
| controlled experiments (Section 6) | `scripts/paper_experiments.py` -> `paper/theory/experiments.json` |
| figures | `scripts/paper_figures.py` -> `paper/theory/figures/` |
| census and coordinates (Appendix B) | `cpo-census`, `cpo-plane` |
| every table value checked against the data | `scripts/check_theory_numbers.py` |

```bash
pip install -e ".[dev]"
make test          # the theory and system tests
make experiments   # regenerate experiments.json and the figures from fixed seeds (~2.5 min)
make papercheck    # every printed table value, the version and the test count, against the data
make paper         # compile the manuscript
```

`SHA256SUMS` lists a checksum for every file in this bundle.
