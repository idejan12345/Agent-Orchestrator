# Architecture

```
validate -> request policy -> [ collect -> candidate policy -> signatures + binding proxy
  -> hard-risk filter -> occupancy decision -> top-phi selection (capped) -> majority consensus
  -> consensus writer -> workspace policy -> broadcast -> trace -> terminate? ]
  -> environmental reconfirmation (blind re-collect) -> plane proxies -> consume -> trace
```

- **Specialists** are private pattern sources (`propose`, `receive_broadcast`). On a blind resample
  they are called with `workspace=None` and `context["_cpo_resample"]=r`; the API strips that key
  from client input so only the orchestrator can set it.
- **Reference**: a `Signature` produced by the configured `Signer` (default `SimHashSigner`, 256 bits;
  `ThresholdedVectorSigner` adapts embeddings). The seed is the request text.
- **Bundle**: at the end of a run the selected candidates are fused into a level-1 `Bundle` whose
  correlation matrix ships with it (`response.bundle`), bounded by the largest admissible bundle
  at the final occupancy.
- **Consensus writer**: `MedoidConsensusWriter` (deterministic, idempotent at a fixed point) or
  `ProviderConsensusWriter` (a model merges the selected candidates; falls back to the medoid).
- **Occupancy controller**: occupancy = atoms retained from the last cycle + incoming pool, clipped
  to `workspace_slots`; caps selection at floor(1 + (n/2)min(ν,1−ν)).
- **Termination**: repeat of a reference signature with period 1 = `fixed_point`; longer period =
  `cycle`; change below `fixed_point_threshold` also counts as fixed; otherwise `budget_exhausted`.
- **Traces**: hash-chained JSONL; each cycle records `reference_signature`, `reference_delta`
  (XOR with the previous reference) and its weight.
- All components declare `concurrency_safe=True`; per-request state lives in the run, not in the
  orchestrator.
