# Mapping the paper to CPO

Fidelity labels: **exact** (the paper's object, computed as stated and tested against its numbers),
**proxy** (same shape, different substrate, labelled as such in output), **policy** (a theorem used
as an engineering rule), **not transferred**.

| paper construct | where | fidelity | notes |
|---|---|---|---|
| Substratum Ω = {0,1}^n, pool with planted motifs | `focus/register.py: PoolSpec, make_pool` | exact | reference parameters n=24, N=2e4, μ=0.15, η=0.20 |
| Flip map d, kernel {0^n,1^n} | `flips` | exact | homomorphism tested |
| order(u) = 1 − wt(d(u))/(n−1) | `order` | exact | m1 = 0.957, m2 = 0.522 reproduced |
| Hamming theorem: resonance = order(s0 ⊕ p) | `resonance` | exact | 500 random checks in tests |
| Affine selection law E[order] = τ + (1−2τ)order(s0) | `selection_law_expectation` | exact | verified by sampling at three radii |
| Selection alone erodes order (Cor. eigen) | `focus_loop.py`, `config.consensus_required` | policy | consensus never skipped; `selection_only:consensus_degenerate` warning |
| Focus map F, top-φ, majority consensus, ties retain | `select`, `consensus`, `focus_map` | exact | Appendix repro items 1–4 |
| Fixed point / cycle termination, T_max | `iterate`, `FocusRun` | exact | orchestrator mirrors: `terminal_kind` |
| Veridical / non-motif classification, θ=3, complement equivalence | `classify` | exact | cycles reported separately |
| Chimeras (268 at n=24) | `chimeras` | exact | count tested |
| Census with exact binomial CI, ≥3 seeds | `focus/census.py`, `cpo-census` | exact | evidence shipped |
| Spurious attractors → blind resampling test (H2) | `reconfirmation.py` | proxy | blind re-query of specialists; `status` (tie-retaining) and `strict_status` (also requires the blind-consensus distance within theta; recommended) |
| Chimera structure of non-motif attractors | `recombination_test` | proxy | Jaccard on shingle sets: synthesis closer to a two-candidate union than any single one |
| Binding Φ_mc (min-cut MI) | `information.phi_mincut` | exact | XOR triple = 1 bit |
| Binding as a weight in w(p) | `binding.min_cut_binding` | proxy | one text is one sample; min over bipartitions of shingle overlap |
| Capacity theorem 1 + (n/2)min(ν,1−ν), B_max = 1 + n/4 | `focus/capacity.py` | exact | n=24 → 7; duty-cycle table rows reproduced |
| Admissible band, collapsing band, duty cycle | `capacity.py`, `occupancy.py` | policy | selection cap = floor(holdable); regime starved / admissible / saturated |
| n = 4(B_max − 1) | `register_from_span` | exact | 24 slots default |
| Abstraction tower: bundle B units *with correlations* | `tower.py: bundle, Bundle.serialize` | policy | bundled mode ships the correlation matrix |
| Serialisation bound (B−1)/(2B−1) | `serialisation_binding_bound` | exact | reported in flattened mode |
| World-model W = I(s0; ē) | `estimate_W` | exact | shuffle-corrected plug-in, 4-bit blocks |
| Conditional self-model M* = I(past; future \| ē), two-state conditioner | `estimate_M_star` | exact | documented as an upper bound (Remark residual) |
| Archetype generators and plane | `focus/archetypes.py`, `cpo-plane` | exact | dissociation reproduced; absolute values are construction artefacts |
| W / M* for an orchestration run | `plane.py: trajectory_plane` | proxy | bitwise over reference vs blind-pool consensus; null below 3 cycles |
| Intersubjectivity: the map is reference-independent | `CycleTrace.reference_delta` | policy | traces record XOR deltas of consecutive references |
| Count channel ½ log₂ n, SR/proper time, cosmology, hard problem | — | not transferred | no engineering content |
| The nine bridges (reference=self, fixed point=percept, …) | `diagnostics.bridges_not_asserted` | not asserted | listed so that they are visibly not used |

## The one substitution that matters

Signature positions are unordered hash slots, so the flip-domain form of resonance is exact only in
`cpo.focus`. At the text layer resonance is direct Hamming distance between SimHash signatures.
This keeps the loop's structure (relational scoring, majority consensus, fixed points, erosion under
selection-only) but the *order* of a text has no meaning here, and no output claims one.

## What replicates and what does not

The paper says the existence of non-motif fixed points and their chimera structure replicate; the
rate does not replicate to the digit. Our census gives 3–7 % across seeds against the paper's 9 %
and its independent reimplementation's 2–8 %. `release/evidence/census_report.json` states the
convergence criterion and motif tolerance used, as the Appendix requires.
