"""The paper's procedure on bit sequences: one run from a random reference to a fixed point."""

import random

from cpo.focus import PoolSpec, classify, iterate, make_pool, order, to_bits

spec, n = PoolSpec(), 24
pool = make_pool(spec, seed=1)
s0 = random.Random(0).getrandbits(n)
run = iterate(s0, pool, n, phi=0.10)
for t, s in enumerate(run.trajectory):
    print(f"t={t} {to_bits(s, n)} order={order(s, n):.3f}")
print(run.kind, classify(run, spec.resolved_motifs(), n))
