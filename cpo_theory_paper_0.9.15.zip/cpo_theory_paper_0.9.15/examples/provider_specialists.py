"""Three provider-backed specialists and a provider-written consensus step (credentials from env)."""

import asyncio
import os

from cpo.consumers import TextConsumer
from cpo.models import OrchestrationRequest
from cpo.orchestrator import Orchestrator
from cpo.provider_specialist import ProviderConsensusWriter, ProviderSpecialist
from cpo.providers import AnthropicMessagesConfig, AnthropicMessagesProvider


async def main():
    provider = AnthropicMessagesProvider(
        AnthropicMessagesConfig(model=os.environ["ANTHROPIC_MODEL"], api_key=os.environ["ANTHROPIC_API_KEY"])
    )
    roles = {
        "analyst": "Analyze the evidence.",
        "planner": "Propose concrete steps.",
        "critic": "Find weaknesses.",
    }
    specialists = [ProviderSpecialist(n, provider, role_instruction=r) for n, r in roles.items()]
    o = Orchestrator(specialists, [TextConsumer()], consensus_writer=ProviderConsensusWriter(provider))
    try:
        r = await o.run(OrchestrationRequest(input="Draft a rollback plan for the payments deployment."))
        print(r.workspace.terminal_kind, r.reconfirmation.status)
        print(r.workspace.synthesis)
    finally:
        await provider.close()


asyncio.run(main())
