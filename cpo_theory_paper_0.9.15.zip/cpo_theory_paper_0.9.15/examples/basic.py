"""Run the focus loop with built-in specialists and print the focus report."""

import asyncio
import json

from cpo.config import CPOConfig
from cpo.consumers import TextConsumer
from cpo.models import OrchestrationRequest
from cpo.orchestrator import Orchestrator
from cpo.specialists import EchoSpecialist, NoisySpecialist

o = Orchestrator(
    [
        EchoSpecialist("analysis", "Analysis"),
        EchoSpecialist("planning", "Plan"),
        EchoSpecialist("review", "Review"),
        NoisySpecialist(),
    ],
    [TextConsumer()],
    config=CPOConfig(),
)
r = asyncio.run(
    o.run(OrchestrationRequest(input="Summarize the incident review and propose two mitigations."))
)
for t in r.cycles:
    print(
        f"cycle {t.cycle}: change={t.change_signal:.3f} selected={t.selected_sources} "
        f"cap={t.occupancy.selection_cap} terminal={t.terminal_kind}"
    )
print("reconfirmation:", r.reconfirmation.status)
print(json.dumps(r.diagnostics["plane_proxy"], indent=2))
