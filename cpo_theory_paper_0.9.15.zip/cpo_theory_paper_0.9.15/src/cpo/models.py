from __future__ import annotations

import math
from datetime import UTC, datetime
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator


def validate_json(value: Any, *, depth: int = 0, max_depth: int = 8) -> Any:
    if depth > max_depth:
        raise ValueError("JSON value exceeds maximum nesting depth")
    if value is None or isinstance(value, (str, int, bool)):
        return value
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("non-finite floats are not valid JSON")
        return value
    if isinstance(value, list):
        return [validate_json(v, depth=depth + 1, max_depth=max_depth) for v in value]
    if isinstance(value, dict):
        if not all(isinstance(k, str) for k in value):
            raise ValueError("JSON object keys must be strings")
        return {k: validate_json(v, depth=depth + 1, max_depth=max_depth) for k, v in value.items()}
    raise ValueError(f"unsupported JSON value type: {type(value).__name__}")


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class Candidate(StrictModel):
    """A pattern offered to the pool by a specialist.

    Content is relational: a candidate is never scored on its own, only against
    the current reference.  The only self-reported field the loop consumes is
    ``claimed_risk``, and only to *reject*, never to promote.
    """

    source: str = Field(min_length=1, max_length=128)
    content: str = Field(min_length=1)
    claimed_risk: float = Field(default=0.0, ge=0, le=1)
    evidence: list[str] = Field(default_factory=list, max_length=64)
    metadata: dict[str, Any] = Field(default_factory=dict)

    @field_validator("metadata")
    @classmethod
    def metadata_is_json(cls, value: dict[str, Any]) -> dict[str, Any]:
        return validate_json(value)

    @field_validator("evidence")
    @classmethod
    def evidence_bounded(cls, value: list[str]) -> list[str]:
        if any(len(e) > 2048 for e in value):
            raise ValueError("evidence entries must be at most 2048 characters")
        return value


class CandidateAssessment(StrictModel):
    source: str
    candidate_index: int = Field(ge=0)
    signature: str
    resonance: float = Field(ge=0, le=1)  # 1 - d_H(reference, candidate)/n
    binding: float = Field(ge=0, le=1)  # min-cut shingle-overlap proxy
    quality: float = Field(default=1.0, ge=0, le=1)
    risk: float = Field(ge=0, le=1)
    weight: float = Field(ge=0)  # w(p): the focus weighting
    rank: int | None = Field(default=None, ge=0)
    rejected: bool = False
    reasons: list[str] = Field(default_factory=list)


class SelectedCandidate(StrictModel):
    candidate: Candidate
    assessment: CandidateAssessment


class OccupancyReport(StrictModel):
    slots: int
    occupancy: int
    nu: float
    holdable_alternatives: float
    max_bundle: int
    largest_admissible_bundle: int
    regime: Literal["starved", "admissible", "saturated"]
    selection_cap: int


class WorkspaceContent(StrictModel):
    request_id: str
    cycle: int = Field(ge=1)
    reference_signature: str
    previous_reference_signature: str | None = None
    reference_delta_weight: int = Field(ge=0)  # d_H between consecutive references
    change_signal: float = Field(ge=0, le=1)  # delta weight / n
    selected: list[SelectedCandidate]
    synthesis: str
    consensus_agreement: float = Field(ge=0, le=1)  # mean per-position majority margin
    occupancy: OccupancyReport
    converged: bool = False
    terminal_kind: Literal["open", "fixed_point", "cycle", "budget_exhausted", "pool_exhausted"] = "open"


class OrchestrationRequest(StrictModel):
    input: str = Field(min_length=1)
    goal: str | None = None
    context: dict[str, Any] = Field(default_factory=dict)
    request_id: str | None = Field(default=None, min_length=1, max_length=128, pattern=r"^[A-Za-z0-9._:-]+$")
    max_cycles: int | None = Field(default=None, ge=1, le=32)

    @field_validator("input", "goal")
    @classmethod
    def no_null_bytes(cls, value: str | None) -> str | None:
        if value is not None and "\x00" in value:
            raise ValueError("null bytes are not allowed")
        return value

    @field_validator("context")
    @classmethod
    def context_is_json(cls, value: dict[str, Any]) -> dict[str, Any]:
        return validate_json(value)


class ConsumerResult(StrictModel):
    consumer: str
    output: Any
    confidence: float = Field(default=0.5, ge=0, le=1)
    metadata: dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def output_is_json(self):
        self.output = validate_json(self.output)
        self.metadata = validate_json(self.metadata)
        return self


class CycleTrace(StrictModel):
    cycle: int
    specialist_count: int
    candidate_count: int
    selected_sources: list[str]
    synthesis_digest: str
    reference_signature: str
    reference_delta: str  # hex XOR of consecutive references: the shared "map"
    reference_delta_weight: int
    change_signal: float = Field(ge=0, le=1)
    consensus_agreement: float = Field(ge=0, le=1)
    occupancy: OccupancyReport
    elapsed_ms: float
    converged: bool = False
    terminal_kind: str = "open"
    failures: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    # Populated only when config.trace_candidate_texts is set (evaluation).  These make the
    # selection step auditable: p_sel is the correctness rate of selected_texts against pool_texts.
    pool_texts: list[str] = Field(default_factory=list)
    selected_texts: list[str] = Field(default_factory=list)


class ReconfirmationReport(StrictModel):
    status: Literal["reconfirmed", "not_reconfirmed", "untested", "unavailable"]
    rounds: int = 0
    theta: float
    distances: list[float] = Field(default_factory=list)  # fractional d_H per round
    nearest_single_candidate: float | None = None  # fractional d_H
    nearest_pair_blend: float | None = None
    recombination_signature: bool | None = None
    # expected fractional d_H to the majority of the whole fresh pool under random tie-breaking
    blind_consensus_distance: float | None = None
    # The recommended verdict: ``status`` additionally requires the unbiased blind-consensus distance
    # to be within theta.  ``status`` alone inherits the tie rule's bias toward acceptance (a blind
    # pool with no information leaves tied bits at the converged reference's values).
    strict_status: Literal["reconfirmed", "not_reconfirmed", "untested", "unavailable"] | None = None
    note: str


class OrchestrationResponse(StrictModel):
    request_id: str
    status: Literal["completed", "partial", "rejected"]
    workspace: WorkspaceContent | None = None
    consumers: list[ConsumerResult] = Field(default_factory=list)
    cycles: list[CycleTrace] = Field(default_factory=list)
    reconfirmation: ReconfirmationReport | None = None
    bundle: dict[str, Any] | None = None  # level-1 atom of the selected candidates with correlations
    warnings: list[str] = Field(default_factory=list)
    diagnostics: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
