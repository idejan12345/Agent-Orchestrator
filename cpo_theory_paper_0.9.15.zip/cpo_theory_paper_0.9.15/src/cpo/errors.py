class CPOError(Exception):
    pass


class PolicyRejected(CPOError):
    pass


class NoCandidates(CPOError):
    pass


class RequestTimedOut(CPOError):
    pass
