"""Integration (binding) proxy for candidate texts.

The paper weights patterns by Phi_mc: the mutual information across the weakest
bipartition of the pattern's parts.  ``cpo.focus.information.phi_mincut`` is the
exact quantity for a joint distribution.  For a text we have one sample, not a
distribution, so this module computes a *proxy* with the same shape: split the
text into parts, and take the minimum over bipartitions of the shingle overlap
between the two sides, normalised by the total shingle count.  A text whose
sections share nothing across some cut scores 0; one whose every section reuses
the others' terms scores high.  It is labelled a proxy everywhere it appears.
"""

from __future__ import annotations

import re
from itertools import combinations

from .sketch import shingles

_SPLIT = re.compile(r"\n\s*\n|(?<=[.!?])\s+(?=[A-Z0-9])")


def split_parts(text: str, max_parts: int = 8) -> list[str]:
    parts = [p.strip() for p in _SPLIT.split(text) if p and p.strip()]
    if len(parts) <= max_parts:
        return parts
    # merge adjacent parts to respect the cap (2^(max_parts-1) bipartitions)
    size = -(-len(parts) // max_parts)
    return [" ".join(parts[i : i + size]) for i in range(0, len(parts), size)]


def min_cut_binding(text: str, *, max_parts: int = 8) -> float:
    parts = split_parts(text, max_parts)
    if len(parts) < 2:
        return 0.0
    sets = [set(shingles(p)) for p in parts]
    total = len(set().union(*sets)) or 1
    idx = list(range(len(sets)))
    best = None
    for size in range(1, len(sets) // 2 + 1):
        for s in combinations(idx, size):
            sc = [i for i in idx if i not in s]
            if size == len(sets) / 2 and s > tuple(sc):
                continue
            left = set().union(*(sets[i] for i in s))
            right = set().union(*(sets[i] for i in sc))
            value = len(left & right) / total
            best = value if best is None else min(best, value)
    return max(0.0, min(1.0, best or 0.0))
