"""Abstraction tower: bundles of atoms that keep their mutual correlations.

Postulate (Abstraction tower): a level-(k+1) unit is a bundle of B level-k units
*together with the correlations among them*.  Theorem (serialisation): a
protocol that names the constituents one by one and sends their binding
separately can devote at most (B-1)/(2B-1) < 1/2 of its message to binding.

Engineering consequence: when the orchestrator hands a bundle to a specialist
or consumer, it ships the correlation block with it (``mode="bundled"``).  The
``flattened`` mode exists for comparison and reports the bound it is subject to.
Whether bundling is *possible* at the current occupancy is decided by the
capacity band, not here.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .focus.capacity import serialisation_binding_bound
from .sketch import Signature, majority


@dataclass(frozen=True)
class Atom:
    label: str
    content: str
    signature: Signature
    level: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class Bundle(Atom):
    constituents: tuple[Atom, ...] = ()
    correlations: tuple[tuple[float, ...], ...] = ()

    @property
    def size(self) -> int:
        return len(self.constituents)

    def serialize(self, mode: str = "bundled", *, max_chars: int = 64_000) -> dict[str, Any]:
        names = [a.label for a in self.constituents]
        body = "\n\n".join(f"[{a.label}] {a.content}" for a in self.constituents)[:max_chars]
        if mode == "bundled":
            return {
                "level": self.level,
                "label": self.label,
                "constituents": names,
                "content": body,
                "correlations": [list(r) for r in self.correlations],
                "binding_share_bound": None,
                "note": "constituents shipped with their pairwise correlations",
            }
        if mode == "flattened":
            return {
                "level": self.level,
                "label": self.label,
                "constituents": names,
                "content": body,
                "correlations": None,
                "binding_share_bound": serialisation_binding_bound(max(2, self.size)),
                "note": "constituent-wise serialisation; binding share bounded by (B-1)/(2B-1)",
            }
        raise ValueError("mode must be 'bundled' or 'flattened'")


def bundle(atoms: list[Atom], label: str) -> Bundle:
    """Fuse atoms into one atom of the next level.  The bundle's signature is the
    majority of its constituents (ties keep the first constituent's bit) and its
    correlation block is the matrix of pairwise signature similarities."""
    if len(atoms) < 2:
        raise ValueError("a bundle needs at least two constituents")
    level = max(a.level for a in atoms) + 1
    sig = majority([a.signature for a in atoms], atoms[0].signature)
    corr = tuple(tuple(round(a.signature.similarity(b.signature), 4) for b in atoms) for a in atoms)
    content = "\n\n".join(f"[{a.label}] {a.content}" for a in atoms)
    return Bundle(
        label=label,
        content=content,
        signature=sig,
        level=level,
        metadata={"constituent_levels": [a.level for a in atoms]},
        constituents=tuple(atoms),
        correlations=corr,
    )
