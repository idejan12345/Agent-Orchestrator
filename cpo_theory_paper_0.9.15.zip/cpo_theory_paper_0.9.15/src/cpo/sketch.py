"""Embedding of candidate texts into the register.

The paper's loop operates on binary sequences.  To apply it to specialist
outputs, each text is mapped to a fixed-length binary *signature* by a
deterministic SimHash over word shingles.  Two properties matter and are tested:

* the map is deterministic and total (any text gets a signature);
* Hamming distance between signatures decreases monotonically with lexical
  overlap, so ``1 - d_H/n`` is a usable resonance kernel.

What is *not* preserved: the sequential structure that makes the paper's flip
map ``d`` meaningful.  Signature positions are unordered hash slots, so the
Hamming theorem's flip-domain form is replaced by direct Hamming distance
between signatures (see docs/THEORY_MAPPING.md, row "resonance").  The
register-level formalism in ``cpo.focus`` keeps the exact form.
"""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass

_TOKEN = re.compile(r"[a-z0-9]+(?:'[a-z]+)?")


def tokens(text: str) -> list[str]:
    return _TOKEN.findall(text.lower())


def shingles(text: str, width: int = 3) -> list[str]:
    toks = tokens(text)
    if not toks:
        return []
    out = list(toks)  # unigrams anchor short texts
    for w in range(2, width + 1):
        out.extend(" ".join(toks[i : i + w]) for i in range(len(toks) - w + 1))
    return out


@dataclass(frozen=True)
class Signature:
    bits: int
    n: int

    @classmethod
    def of_text(cls, text: str, n: int = 256, width: int = 3) -> Signature:
        if n < 8 or n % 8:
            raise ValueError("signature length must be a positive multiple of 8")
        acc = [0] * n
        for sh in shingles(text, width):
            digest = hashlib.sha256(sh.encode("utf-8")).digest()
            # consume as many 32-byte blocks as needed for n bits
            value = int.from_bytes(digest, "big")
            blocks = (n + 255) // 256
            for b in range(1, blocks):
                value = (value << 256) | int.from_bytes(hashlib.sha256(digest + bytes([b])).digest(), "big")
            for i in range(n):
                acc[i] += 1 if (value >> i) & 1 else -1
        bits = 0
        for i, v in enumerate(acc):
            if v > 0:
                bits |= 1 << i
        return cls(bits, n)

    @classmethod
    def from_hex(cls, value: str, n: int) -> Signature:
        return cls(int(value, 16) & ((1 << n) - 1), n)

    def hex(self) -> str:
        return format(self.bits, f"0{self.n // 4}x")

    def hamming(self, other: Signature) -> int:
        self._check(other)
        return (self.bits ^ other.bits).bit_count()

    def similarity(self, other: Signature) -> float:
        return 1.0 - self.hamming(other) / self.n

    def xor(self, other: Signature) -> Signature:
        self._check(other)
        return Signature(self.bits ^ other.bits, self.n)

    def weight(self) -> int:
        return self.bits.bit_count()

    def _check(self, other: Signature) -> None:
        if other.n != self.n:
            raise ValueError("signature lengths differ")


class SimHashSigner:
    """Default signer: deterministic SimHash over word shingles (see module docstring)."""

    def __init__(self, n: int = 256, width: int = 3):
        self.n, self.width = n, width

    def sign(self, text: str) -> Signature:
        return Signature.of_text(text, self.n, self.width)


class MarkerWeightedSigner:
    """SimHash in which the shingles of a marked deliverable line carry extra weight.

    When candidates are instructed to end with ``Answer: <answer>`` (or any marker),
    the marked line is the task's deliverable and the rest is reasoning that legitimately
    varies between paraphrases.  Weighting the marked line by ``weight`` lets agreement
    on the deliverable dominate the majority vote, so the loop converges on what the
    specialists agree about rather than on how they phrased it.  Texts without the
    marker are signed exactly as ``SimHashSigner`` would sign them, so rubric-style
    tasks are unaffected.  Still lexical, still deterministic.
    """

    def __init__(self, n: int = 256, *, marker: str = "Answer:", weight: int = 8, width: int = 3):
        if n < 8 or n % 8:
            raise ValueError("signature length must be a positive multiple of 8")
        if weight < 1:
            raise ValueError("weight must be positive")
        self.n, self.marker, self.weight, self.width = n, marker, weight, width

    def split(self, text: str) -> tuple[str, str | None]:
        lower = self.marker.lower()
        for line in reversed(text.strip().splitlines()):
            if line.lower().lstrip().startswith(lower):
                head = text[: text.rfind(line)]
                return head, line.split(":", 1)[1].strip() if ":" in line else line[
                    len(self.marker) :
                ].strip()
        return text, None

    def sign(self, text: str) -> Signature:
        body, marked = self.split(text)
        if marked is None:
            return Signature.of_text(text, self.n, self.width)
        acc = [0] * self.n
        votes: list[tuple[str, int]] = [(sh, 1) for sh in shingles(body, self.width)]
        votes += [(sh, self.weight) for sh in shingles(f"{self.marker} {marked}", self.width)]
        for sh, w in votes:
            value = int.from_bytes(hashlib.sha256(sh.encode("utf-8")).digest(), "big")
            for i in range(self.n):
                acc[i] += w if (value >> i) & 1 else -w
        bits = 0
        for i, v in enumerate(acc):
            if v > 0:
                bits |= 1 << i
        return Signature(bits, self.n)


class ThresholdedVectorSigner:
    """Adapter for embedding models: a callable returning a float vector is thresholded
    against its median to a signature.  ``embed`` must be deterministic for a given text
    (cache it if the backend is not); the vector length must be a positive multiple of 8.
    Resonance then compares embedding sign patterns rather than lexical overlap."""

    def __init__(self, embed, n: int):
        if n < 8 or n % 8:
            raise ValueError("signature length must be a positive multiple of 8")
        self.embed, self.n = embed, n

    def sign(self, text: str) -> Signature:
        vec = list(self.embed(text))
        if len(vec) != self.n:
            raise ValueError(f"embedding length {len(vec)} does not match signer length {self.n}")
        pivot = sorted(vec)[len(vec) // 2]
        bits = 0
        for i, v in enumerate(vec):
            if v > pivot:
                bits |= 1 << i
        return Signature(bits, self.n)


def expected_majority_distance(signatures: list[Signature], reference: Signature) -> float:
    """Fractional Hamming distance from ``reference`` to the position-wise majority of
    ``signatures`` under *random* tie-breaking, taken in expectation: a position whose
    vote is split contributes 1/2 whatever the reference holds there.  Unlike
    ``majority``, which retains the previous bit on a tie, this depends on the reference
    only where the pool actually decides a bit, so a pool that carries no information
    sits at distance about 1/2 from any reference."""
    if not signatures:
        return 0.5
    n = reference.n
    counts = [0] * n
    for s in signatures:
        if s.n != n:
            raise ValueError("signature lengths differ")
        v = s.bits
        while v:
            low = v & -v
            counts[low.bit_length() - 1] += 1
            v ^= low
    half = len(signatures) / 2.0
    total = 0.0
    for i in range(n):
        if counts[i] == half:
            total += 0.5
        elif (counts[i] > half) != bool((reference.bits >> i) & 1):
            total += 1.0
    return total / n


def majority(signatures: list[Signature], previous: Signature) -> Signature:
    """Position-wise majority vote, exact ties retaining the previous bit: the
    paper's consensus step applied to signatures."""
    if not signatures:
        return previous
    n = previous.n
    counts = [0] * n
    for s in signatures:
        if s.n != n:
            raise ValueError("signature lengths differ")
        v = s.bits
        while v:
            low = v & -v
            counts[low.bit_length() - 1] += 1
            v ^= low
    half = len(signatures) / 2.0
    bits = 0
    for i in range(n):
        if counts[i] > half or (counts[i] == half and (previous.bits >> i) & 1):
            bits |= 1 << i
    return Signature(bits, n)
