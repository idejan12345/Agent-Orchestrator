from __future__ import annotations

import random

from .models import Candidate, OrchestrationRequest, WorkspaceContent


class EchoSpecialist:
    """Deterministic test specialist: restates the input with a role prefix and, when a
    workspace is present, converges toward it (so the loop reaches a fixed point)."""

    concurrency_safe = True

    def __init__(self, name: str, prefix: str, risk: float = 0.0):
        self.name, self.prefix, self.risk = name, prefix, risk
        self.broadcasts: dict[str, WorkspaceContent] = {}

    async def propose(
        self, request: OrchestrationRequest, workspace: WorkspaceContent | None
    ) -> list[Candidate]:
        if workspace is None:
            content = f"{self.prefix}: {request.input}"
        else:
            content = f"{self.prefix}: {request.input}\n\nAgreed basis: {workspace.synthesis[:400]}"
        return [
            Candidate(
                source=self.name,
                content=content,
                claimed_risk=self.risk,
                metadata={"resample": bool(request.context.get("_cpo_resample"))},
            )
        ]

    async def receive_broadcast(self, workspace: WorkspaceContent) -> None:
        self.broadcasts[workspace.request_id] = workspace


class NoisySpecialist:
    """Emits unrelated content every call; used to show that noise votes itself out."""

    concurrency_safe = True
    _words = (
        "lantern",
        "quartz",
        "harbor",
        "meridian",
        "saffron",
        "ledger",
        "orbit",
        "thistle",
        "granite",
        "velvet",
        "compass",
        "ember",
        "prairie",
        "cobalt",
        "willow",
        "anchor",
    )

    def __init__(self, name: str = "noise", seed: int = 0):
        self.name = name
        self._rng = random.Random(seed)  # nosec B311 - simulation, not security

    async def propose(self, request, workspace):
        words = [self._rng.choice(self._words) for _ in range(40)]
        return [Candidate(source=self.name, content=" ".join(words))]

    async def receive_broadcast(self, workspace):
        return None


class FailingSpecialist:
    concurrency_safe = True

    def __init__(self, name: str = "failing"):
        self.name = name

    async def propose(self, request, workspace):
        raise RuntimeError("intentional specialist failure")

    async def receive_broadcast(self, workspace):
        return None
