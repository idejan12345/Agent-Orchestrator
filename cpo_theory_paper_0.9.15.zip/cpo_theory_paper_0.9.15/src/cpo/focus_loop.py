"""The focus map applied to a pool of candidate texts.

One cycle is the paper's three operations:

1. **Resonate.**  Every candidate is scored *relative to the reference*:
   ``resonance = 1 - d_H(reference, candidate)/n`` on signatures.  The focus
   weighting is ``w = resonance^a * (1 + binding)^b * quality``; risk only rejects.
2. **Select.**  Keep the top ``ceil(phi * N)`` by weight, clamped to
   ``[k_min, selection_cap]`` where the cap comes from the occupancy controller.
   Ties break by (source, index) so selection is deterministic.
3. **Consensus.**  The new reference is the position-wise majority of the selected
   signatures, ties retaining the previous bit.  The workspace text is produced by
   a ``ConsensusWriter``; the default picks the *medoid* (the selected candidate
   nearest the consensus signature), which is idempotent at a fixed point.

The selection law says step 2 on its own can only erode order; the loop therefore
never skips step 3, and warns when a cycle degenerates to a single selection.
"""

from __future__ import annotations

import math
from collections.abc import Sequence
from dataclasses import dataclass
from typing import Protocol

from .binding import min_cut_binding
from .interfaces import Signer
from .models import Candidate, CandidateAssessment, SelectedCandidate
from .sketch import Signature, SimHashSigner, majority


@dataclass(frozen=True)
class ConsensusReport:
    signature: Signature
    agreement: float  # mean per-position majority margin in [0,1]
    medoid_index: int


class QualityHook(Protocol):
    async def quality(self, candidate: Candidate) -> float: ...


class ConsensusWriter(Protocol):
    async def write(
        self,
        selected: Sequence[SelectedCandidate],
        report: ConsensusReport,
        previous: str | None,
        max_chars: int,
    ) -> str: ...


class MedoidConsensusWriter:
    """Deterministic default: the selected candidate closest to the consensus signature."""

    async def write(self, selected, report, previous, max_chars):
        return selected[report.medoid_index].candidate.content[:max_chars]


class TextFocusLoop:
    def __init__(
        self,
        *,
        n: int,
        phi: float,
        k_min: int,
        resonance_exponent: float,
        binding_exponent: float,
        hard_risk_threshold: float,
        quality_hook: QualityHook | None = None,
        signer: Signer | None = None,
    ):
        self.n, self.phi, self.k_min = n, phi, k_min
        self.signer: Signer = signer or SimHashSigner(n)
        if self.signer.n != n:
            raise ValueError("signer length must equal signature_bits")
        self.a, self.b = resonance_exponent, binding_exponent
        self.hard_risk_threshold = hard_risk_threshold
        self.quality_hook = quality_hook

    def signature(self, text: str) -> Signature:
        return self.signer.sign(text)

    async def assess(
        self, reference: Signature, candidates: Sequence[Candidate]
    ) -> list[tuple[Candidate, CandidateAssessment]]:
        out = []
        for index, c in enumerate(candidates):
            sig = self.signature(c.content)
            resonance = reference.similarity(sig)
            binding = min_cut_binding(c.content)
            quality = 1.0
            if self.quality_hook is not None:
                quality = max(0.0, min(1.0, float(await self.quality_hook.quality(c))))
            reasons: list[str] = []
            rejected = False
            if c.claimed_risk >= self.hard_risk_threshold:
                rejected, reasons = True, ["hard_risk_threshold"]
            weight = (resonance**self.a) * ((1.0 + binding) ** self.b) * quality
            if not math.isfinite(weight):
                rejected, reasons = True, [*reasons, "non_finite_weight"]
                weight = 0.0
            out.append(
                (
                    c,
                    CandidateAssessment(
                        source=c.source,
                        candidate_index=index,
                        signature=sig.hex(),
                        resonance=resonance,
                        binding=binding,
                        quality=quality,
                        risk=c.claimed_risk,
                        weight=weight,
                        rejected=rejected,
                        reasons=reasons,
                    ),
                )
            )
        return out

    def select(
        self, assessed: Sequence[tuple[Candidate, CandidateAssessment]], *, selection_cap: int
    ) -> tuple[list[SelectedCandidate], list[CandidateAssessment]]:
        accepted = [(c, a) for c, a in assessed if not a.rejected]
        rejected = [a for _, a in assessed if a.rejected]
        if not accepted:
            return [], rejected
        k = math.ceil(len(accepted) * self.phi - 1e-12)
        k = max(1, min(len(accepted), max(self.k_min, k), selection_cap))
        ordered = sorted(accepted, key=lambda ca: (-ca[1].weight, ca[0].source, ca[1].candidate_index))
        selected = [
            SelectedCandidate(candidate=c, assessment=a.model_copy(update={"rank": r}))
            for r, (c, a) in enumerate(ordered[:k])
        ]
        return selected, rejected

    def consensus(self, selected: Sequence[SelectedCandidate], previous: Signature) -> ConsensusReport:
        sigs = [Signature.from_hex(s.assessment.signature, self.n) for s in selected]
        sig = majority(sigs, previous)
        # agreement: mean |2*ones/k - 1| across positions
        k = len(sigs)
        if k == 0:
            return ConsensusReport(previous, 0.0, 0)
        margin_total = 0.0
        for i in range(self.n):
            ones = sum((s.bits >> i) & 1 for s in sigs)
            margin_total += abs(2.0 * ones / k - 1.0)
        agreement = margin_total / self.n
        medoid = min(range(k), key=lambda j: (sigs[j].hamming(sig), selected[j].candidate.source))
        return ConsensusReport(sig, agreement, medoid)
