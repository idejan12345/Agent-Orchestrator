"""Environmental reconfirmation of a converged reference.

A fixed point carved by a real regularity keeps being reconfirmed when the pool is
refreshed; one carved by the loop's own history does not (theory paper, sec. 3.4 and
H2; the source model's prediction on non-motif perceptual locking).  Self-consistency
alone cannot tell the two apart, so the orchestrator refreshes the pool *blind*
(specialists receive no workspace) and re-applies one step of the focus map from the
converged reference.

Reported, never interpreted further:
* ``status`` -- ``reconfirmed`` if every round's re-selected consensus lies within
  ``theta`` of the reference, else ``not_reconfirmed``.  Exact ties in that consensus
  retain the reference's bit, which biases the test toward acceptance.
* ``strict_status`` -- the recommended verdict: ``status`` is ``reconfirmed`` AND
  ``blind_consensus_distance`` <= ``theta``.
* ``blind_consensus_distance`` -- expected fractional distance from the reference to
  the majority of the whole fresh pool under random tie-breaking (no selection, each
  tied position counting one half); a pool carrying no information sits near 1/2.
* ``recombination_signature`` -- the synthesis overlaps a *union of two* fresh
  candidates more than any single one (Jaccard on shingle sets): the chimera
  structure in which non-motif attractors are blends of real motifs.

The word "hallucination" does not appear in any output field on purpose.
"""

from __future__ import annotations

import math
from collections.abc import Sequence
from itertools import combinations
from typing import Literal

from .interfaces import Signer
from .models import ReconfirmationReport
from .sketch import Signature, SimHashSigner, expected_majority_distance, majority, shingles


def _jaccard_distance(a: set[str], b: set[str]) -> float:
    union = a | b
    return 1.0 - len(a & b) / len(union) if union else 0.0


def recombination_test(
    synthesis: str, fresh_texts: Sequence[str]
) -> tuple[float | None, float | None, bool | None]:
    """(distance to nearest single candidate, distance to nearest two-candidate union, flag)."""
    if not fresh_texts:
        return None, None, None
    ref = set(shingles(synthesis))
    sets = [set(shingles(t)) for t in fresh_texts]
    single = min(_jaccard_distance(ref, s) for s in sets)
    if len(sets) < 2:
        return single, None, None
    pair = min(_jaccard_distance(ref, a | b) for a, b in combinations(sets, 2))
    return single, pair, pair + 1e-9 < single


def reconfirm(
    reference: Signature,
    synthesis: str,
    fresh_rounds: Sequence[Sequence[str]],
    *,
    n: int,
    theta: float,
    phi: float,
    k_min: int,
    signer: Signer | None = None,
) -> ReconfirmationReport:
    sign = (signer or SimHashSigner(n)).sign
    if not fresh_rounds:
        return ReconfirmationReport(
            status="untested", strict_status="untested", theta=theta, note="reconfirmation disabled"
        )
    distances: list[float] = []
    all_fresh: list[str] = []
    all_sigs: list[Signature] = []
    for texts in fresh_rounds:
        if not texts:
            continue
        all_fresh.extend(texts)
        sigs = [sign(t) for t in texts]
        all_sigs.extend(sigs)
        k = max(1, min(len(sigs), max(k_min, math.ceil(len(sigs) * phi - 1e-12))))
        top = sorted(sigs, key=lambda s: reference.hamming(s))[:k]
        distances.append(reference.hamming(majority(top, reference)) / reference.n)
    if not distances:
        return ReconfirmationReport(
            status="unavailable",
            strict_status="unavailable",
            theta=theta,
            note="fresh pools were empty; specialists failed on resample",
        )
    single, pair, recomb = recombination_test(synthesis, all_fresh)
    # the pool's own regularity: expected distance to its majority under random tie-breaking,
    # so a tie pulls neither toward the reference nor toward a fixed bit value
    blind_distance = expected_majority_distance(all_sigs, reference)
    status: Literal["reconfirmed", "not_reconfirmed"] = (
        "reconfirmed" if max(distances) <= theta else "not_reconfirmed"
    )
    strict: Literal["reconfirmed", "not_reconfirmed"] = (
        "reconfirmed" if status == "reconfirmed" and blind_distance <= theta else "not_reconfirmed"
    )
    return ReconfirmationReport(
        status=status,
        strict_status=strict,
        rounds=len(distances),
        theta=theta,
        distances=distances,
        nearest_single_candidate=single,
        nearest_pair_blend=pair,
        recombination_signature=recomb,
        blind_consensus_distance=blind_distance,
        note=(
            "fresh blind pool re-selected from the converged reference; a reconfirmed fixed point "
            "matches an environmental regularity, an unconfirmed one is self-sustained. "
            "This is a stability test, not a truth test."
        ),
    )
