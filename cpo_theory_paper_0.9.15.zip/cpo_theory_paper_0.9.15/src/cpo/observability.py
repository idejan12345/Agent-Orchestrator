from __future__ import annotations

import json
import logging
import threading
import time
from collections import Counter


class MetricsRegistry:
    def __init__(self):
        self._lock = threading.Lock()
        self.counters = Counter()
        self.gauges = Counter()
        self.duration_sum = Counter()
        self.duration_count = Counter()

    def inc(self, name: str, labels: tuple[tuple[str, str], ...] = (), value: float = 1) -> None:
        with self._lock:
            self.counters[(name, labels)] += value

    def gauge_add(self, name: str, labels: tuple[tuple[str, str], ...] = (), value: float = 1) -> None:
        with self._lock:
            self.gauges[(name, labels)] += value

    def observe(self, name: str, seconds: float, labels: tuple[tuple[str, str], ...] = ()) -> None:
        with self._lock:
            self.duration_sum[(name, labels)] += seconds
            self.duration_count[(name, labels)] += 1

    @staticmethod
    def _sample(name, labels, value):
        suffix = "{" + ",".join(f'{k}="{v}"' for k, v in labels) + "}" if labels else ""
        return f"{name}{suffix} {value}\n"

    def render(self) -> str:
        lines = []
        with self._lock:
            for (name, labels), value in sorted(self.counters.items()):
                lines.append(self._sample(name, labels, value))
            for (name, labels), value in sorted(self.gauges.items()):
                lines.append(self._sample(name, labels, value))
            for (name, labels), value in sorted(self.duration_sum.items()):
                lines.append(self._sample(name + "_seconds_sum", labels, value))
                lines.append(
                    self._sample(name + "_seconds_count", labels, self.duration_count[(name, labels)])
                )
        return "".join(lines)


METRICS = MetricsRegistry()
LOGGER = logging.getLogger("cpo")


def configure_json_logging(level: str = "INFO") -> None:
    handler = logging.StreamHandler()
    handler.setFormatter(JsonFormatter())
    LOGGER.handlers[:] = [handler]
    LOGGER.setLevel(level)


class JsonFormatter(logging.Formatter):
    def format(self, record):
        return json.dumps(
            {
                "timestamp": time.time(),
                "level": record.levelname,
                "logger": record.name,
                "message": record.getMessage(),
            },
            separators=(",", ":"),
        )
