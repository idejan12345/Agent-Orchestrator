"""(W, M*) proxies for an orchestration trajectory.

The paper defines W = I(s0; e-bar) and M* = I(s0_past; s0_future | e-bar).  For a
run we have, per cycle, the reference signature (s0) and the blind-pool consensus
(the environment's regularity as the specialists report it without workspace
bias).  Treating signature positions as paired samples gives n * cycles pairs,
which is enough for a shuffle-corrected plug-in estimate of the *bitwise* mutual
information.  These are trajectory proxies of the coordinates, in bits per
position, and are reported as ``null`` below three cycles because M* needs a
past, a future and a conditioner.
"""

from __future__ import annotations

from collections.abc import Sequence

from .focus.information import conditional_mutual_information, mutual_information
from .sketch import Signature


def _bits(sig: Signature) -> list[int]:
    return [(sig.bits >> i) & 1 for i in range(sig.n)]


def trajectory_plane(references: Sequence[Signature], environment: Sequence[Signature]) -> dict:
    if len(references) != len(environment):
        raise ValueError("references and environment must be aligned per cycle")
    cycles = len(references)
    if cycles < 3:
        return {
            "W_bits_per_position": None,
            "M_star_bits_per_position": None,
            "M_raw_bits_per_position": None,
            "cycles": cycles,
            "status": "insufficient_cycles",
            "note": "needs at least three cycles",
        }
    ref = [b for s in references for b in _bits(s)]
    env = [b for s in environment for b in _bits(s)]
    n = references[0].n
    past = [b for s in references[:-1] for b in _bits(s)]
    future = [b for s in references[1:] for b in _bits(s)]
    cond = [b for s in environment[:-1] for b in _bits(s)]

    # shuffle baseline: rotate the second argument by a fixed offset across cycles
    def shuffled(x):
        return x[n:] + x[:n]

    w = max(0.0, mutual_information(ref, env) - mutual_information(ref, shuffled(env)))
    m_raw = max(0.0, mutual_information(past, future) - mutual_information(past, shuffled(future)))
    m_star = max(
        0.0,
        conditional_mutual_information(past, future, cond)
        - conditional_mutual_information(past, shuffled(future), cond),
    )
    return {
        "W_bits_per_position": round(w, 5),
        "M_star_bits_per_position": round(m_star, 5),
        "M_raw_bits_per_position": round(m_raw, 5),
        "cycles": cycles,
        "status": "proxy",
        "note": (
            "bitwise trajectory proxies of the paper's coordinates; M* is an upper bound "
            "on the self-model (partial deconfounding), not a self-awareness measurement"
        ),
    }
