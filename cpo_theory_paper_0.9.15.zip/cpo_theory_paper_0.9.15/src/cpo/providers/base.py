from __future__ import annotations

import asyncio
import random
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any
from urllib.parse import urlparse

import httpx
from pydantic import BaseModel, ConfigDict, Field


class ProviderError(RuntimeError):
    """Sanitized provider failure. Secrets and response bodies are never included."""


class TruncatedOutput(ProviderError):
    """The model stopped because it hit the output-token ceiling.

    This is raised rather than returned because a truncated answer is *worse* than no answer in an
    evaluation: it looks like a complete response, grades as wrong (or gets marked down by a rater
    for being cut off), and the failure is invisible in the results.  The caller must either raise
    ``max_output_tokens`` or record the run as failed.
    """


class ProviderConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")
    model: str = Field(min_length=1, max_length=256)
    # Ceilings are deliberately generous: a reasoning model answering a drafting or coding task can
    # take several minutes for a single call, and a limit that cannot be raised is a limit that
    # silently drops candidates from the pool.  Defaults stay modest; evaluations raise them.
    timeout_s: float = Field(default=120.0, gt=0, le=1800)
    connect_timeout_s: float = Field(default=15.0, gt=0, le=120)
    max_retries: int = Field(default=6, ge=0, le=10)
    max_output_tokens: int = Field(default=4096, ge=1, le=64000)
    max_response_bytes: int = Field(default=1_000_000, ge=1024, le=10_000_000)
    temperature: float | None = Field(
        default=None,
        ge=0.0,
        le=2.0,
        description="sampling temperature; None leaves the provider default. Set it explicitly for evaluations.",
    )


@dataclass(frozen=True)
class ProviderResult:
    text: str
    provider: str
    model: str
    request_id: str | None
    usage: Mapping[str, Any]
    stop_reason: str | None = None


def require_https_url(
    url: str, *, exact_host: str | None = None, allowed_suffixes: tuple[str, ...] = ()
) -> str:
    parsed = urlparse(url)
    if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password:
        raise ValueError("provider endpoint must be an HTTPS URL without embedded credentials")
    host = parsed.hostname.lower()
    if exact_host and host != exact_host:
        raise ValueError(f"provider endpoint host must be {exact_host}")
    if allowed_suffixes and not any(
        host == suffix.lstrip(".") or host.endswith(suffix) for suffix in allowed_suffixes
    ):
        raise ValueError("provider endpoint host is not in the approved suffix allowlist")
    if parsed.query or parsed.fragment:
        raise ValueError("provider endpoint must not include query parameters or fragments")
    return url.rstrip("/")


class HttpProvider:
    provider_name = "provider"
    retry_statuses = {408, 409, 425, 429, 500, 502, 503, 504, 529}

    def __init__(self, config: ProviderConfig, *, client: httpx.AsyncClient | None = None):
        self.config = config
        self._owns_client = client is None
        timeout = httpx.Timeout(config.timeout_s, connect=config.connect_timeout_s)
        self.client = client or httpx.AsyncClient(timeout=timeout, follow_redirects=False)

    async def close(self) -> None:
        if self._owns_client:
            await self.client.aclose()

    async def readiness(self) -> tuple[bool, str]:
        return True, "configured"

    @staticmethod
    def _backoff(attempt: int, retry_after: str | None) -> float:
        """Exponential backoff with jitter, capped at 30 s; a numeric Retry-After header wins."""
        if retry_after:
            try:
                return min(float(retry_after), 60.0)
            except ValueError:
                pass
        base = min(1.0 * (2**attempt), 30.0)
        return base * (0.5 + random.random() / 2)  # nosec B311 - jitter, not security

    async def _post_json(
        self, url: str, *, headers: dict[str, str], payload: dict[str, Any]
    ) -> httpx.Response:
        last_error: Exception | None = None
        for attempt in range(self.config.max_retries + 1):
            try:
                response = await self.client.post(url, headers=headers, json=payload)
                if response.status_code in self.retry_statuses and attempt < self.config.max_retries:
                    await asyncio.sleep(self._backoff(attempt, response.headers.get("retry-after")))
                    continue
                if response.is_redirect:
                    raise ProviderError(f"{self.provider_name} redirect rejected")
                if response.status_code >= 400:
                    # Include a sanitised snippet of the error body for diagnosis
                    try:
                        err_body = response.json()
                        err_msg = (
                            err_body.get("error", {}).get("message", "") if isinstance(err_body, dict) else ""
                        )
                        err_snippet = err_msg[:120] if err_msg else ""
                    except Exception:
                        err_snippet = ""
                    detail = f" — {err_snippet}" if err_snippet else ""
                    raise ProviderError(f"{self.provider_name} returned HTTP {response.status_code}{detail}")
                if len(response.content) > self.config.max_response_bytes:
                    raise ProviderError(f"{self.provider_name} response exceeded configured size")
                content_type = response.headers.get("content-type", "")
                if "application/json" not in content_type:
                    raise ProviderError(f"{self.provider_name} returned non-JSON content")
                return response
            except ProviderError:
                raise
            except (httpx.TimeoutException, httpx.NetworkError) as exc:
                last_error = exc
                if attempt < self.config.max_retries:
                    await asyncio.sleep(self._backoff(attempt, None))
                    continue
                break
        raise ProviderError(f"{self.provider_name} request failed: {type(last_error).__name__}")


def raise_if_truncated(data: dict[str, Any], limit: int, provider: str) -> str | None:
    """Responses-API truncation guard.  Returns the stop reason; raises if output was cut short."""
    status = data.get("status")
    incomplete = data.get("incomplete_details")
    reason = incomplete.get("reason") if isinstance(incomplete, dict) else None
    if status == "incomplete" and reason in {"max_output_tokens", "max_tokens"}:
        raise TruncatedOutput(
            f"{provider} response hit max_output_tokens ({limit}); "
            "raise max_output_tokens or shorten the task"
        )
    return reason or status


def extract_responses_text(data: dict[str, Any]) -> str:
    direct = data.get("output_text")
    if isinstance(direct, str) and direct.strip():
        return direct.strip()
    texts: list[str] = []
    for item in data.get("output", []) if isinstance(data.get("output"), list) else []:
        if not isinstance(item, dict):
            continue
        for block in item.get("content", []) if isinstance(item.get("content"), list) else []:
            if isinstance(block, dict) and block.get("type") in {"output_text", "text"}:
                text = block.get("text")
                if isinstance(text, str):
                    texts.append(text)
    result = "\n".join(t.strip() for t in texts if t.strip())
    if not result:
        raise ProviderError("provider response did not contain text output")
    return result
