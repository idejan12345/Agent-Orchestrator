from __future__ import annotations

from typing import Any

import httpx
from pydantic import SecretStr, field_validator, model_validator

from ..version import __version__
from .base import (
    HttpProvider,
    ProviderConfig,
    ProviderError,
    ProviderResult,
    extract_responses_text,
    raise_if_truncated,
    require_https_url,
)


class AzureResponsesConfig(ProviderConfig):
    endpoint: str
    api_key: SecretStr | None = None
    bearer_token: SecretStr | None = None

    @field_validator("endpoint")
    @classmethod
    def validate_endpoint(cls, value: str) -> str:
        return require_https_url(
            value,
            allowed_suffixes=(".openai.azure.com", ".services.ai.azure.com"),
        )

    @model_validator(mode="after")
    def exactly_one_credential(self):
        if (self.api_key is None) == (self.bearer_token is None):
            raise ValueError("configure exactly one of api_key or bearer_token")
        return self


class AzureResponsesProvider(HttpProvider):
    provider_name = "azure-openai"

    def __init__(self, config: AzureResponsesConfig, *, client: httpx.AsyncClient | None = None):
        super().__init__(config, client=client)
        self.config: AzureResponsesConfig = config

    async def generate(self, prompt: str, *, request_id: str) -> ProviderResult:
        headers = {
            "content-type": "application/json",
            "user-agent": f"cpo-orchestrator/{__version__}",
            "x-ms-client-request-id": request_id,
        }
        if self.config.api_key is not None:
            headers["api-key"] = self.config.api_key.get_secret_value()
        elif self.config.bearer_token is not None:
            headers["authorization"] = f"Bearer {self.config.bearer_token.get_secret_value()}"
        else:  # unreachable: the config validator requires one of the two
            raise ProviderError("azure provider has no credential configured")
        payload: dict[str, Any] = {
            "model": self.config.model,
            "input": prompt,
            "max_output_tokens": self.config.max_output_tokens,
            "store": False,
        }
        if self.config.temperature is not None:
            payload["temperature"] = self.config.temperature
        response = await self._post_json(
            self.config.endpoint + "/openai/v1/responses", headers=headers, payload=payload
        )
        data = response.json()
        stop_reason = raise_if_truncated(data, self.config.max_output_tokens, self.provider_name)
        return ProviderResult(
            text=extract_responses_text(data),
            provider=self.provider_name,
            model=self.config.model,
            request_id=response.headers.get("x-request-id")
            or response.headers.get("apim-request-id")
            or data.get("id"),
            usage=data.get("usage") if isinstance(data.get("usage"), dict) else {},
            stop_reason=stop_reason,
        )
