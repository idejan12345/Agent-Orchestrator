from __future__ import annotations

from typing import Any

import httpx
from pydantic import Field, SecretStr, field_validator

from ..version import __version__
from .base import (
    HttpProvider,
    ProviderConfig,
    ProviderResult,
    extract_responses_text,
    raise_if_truncated,
    require_https_url,
)


class OpenAIResponsesConfig(ProviderConfig):
    api_key: SecretStr
    base_url: str = "https://api.openai.com"
    organization: str | None = Field(default=None, max_length=128)
    project: str | None = Field(default=None, max_length=128)
    store: bool = False

    @field_validator("base_url")
    @classmethod
    def validate_base_url(cls, value: str) -> str:
        return require_https_url(value, exact_host="api.openai.com")


class OpenAIResponsesProvider(HttpProvider):
    provider_name = "openai"

    def __init__(self, config: OpenAIResponsesConfig, *, client: httpx.AsyncClient | None = None):
        super().__init__(config, client=client)
        self.config: OpenAIResponsesConfig = config

    async def generate(self, prompt: str, *, request_id: str) -> ProviderResult:
        headers = {
            "authorization": f"Bearer {self.config.api_key.get_secret_value()}",
            "content-type": "application/json",
            "user-agent": f"cpo-orchestrator/{__version__}",
            "x-client-request-id": request_id,
        }
        if self.config.organization:
            headers["openai-organization"] = self.config.organization
        if self.config.project:
            headers["openai-project"] = self.config.project
        payload: dict[str, Any] = {
            "model": self.config.model,
            "input": prompt,
            "max_output_tokens": self.config.max_output_tokens,
            "store": self.config.store,
        }
        if self.config.temperature is not None:
            payload["temperature"] = self.config.temperature
        response = await self._post_json(
            self.config.base_url + "/v1/responses", headers=headers, payload=payload
        )
        data = response.json()
        stop_reason = raise_if_truncated(data, self.config.max_output_tokens, self.provider_name)
        return ProviderResult(
            text=extract_responses_text(data),
            provider=self.provider_name,
            model=self.config.model,
            request_id=response.headers.get("x-request-id") or data.get("id"),
            usage=data.get("usage") if isinstance(data.get("usage"), dict) else {},
            stop_reason=stop_reason,
        )
