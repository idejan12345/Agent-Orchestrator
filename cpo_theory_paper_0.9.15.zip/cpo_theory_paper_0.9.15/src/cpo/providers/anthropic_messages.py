from __future__ import annotations

from typing import Any

import httpx
from pydantic import SecretStr, field_validator

from ..version import __version__
from .base import (
    HttpProvider,
    ProviderConfig,
    ProviderError,
    ProviderResult,
    TruncatedOutput,
    require_https_url,
)


class AnthropicMessagesConfig(ProviderConfig):
    api_key: SecretStr
    base_url: str = "https://api.anthropic.com"
    anthropic_version: str = "2023-06-01"

    @field_validator("base_url")
    @classmethod
    def validate_base_url(cls, value: str) -> str:
        return require_https_url(value, exact_host="api.anthropic.com")


class AnthropicMessagesProvider(HttpProvider):
    provider_name = "anthropic"

    def __init__(self, config: AnthropicMessagesConfig, *, client: httpx.AsyncClient | None = None):
        super().__init__(config, client=client)
        self.config: AnthropicMessagesConfig = config
        self._temperature_unsupported: bool = False

    async def generate(self, prompt: str, *, request_id: str) -> ProviderResult:
        headers = {
            "x-api-key": self.config.api_key.get_secret_value(),
            "anthropic-version": self.config.anthropic_version,
            "content-type": "application/json",
            "user-agent": f"cpo-orchestrator/{__version__}",
            "x-client-request-id": request_id,
        }
        payload: dict[str, Any] = {
            "model": self.config.model,
            "max_tokens": self.config.max_output_tokens,
            "messages": [{"role": "user", "content": prompt}],
        }
        if self.config.temperature is not None and not self._temperature_unsupported:
            payload["temperature"] = self.config.temperature
        try:
            response = await self._post_json(
                self.config.base_url + "/v1/messages", headers=headers, payload=payload
            )
        except ProviderError as exc:
            # Some models reject the sampling parameter outright ("`temperature` is deprecated
            # for this model").  Drop it, remember that, and retry once at the provider default.
            if "temperature" in str(exc) and "temperature" in payload:
                self._temperature_unsupported = True
                payload.pop("temperature", None)
                response = await self._post_json(
                    self.config.base_url + "/v1/messages", headers=headers, payload=payload
                )
            else:
                raise
        data = response.json()
        texts = [
            block.get("text", "")
            for block in data.get("content", [])
            if isinstance(block, dict) and block.get("type") == "text"
        ]
        text = "\n".join(t.strip() for t in texts if isinstance(t, str) and t.strip())
        stop_reason = data.get("stop_reason")
        if stop_reason == "max_tokens":
            # Truncated mid-answer.  Never return this as if it were a complete response.
            raise TruncatedOutput(
                f"anthropic response hit max_tokens ({self.config.max_output_tokens}); "
                "raise max_output_tokens or shorten the task"
            )
        if not text:
            reason = stop_reason
            kinds = sorted({str(b.get("type")) for b in data.get("content", []) if isinstance(b, dict)})
            raise ProviderError(
                f"anthropic response did not contain text output (stop_reason={reason}, blocks={kinds or 'none'})"
            )
        return ProviderResult(
            text=text,
            provider=self.provider_name,
            model=self.config.model,
            request_id=response.headers.get("request-id") or data.get("id"),
            usage=data.get("usage") if isinstance(data.get("usage"), dict) else {},
            stop_reason=stop_reason,
        )
