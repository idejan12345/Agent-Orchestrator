from __future__ import annotations

import asyncio
import hashlib
import hmac
import time
from dataclasses import dataclass

from fastapi import HTTPException, Request


@dataclass(frozen=True)
class Principal:
    principal_id: str
    roles: tuple[str, ...]


class GatewayIdentityVerifier:
    def __init__(self, secret: str | None, *, clock_skew_s: int = 300):
        self.secret = secret
        self.clock_skew_s = clock_skew_s
        self._seen: dict[str, int] = {}
        self._lock = asyncio.Lock()

    async def verify(
        self,
        request: Request,
        x_cpo_principal: str | None,
        x_cpo_timestamp: str | None,
        x_cpo_signature: str | None,
        x_cpo_roles: str | None,
    ) -> Principal:
        if not self.secret:
            raise HTTPException(503, "gateway identity is not configured")
        if not (x_cpo_principal and x_cpo_timestamp and x_cpo_signature):
            raise HTTPException(401, "missing gateway identity headers")
        if len(x_cpo_principal) > 128 or not x_cpo_principal.replace("-", "").replace("_", "").isalnum():
            raise HTTPException(401, "invalid principal")
        try:
            timestamp = int(x_cpo_timestamp)
        except ValueError as exc:
            raise HTTPException(401, "invalid gateway timestamp") from exc
        if abs(int(time.time()) - timestamp) > self.clock_skew_s:
            raise HTTPException(401, "expired gateway assertion")
        body = await request.body()
        digest = hashlib.sha256(body).hexdigest()
        canonical = (
            f"{x_cpo_principal}\n{x_cpo_timestamp}\n{request.method.upper()}\n{request.url.path}\n{digest}"
        )
        expected = hmac.new(self.secret.encode(), canonical.encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(expected, x_cpo_signature):
            raise HTTPException(401, "invalid gateway signature")
        async with self._lock:
            cutoff = int(time.time()) - self.clock_skew_s
            self._seen = {sig: ts for sig, ts in self._seen.items() if ts >= cutoff}
            if x_cpo_signature in self._seen:
                raise HTTPException(409, "gateway assertion replayed")
            self._seen[x_cpo_signature] = timestamp
        roles = tuple(sorted({r.strip() for r in (x_cpo_roles or "user").split(",") if r.strip()}))
        if any(len(r) > 64 for r in roles):
            raise HTTPException(401, "invalid role")
        return Principal(x_cpo_principal, roles)


@dataclass
class Bucket:
    tokens: float
    updated: float
    concurrent: int = 0


class InMemoryQuotaManager:
    """Single-process pilot quota manager. Replace with Redis for multiple replicas."""

    def __init__(self, *, units_per_minute: int = 60, burst: int = 20, max_concurrent: int = 4):
        self.rate = units_per_minute / 60.0
        self.burst = float(burst)
        self.max_concurrent = max_concurrent
        self._buckets: dict[str, Bucket] = {}
        self._lock = asyncio.Lock()

    async def acquire(self, principal: str, units: int = 1) -> dict[str, str]:
        now = time.monotonic()
        async with self._lock:
            bucket = self._buckets.setdefault(principal, Bucket(self.burst, now))
            bucket.tokens = min(self.burst, bucket.tokens + (now - bucket.updated) * self.rate)
            bucket.updated = now
            if bucket.concurrent >= self.max_concurrent:
                raise HTTPException(429, "concurrency quota exceeded", headers={"Retry-After": "1"})
            if bucket.tokens < units:
                retry = max(1, int((units - bucket.tokens) / max(self.rate, 0.001)) + 1)
                raise HTTPException(429, "request quota exceeded", headers={"Retry-After": str(retry)})
            bucket.tokens -= units
            bucket.concurrent += 1
            return {
                "X-RateLimit-Limit": str(int(self.burst)),
                "X-RateLimit-Remaining": str(max(0, int(bucket.tokens))),
            }

    async def release(self, principal: str) -> None:
        async with self._lock:
            bucket = self._buckets.get(principal)
            if bucket:
                bucket.concurrent = max(0, bucket.concurrent - 1)
