from __future__ import annotations

import re

from .policy import DefaultPolicy


def _luhn(token: str) -> bool:
    digits = [int(x) for x in re.sub(r"\D", "", token)]
    if not 13 <= len(digits) <= 19:
        return False
    total = 0
    parity = len(digits) % 2
    for i, d in enumerate(digits):
        if i % 2 == parity:
            d *= 2
            d = d - 9 if d > 9 else d
        total += d
    return total % 10 == 0


class EnterpriseKnowledgeWorkPolicy(DefaultPolicy):
    _ssn = re.compile(r"\b\d{3}-\d{2}-\d{4}\b")
    _card = re.compile(r"\b(?:\d[ -]*?){13,19}\b")
    _injection = re.compile(
        r"(?i)(ignore (?:all|the) previous (?:instructions|rules|messages)|reveal (?:the )?system prompt|developer message|bypass policy)"
    )
    _high_impact = [
        (
            "employment",
            re.compile(r"(?i)\b(?:hire|fire)\b.{0,40}\b(?:applicant|candidate|employee|worker|person)\b"),
        ),
        (
            "credit",
            re.compile(
                r"(?i)\b(?:deny credit|approve loan)\b.{0,40}\b(?:applicant|borrower|customer|person)\b"
            ),
        ),
        ("medical", re.compile(r"(?i)\b(?:diagnose|prescribe)\b.{0,40}\b(?:patient|person|individual)\b")),
        (
            "justice",
            re.compile(r"(?i)\b(?:sentence|arrest)\b.{0,40}\b(?:defendant|suspect|person|individual)\b"),
        ),
        ("benefits", re.compile(r"(?i)\bterminate benefits\b.{0,40}\b(?:claimant|recipient|person)\b")),
    ]
    _credential_action = re.compile(
        r"(?i)\b(reset|change|retrieve|expose|send)\b.{0,30}\b(password|token|api key|secret)\b"
    )

    def _domain_scan(self, text):
        reasons = []
        if self._ssn.search(text):
            reasons.append("possible_us_ssn")
        if any(_luhn(m.group()) for m in self._card.finditer(text)):
            reasons.append("possible_payment_card")
        if self._injection.search(text):
            reasons.append("prompt_injection_marker")
        for sub, pat in self._high_impact:
            if pat.search(text):
                reasons.extend(
                    ["high_impact_decision_outside_pilot", f"high_impact_decision_outside_pilot:{sub}"]
                )
        if self._credential_action.search(text):
            reasons.append("credential_action_outside_pilot")
        return reasons

    async def check_request(self, request):
        return await super().check_request(request) + self._domain_scan(self._request_text(request))

    async def check_candidate(self, candidate):
        return await super().check_candidate(candidate) + self._domain_scan(candidate.content)

    async def check_workspace(self, workspace):
        return await super().check_workspace(workspace) + self._domain_scan(workspace.synthesis)

    def _request_text(self, request):
        values = [request.input, request.goal or ""]
        self._collect_strings(request.context, values)
        return "\n".join(values)
