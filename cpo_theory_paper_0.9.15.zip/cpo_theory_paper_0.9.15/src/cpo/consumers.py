from __future__ import annotations

from .models import ConsumerResult, OrchestrationRequest, WorkspaceContent


class TextConsumer:
    concurrency_safe = True

    def __init__(self, name: str = "response"):
        self.name = name

    async def consume(self, request: OrchestrationRequest, workspace: WorkspaceContent) -> ConsumerResult:
        return ConsumerResult(
            consumer=self.name,
            output=workspace.synthesis,
            confidence=round(0.5 + 0.5 * workspace.consensus_agreement, 3),
            metadata={
                "selected_sources": [x.candidate.source for x in workspace.selected],
                "terminal_kind": workspace.terminal_kind,
            },
        )
