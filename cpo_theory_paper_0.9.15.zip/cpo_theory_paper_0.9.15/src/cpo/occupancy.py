"""Workspace occupancy control from the capacity theorem.

The workspace is treated as a register of ``slots`` positions.  Every distinct
atom the workspace currently holds (selected candidates plus retained bundle
atoms) occupies one slot.  The theorem
``holdable = 1 + (n/2) min(nu, 1-nu)`` then bounds how many alternatives the
workspace can keep apart, and the admissible band ``[2(B-1), n-2(B-1)]`` says
whether bundling ``B`` atoms is currently possible at all.

The controller does three things, all deterministic and all reported:
* caps next-cycle selection breadth at ``floor(holdable)``;
* labels the regime (starved / admissible / saturated) relative to the
  configured target bundle;
* recommends ``expand_pool`` / ``hold`` / ``compress_workspace``.
"""

from __future__ import annotations

from dataclasses import dataclass

from .focus.capacity import admissible_band, assess_occupancy
from .models import OccupancyReport


@dataclass(frozen=True)
class OccupancyDecision:
    report: OccupancyReport
    action: str  # "expand_pool" | "hold" | "compress_workspace"
    reason: str


class OccupancyController:
    def __init__(self, slots: int = 24, target_bundle: int = 3, k_min: int = 1, k_max: int = 8):
        self.slots, self.target_bundle, self.k_min, self.k_max = slots, target_bundle, k_min, k_max

    def decide(self, held_atoms: int, requested_k: int) -> OccupancyDecision:
        occupancy = max(0, min(self.slots, held_atoms))
        a = assess_occupancy(self.slots, occupancy, target_bundle=self.target_bundle)
        cap = max(1, min(self.k_max, int(a.holdable + 1e-9)))  # tolerate 2.9999999
        selection_cap = max(1, min(cap, max(self.k_min, requested_k)))
        report = OccupancyReport(
            slots=self.slots,
            occupancy=occupancy,
            nu=a.nu,
            holdable_alternatives=a.holdable,
            max_bundle=a.max_bundle,
            largest_admissible_bundle=a.largest_admissible_bundle,
            regime=a.regime,
            selection_cap=selection_cap,
        )
        band = admissible_band(self.slots, self.target_bundle)
        if a.regime == "starved":
            return OccupancyDecision(
                report,
                "expand_pool",
                f"occupancy {occupancy} below band {band} for bundle {self.target_bundle}",
            )
        if a.regime == "saturated":
            return OccupancyDecision(
                report,
                "compress_workspace",
                f"occupancy {occupancy} above band {band}; holdable alternatives {a.holdable:.1f}",
            )
        return OccupancyDecision(report, "hold", f"occupancy {occupancy} inside band {band}")
