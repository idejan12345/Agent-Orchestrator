from __future__ import annotations

from typing import Protocol, runtime_checkable

from .models import Candidate, ConsumerResult, OrchestrationRequest, WorkspaceContent
from .sketch import Signature


@runtime_checkable
class Specialist(Protocol):
    """A private pattern source.  ``propose`` may be called with ``workspace=None`` on a
    blind resample; specialists must then answer without any workspace memory."""

    name: str
    concurrency_safe: bool

    async def propose(
        self, request: OrchestrationRequest, workspace: WorkspaceContent | None
    ) -> list[Candidate]: ...
    async def receive_broadcast(self, workspace: WorkspaceContent) -> None: ...


@runtime_checkable
class Consumer(Protocol):
    name: str
    concurrency_safe: bool

    async def consume(self, request: OrchestrationRequest, workspace: WorkspaceContent) -> ConsumerResult: ...


@runtime_checkable
class Policy(Protocol):
    async def check_request(self, request: OrchestrationRequest) -> list[str]: ...
    async def check_candidate(self, candidate: Candidate) -> list[str]: ...
    async def check_workspace(self, workspace: WorkspaceContent) -> list[str]: ...


@runtime_checkable
class Signer(Protocol):
    """Maps a text to a fixed-length binary signature.  The default is SimHash over word
    shingles; a thresholded embedding keeps the loop's algebra while improving the kernel."""

    n: int

    def sign(self, text: str) -> Signature: ...


@runtime_checkable
class TraceSink(Protocol):
    async def append(self, event: dict) -> None: ...
    async def readiness(self) -> tuple[bool, str]: ...
