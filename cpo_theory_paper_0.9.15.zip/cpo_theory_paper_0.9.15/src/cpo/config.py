from __future__ import annotations

from pydantic import BaseModel, Field, model_validator


class CPOConfig(BaseModel):
    # --- focus loop ---------------------------------------------------------
    signature_bits: int = Field(default=256, ge=64, le=4096, multiple_of=8)
    phi: float = Field(
        default=0.5, gt=0, le=1, description="selection breadth: fraction of the pool kept each cycle"
    )
    k_min: int = Field(
        default=2,
        ge=1,
        le=64,
        description="never select fewer than this when the pool allows (consensus needs >1)",
    )
    k_max: int = Field(default=8, ge=1, le=64)
    resonance_exponent: float = Field(default=1.0, ge=0, le=8)
    binding_exponent: float = Field(default=0.5, ge=0, le=8)
    hard_risk_threshold: float = Field(default=0.80, ge=0, le=1)
    fixed_point_threshold: float = Field(
        default=0.06,
        ge=0,
        le=1,
        description="fractional d_H below which the reference counts as unchanged; 0.06 absorbs paraphrase jitter of text signatures, 0.0 is the exact register criterion",
    )
    max_cycles: int = Field(default=6, ge=1, le=32)
    min_cycles: int = Field(default=1, ge=1, le=32)
    consensus_required: bool = Field(
        default=True, description="warn when a cycle degenerates to selection only (k=1)"
    )

    # --- workspace register (capacity theorem) ---------------------------
    workspace_slots: int = Field(
        default=24, ge=8, le=512, description="register size n; B_max = 1 + n/4 (24 -> 7)"
    )
    target_bundle: int = Field(default=3, ge=2, le=64)
    occupancy_control_enabled: bool = True

    # --- environmental reconfirmation (non-motif attractor test) ----------
    reconfirmation_rounds: int = Field(default=1, ge=0, le=4)
    reconfirmation_theta: float = Field(
        default=0.15,
        ge=0,
        le=0.5,
        description="fractional d_H within which a fixed point counts as reconfirmed",
    )

    # --- limits and timeouts (carried over from SGWM 0.7.1) ---------------
    max_specialists: int = Field(default=32, ge=1, le=128)
    max_candidates_per_specialist: int = Field(default=4, ge=1, le=32)
    # Defaults are for an interactive service.  The ceilings are large because a timeout here
    # does not fail loudly: it removes a candidate from the pool, which biases the method that
    # suffered it.  Evaluations raise these (see cpo.eval.baselines.CPOMethod._config).
    specialist_timeout_s: float = Field(default=5.0, gt=0, le=1800)
    consumer_timeout_s: float = Field(default=5.0, gt=0, le=1800)
    request_timeout_s: float = Field(default=30.0, gt=0, le=7200)
    max_input_chars: int = Field(default=50_000, ge=1, le=2_000_000)
    max_goal_chars: int = Field(default=10_000, ge=1, le=200_000)
    max_context_bytes: int = Field(default=100_000, ge=2, le=5_000_000)
    max_candidate_chars: int = Field(default=12_000, ge=1, le=200_000)
    max_workspace_chars: int = Field(default=64_000, ge=1, le=2_000_000)
    diagnostics_enabled: bool = True
    trace_candidate_texts: bool = Field(
        default=False,
        description=(
            "record each cycle's pool and selected candidate texts in the cycle trace. Off in "
            "production (traces would carry user content); on under evaluation, where measuring "
            "p_sel -- the correctness rate of the selected set against the pool's -- requires them."
        ),
    )
    fail_if_all_specialists_fail: bool = True

    @model_validator(mode="after")
    def validate_relationships(self):
        if self.min_cycles > self.max_cycles:
            raise ValueError("min_cycles cannot exceed max_cycles")
        if self.k_min > self.k_max:
            raise ValueError("k_min cannot exceed k_max")
        if self.target_bundle > 1 + self.workspace_slots // 4:
            raise ValueError("target_bundle exceeds B_max = 1 + slots/4 for this register")
        return self
