from __future__ import annotations

import asyncio
import hashlib
import json
import time
import uuid
from collections import defaultdict
from typing import Any, Literal

from .config import CPOConfig
from .errors import NoCandidates, PolicyRejected, RequestTimedOut
from .focus_loop import ConsensusWriter, MedoidConsensusWriter, QualityHook, TextFocusLoop
from .interfaces import Consumer, Policy, Signer, Specialist, TraceSink
from .models import Candidate, CycleTrace, OrchestrationRequest, OrchestrationResponse, WorkspaceContent
from .occupancy import OccupancyController
from .plane import trajectory_plane
from .policy import DefaultPolicy
from .reconfirmation import reconfirm
from .sketch import Signature, majority
from .tower import Atom, bundle
from .tracing import NullTraceSink
from .version import __version__


class Orchestrator:
    """validate -> request policy -> [collect -> candidate policy -> resonate/bind ->
    risk filter -> occupancy-capped top-phi selection -> majority consensus ->
    consensus writer -> workspace policy -> broadcast -> trace -> terminate?] ->
    environmental reconfirmation -> plane proxies -> consume -> trace"""

    def __init__(
        self,
        specialists: list[Specialist],
        consumers: list[Consumer],
        config: CPOConfig | None = None,
        policy: Policy | None = None,
        trace_sink: TraceSink | None = None,
        consensus_writer: ConsensusWriter | None = None,
        quality_hook: QualityHook | None = None,
        signer: Signer | None = None,
    ):
        self.config = config or CPOConfig()
        if not specialists:
            raise ValueError("at least one specialist is required")
        if len(specialists) > self.config.max_specialists:
            raise ValueError("too many specialists")
        names = [s.name for s in specialists]
        cnames = [c.name for c in consumers]
        if len(names) != len(set(names)) or len(cnames) != len(set(cnames)):
            raise ValueError("component names must be unique")
        components: list[Specialist | Consumer] = [*specialists, *consumers]
        for component in components:
            if not getattr(component, "concurrency_safe", False):
                raise ValueError(f"component {component.name!r} must declare concurrency_safe=True")
        self.specialists, self.consumers = specialists, consumers
        self.policy = policy or DefaultPolicy()
        self.trace_sink = trace_sink or NullTraceSink()
        self.writer = consensus_writer or MedoidConsensusWriter()
        self.loop = TextFocusLoop(
            n=self.config.signature_bits,
            phi=self.config.phi,
            k_min=self.config.k_min,
            resonance_exponent=self.config.resonance_exponent,
            binding_exponent=self.config.binding_exponent,
            hard_risk_threshold=self.config.hard_risk_threshold,
            quality_hook=quality_hook,
            signer=signer,
        )
        self.occupancy = OccupancyController(
            self.config.workspace_slots, self.config.target_bundle, self.config.k_min, self.config.k_max
        )
        self._request_locks: defaultdict[str, asyncio.Lock] = defaultdict(asyncio.Lock)

    # ------------------------------------------------------------------ #
    async def readiness(self) -> dict[str, Any]:
        trace_ok, trace_detail = await self.trace_sink.readiness()
        components: dict[str, dict[str, Any]] = {}
        ok_all = True
        all_components: list[Specialist | Consumer] = [*self.specialists, *self.consumers]
        for component in all_components:
            check = getattr(component, "readiness", None)
            if check is None:
                components[component.name] = {"ready": True, "detail": "no probe"}
                continue
            try:
                ok, detail = await check()
            except Exception as exc:
                ok, detail = False, f"probe failed: {type(exc).__name__}"
            components[component.name] = {"ready": ok, "detail": detail}
            ok_all = ok_all and ok
        return {
            "ready": trace_ok and ok_all,
            "trace": {"ready": trace_ok, "detail": trace_detail},
            "components": components,
            "version": __version__,
        }

    async def run(self, request: OrchestrationRequest) -> OrchestrationResponse:
        request_id = request.request_id or uuid.uuid4().hex
        bound = request.model_copy(update={"request_id": request_id})
        lock = self._request_locks[request_id]
        try:
            async with lock:
                return await asyncio.wait_for(self._run(bound), timeout=self.config.request_timeout_s)
        except TimeoutError as exc:
            await self._safe_trace({"type": "request_timeout", "request_id": request_id})
            raise RequestTimedOut("orchestration exceeded request timeout") from exc
        finally:
            if not lock.locked():
                self._request_locks.pop(request_id, None)

    # ------------------------------------------------------------------ #
    async def _run(self, request: OrchestrationRequest) -> OrchestrationResponse:
        self._validate_request_size(request)
        violations = await self.policy.check_request(request)
        if violations:
            await self._safe_trace(
                {"type": "request_rejected", "request_id": request.request_id, "reasons": violations}
            )
            raise PolicyRejected("; ".join(violations))
        request_id = request.request_id or ""
        max_cycles = min(request.max_cycles or self.config.max_cycles, self.config.max_cycles)
        n = self.config.signature_bits

        # Step 0: fix a reference.  The seed self is the request itself.
        sign = self.loop.signature
        reference = sign(f"{request.input}\n{request.goal or ''}")
        seen: dict[str, int] = {reference.hex(): 0}
        references: list[Signature] = []
        blind_consensus: list[Signature] = []
        workspace: WorkspaceContent | None = None
        traces: list[CycleTrace] = []
        warnings: list[str] = []
        held_atoms = 0
        terminal: Literal["open", "fixed_point", "cycle", "budget_exhausted", "pool_exhausted"] = "open"
        await self._safe_trace(
            {"type": "request_started", "request_id": request_id, "seed_reference": reference.hex()}
        )

        for cycle in range(1, max_cycles + 1):
            started = time.perf_counter()
            cycle_warnings: list[str] = []
            groups, failures = await self._collect(request, workspace)
            candidates: list[Candidate] = []
            for group in groups:
                for c in group[: self.config.max_candidates_per_specialist]:
                    if len(c.content) > self.config.max_candidate_chars:
                        failures.append(f"{c.source}:candidate_too_large")
                        continue
                    if await self.policy.check_candidate(c):
                        failures.append(f"{c.source}:policy_rejected")
                        continue
                    candidates.append(c)
            if not candidates:
                if workspace is not None:
                    # A later cycle produced nothing admissible.  The previous cycle's workspace is
                    # still the best available answer: keep it and stop, rather than discard it.
                    workspace = workspace.model_copy(
                        update={"terminal_kind": "pool_exhausted", "converged": False}
                    )
                    warnings.append(
                        f"cycle {cycle}: no admissible candidates; kept previous workspace ({'; '.join(failures) or 'no detail'})"
                    )
                    await self._safe_trace(
                        {
                            "type": "terminal",
                            "request_id": request_id,
                            "cycle": cycle,
                            "kind": "pool_exhausted",
                            "failures": failures,
                        }
                    )
                    break
                if self.config.fail_if_all_specialists_fail:
                    raise NoCandidates("no admissible candidates: " + ("; ".join(failures) or "no detail"))
                warnings.append("cycle produced no admissible candidates")
                break

            # the pool's unbiased regularity, for the plane proxy
            pool_sigs = [sign(c.content) for c in candidates]
            blind_consensus.append(majority(pool_sigs, reference))

            assessed = await self.loop.assess(reference, candidates)
            # occupancy this moment: atoms retained from the last cycle plus the incoming pool
            decision = self.occupancy.decide(held_atoms + len(candidates), self.config.k_max)
            if self.config.occupancy_control_enabled and decision.action != "hold":
                cycle_warnings.append(f"occupancy:{decision.action}")
            cap = (
                decision.report.selection_cap if self.config.occupancy_control_enabled else self.config.k_max
            )
            selected, rejected = self.loop.select(assessed, selection_cap=cap)
            failures.extend(f"{a.source}:rejected:{','.join(a.reasons)}" for a in rejected)
            if not selected:
                if workspace is not None:
                    workspace = workspace.model_copy(
                        update={"terminal_kind": "pool_exhausted", "converged": False}
                    )
                    warnings.append(f"cycle {cycle}: all candidates rejected; kept previous workspace")
                    break
                if self.config.fail_if_all_specialists_fail:
                    raise NoCandidates("all candidates rejected: " + "; ".join(failures))
                warnings.append("all candidates rejected")
                break
            if self.config.consensus_required and len(selected) == 1 and len(assessed) - len(rejected) > 1:
                cycle_warnings.append("selection_only:consensus_degenerate")

            report = self.loop.consensus(selected, reference)
            new_reference = report.signature
            delta = reference.xor(new_reference)
            change = delta.weight() / n
            previous_text = workspace.synthesis if workspace else None
            synthesis = await self.writer.write(
                selected, report, previous_text, self.config.max_workspace_chars
            )

            key = new_reference.hex()
            # min_cycles governs both fixed-point criteria (exact repeat, threshold) alike
            if key in seen and cycle >= self.config.min_cycles:
                period = cycle - seen[key]
                terminal = "fixed_point" if period == 1 else "cycle"
            elif change <= self.config.fixed_point_threshold and cycle >= self.config.min_cycles:
                terminal = "fixed_point"
            elif cycle == max_cycles:
                terminal = "budget_exhausted"
            seen[key] = cycle
            converged = terminal == "fixed_point"

            held_atoms = len(selected)
            occupancy_report = decision.report
            workspace = WorkspaceContent(
                request_id=request_id,
                cycle=cycle,
                reference_signature=key,
                previous_reference_signature=reference.hex(),
                reference_delta_weight=delta.weight(),
                change_signal=change,
                selected=selected,
                synthesis=synthesis,
                consensus_agreement=report.agreement,
                occupancy=occupancy_report,
                converged=converged,
                terminal_kind=terminal,
            )
            ws_violations = await self.policy.check_workspace(workspace)
            if ws_violations:
                raise PolicyRejected("workspace rejected: " + "; ".join(ws_violations))
            await self._broadcast(workspace, failures)
            references.append(new_reference)
            trace = CycleTrace(
                cycle=cycle,
                specialist_count=len(self.specialists),
                candidate_count=len(candidates),
                selected_sources=[x.candidate.source for x in selected],
                synthesis_digest=hashlib.sha256(synthesis.encode()).hexdigest(),
                reference_signature=key,
                reference_delta=delta.hex(),
                reference_delta_weight=delta.weight(),
                change_signal=change,
                consensus_agreement=report.agreement,
                occupancy=occupancy_report,
                pool_texts=(
                    [c.content for c in candidates] if self.config.trace_candidate_texts else []
                ),
                selected_texts=(
                    [x.candidate.content for x in selected]
                    if self.config.trace_candidate_texts
                    else []
                ),
                elapsed_ms=(time.perf_counter() - started) * 1000,
                converged=converged,
                terminal_kind=terminal,
                failures=failures,
                warnings=cycle_warnings,
            )
            traces.append(trace)
            warnings.extend(f"cycle {cycle}: {w}" for w in cycle_warnings)
            await self._safe_trace({"type": "cycle", "request_id": request_id, "trace": trace.model_dump()})
            reference = new_reference
            if terminal != "open":
                await self._safe_trace(
                    {
                        "type": "terminal",
                        "request_id": request_id,
                        "cycle": cycle,
                        "kind": terminal,
                        "change_signal": change,
                    }
                )
                break

        if workspace is None:
            raise NoCandidates("workspace was not created")

        reconfirmation = None
        if self.config.reconfirmation_rounds and workspace.terminal_kind == "fixed_point":
            fresh_rounds: list[list[str]] = []
            for r in range(1, self.config.reconfirmation_rounds + 1):
                blind = request.model_copy(update={"context": {**request.context, "_cpo_resample": r}})
                groups, fails = await self._collect(blind, None)
                warnings.extend(f"reconfirmation round {r}: {f}" for f in fails)
                fresh_rounds.append(
                    [
                        c.content
                        for g in groups
                        for c in g
                        if len(c.content) <= self.config.max_candidate_chars
                        and not await self.policy.check_candidate(c)
                    ]
                )
            reconfirmation = reconfirm(
                reference,
                workspace.synthesis,
                fresh_rounds,
                n=n,
                theta=self.config.reconfirmation_theta,
                phi=self.config.phi,
                k_min=self.config.k_min,
                signer=self.loop.signer,
            )
            if reconfirmation.status == "not_reconfirmed":
                warnings.append("fixed point not reconfirmed by a fresh pool")
        elif self.config.reconfirmation_rounds:
            reconfirmation = reconfirm(
                reference,
                workspace.synthesis,
                [],
                n=n,
                theta=self.config.reconfirmation_theta,
                phi=self.config.phi,
                k_min=self.config.k_min,
            )
            reconfirmation = reconfirmation.model_copy(
                update={"note": "no fixed point reached; nothing to reconfirm"}
            )

        consumer_results, consumer_failures = await self._consume(request, workspace)
        warnings.extend(consumer_failures)
        status: Literal["completed", "partial"] = (
            "partial" if warnings or any(t.failures for t in traces) else "completed"
        )
        diagnostics: dict[str, Any] = {"status": "disabled"}
        if self.config.diagnostics_enabled:
            diagnostics = {
                "status": "engineering_quantities_not_consciousness_measurements",
                "terminal_kind": workspace.terminal_kind,
                "cycles": len(traces),
                "final_change_signal": workspace.change_signal,
                "final_consensus_agreement": workspace.consensus_agreement,
                "reference_trajectory": [t.reference_signature for t in traces],
                "plane_proxy": trajectory_plane(references, blind_consensus[: len(references)]),
                "occupancy": workspace.occupancy.model_dump(),
                "bridges_not_asserted": [
                    "reference=self",
                    "fixed_point=percept",
                    "occupancy=engaged_capacity",
                ],
            }
        bundle_out = None
        if len(workspace.selected) >= 2 and workspace.occupancy.largest_admissible_bundle >= 2:
            atoms = [
                Atom(
                    label=s.candidate.source,
                    content=s.candidate.content,
                    signature=Signature.from_hex(s.assessment.signature, n),
                    metadata={"resonance": s.assessment.resonance},
                )
                for s in workspace.selected[: workspace.occupancy.largest_admissible_bundle]
            ]
            bundle_out = bundle(atoms, f"{request_id}:workspace").serialize(
                "bundled", max_chars=self.config.max_workspace_chars
            )
        response = OrchestrationResponse(
            request_id=request_id,
            status=status,
            workspace=workspace,
            consumers=consumer_results,
            cycles=traces,
            reconfirmation=reconfirmation,
            bundle=bundle_out,
            warnings=warnings,
            diagnostics=diagnostics,
        )
        await self._safe_trace(
            {
                "type": "request_finished",
                "request_id": request_id,
                "status": status,
                "terminal_kind": workspace.terminal_kind,
            }
        )
        return response

    # ------------------------------------------------------------------ #
    def _validate_request_size(self, request: OrchestrationRequest) -> None:
        if len(request.input) > self.config.max_input_chars:
            raise ValueError("input exceeds configured size")
        if request.goal and len(request.goal) > self.config.max_goal_chars:
            raise ValueError("goal exceeds configured size")
        if len(json.dumps(request.context, separators=(",", ":")).encode()) > self.config.max_context_bytes:
            raise ValueError("context exceeds configured size")

    async def _collect(self, request, workspace):
        async def call(specialist):
            try:
                result = await asyncio.wait_for(
                    specialist.propose(request, workspace), timeout=self.config.specialist_timeout_s
                )
                if not isinstance(result, list) or not all(isinstance(c, Candidate) for c in result):
                    return [], f"{specialist.name}:malformed_output"
                if any(c.source != specialist.name for c in result):
                    return [], f"{specialist.name}:source_identity_mismatch"
                return result, None
            except Exception as exc:
                return [], f"{specialist.name}:{type(exc).__name__}"

        results = await asyncio.gather(*(call(s) for s in self.specialists))
        groups = [r for r, _ in results if r]
        failures = [f for _, f in results if f]
        return groups, failures

    async def _broadcast(self, workspace, failures):
        async def send(specialist):
            try:
                await asyncio.wait_for(
                    specialist.receive_broadcast(workspace), timeout=self.config.specialist_timeout_s
                )
            except Exception as exc:
                failures.append(f"{specialist.name}:broadcast:{type(exc).__name__}")

        await asyncio.gather(*(send(s) for s in self.specialists))

    async def _consume(self, request, workspace):
        async def call(consumer):
            try:
                return await asyncio.wait_for(
                    consumer.consume(request, workspace), timeout=self.config.consumer_timeout_s
                ), None
            except Exception as exc:
                return None, f"{consumer.name}:{type(exc).__name__}"

        results = await asyncio.gather(*(call(c) for c in self.consumers))
        return [r for r, _ in results if r is not None], [f for _, f in results if f]

    async def _safe_trace(self, event: dict) -> None:
        try:
            await self.trace_sink.append(event)
        except Exception:
            return
