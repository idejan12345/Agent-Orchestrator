from __future__ import annotations

from collections.abc import Sequence
from typing import Protocol

from .focus_loop import ConsensusReport
from .models import Candidate, OrchestrationRequest, SelectedCandidate, WorkspaceContent
from .providers.base import ProviderResult


class TextProvider(Protocol):
    provider_name: str

    async def generate(self, prompt: str, *, request_id: str) -> ProviderResult: ...
    async def readiness(self) -> tuple[bool, str]: ...
    async def close(self) -> None: ...


class ProviderSpecialist:
    """Turns a reviewed text provider into a specialist.

    On a blind resample (``workspace is None`` and ``_cpo_resample`` set) the prompt
    carries no workspace, so the fresh pool is independent of the loop's history.
    """

    concurrency_safe = True

    DEFAULT_PREAMBLE = "You are a bounded specialist inside an orchestrated focus loop."
    DEFAULT_GUIDANCE = (
        "Return only a concise candidate contribution. Do not claim certainty without evidence."
    )
    DEFAULT_WORKSPACE_LABEL = "Current shared workspace (the reference the loop has converged toward so far):"

    def __init__(
        self,
        name: str,
        provider: TextProvider,
        *,
        role_instruction: str,
        max_prompt_chars: int = 40_000,
        preamble: str | None = None,
        guidance: str | None = None,
        workspace_label: str | None = None,
        answer_format: str | None = None,
    ):
        if not name or len(name) > 128:
            raise ValueError("invalid specialist name")
        if not role_instruction or len(role_instruction) > 4_000:
            raise ValueError("invalid role instruction")
        self.name, self.provider = name, provider
        self.role_instruction, self.max_prompt_chars = role_instruction, max_prompt_chars
        self.preamble = self.DEFAULT_PREAMBLE if preamble is None else preamble
        self.guidance = self.DEFAULT_GUIDANCE if guidance is None else guidance
        self.workspace_label = self.DEFAULT_WORKSPACE_LABEL if workspace_label is None else workspace_label
        self.answer_format = answer_format
        self.broadcasts: dict[str, WorkspaceContent] = {}

    def _prompt(self, request: OrchestrationRequest, workspace: WorkspaceContent | None) -> str:
        sections = [s for s in (self.preamble, self.role_instruction, self.guidance) if s]
        sections.append(f"Question:\n{request.input}")
        if request.goal:
            sections.append(f"Goal:\n{request.goal}")
        if workspace is not None:
            sections.append(f"{self.workspace_label}\n{workspace.synthesis}")
        if self.answer_format:
            sections.append(self.answer_format)
        prompt = "\n\n".join(sections)
        if len(prompt) > self.max_prompt_chars:
            raise ValueError("provider prompt exceeds specialist limit")
        return prompt

    async def propose(
        self, request: OrchestrationRequest, workspace: WorkspaceContent | None
    ) -> list[Candidate]:
        rid = request.request_id or "unbound"
        if request.context.get("_cpo_resample"):
            rid = f"{rid}:resample:{request.context['_cpo_resample']}"
        result = await self.provider.generate(self._prompt(request, workspace), request_id=rid)
        return [
            Candidate(
                source=self.name,
                content=result.text,
                claimed_risk=0.0,
                metadata={
                    "provider": result.provider,
                    "model": result.model,
                    "provider_request_id": result.request_id,
                    "usage": dict(result.usage),
                    "blind": workspace is None,
                },
            )
        ]

    async def receive_broadcast(self, workspace: WorkspaceContent) -> None:
        self.broadcasts[workspace.request_id] = workspace

    async def readiness(self) -> tuple[bool, str]:
        return await self.provider.readiness()

    async def close(self) -> None:
        await self.provider.close()


class JudgedConsensusWriter:
    """Consensus step written by a judge.

    The loop's *state* is unchanged: the reference signature is still the position-wise
    majority of the selected candidates, and convergence and blind reconfirmation work on
    it exactly as before.  What this changes is the *text* carried forward and returned:
    instead of the medoid, a model reads the selected candidates and returns the one whose
    final answer it judges correct (verbatim), ending with the required ``Answer:`` line.
    This is the reduction rule that best-of-n uses, applied inside the focus loop.  It costs
    one provider call per cycle.  Falls back to the medoid on any failure.
    """

    def __init__(self, provider: TextProvider, *, max_prompt_chars: int = 60_000):
        self.provider, self.max_prompt_chars = provider, max_prompt_chars

    async def write(
        self,
        selected: Sequence[SelectedCandidate],
        report: ConsensusReport,
        previous: str | None,
        max_chars: int,
    ) -> str:
        medoid = selected[report.medoid_index].candidate.content
        if len(selected) == 1:
            return medoid[:max_chars]
        listing = "\n\n".join(f"[{i + 1}] {s.candidate.content}" for i, s in enumerate(selected))
        prompt = (
            "Several specialists answered the same question. Their candidate answers are listed below. "
            "Check the reasoning and choose the single candidate whose final answer is correct. "
            "Reproduce that candidate verbatim, then state its final answer on the last line as "
            "'Answer: <answer>'. If none is correct, reproduce the most nearly correct one and give "
            "the corrected final answer on the last line.\n\n"
            f"Candidates:\n{listing}"
        )
        if len(prompt) > self.max_prompt_chars:
            return medoid[:max_chars]
        try:
            result = await self.provider.generate(prompt, request_id="judge")
            return (result.text or medoid)[:max_chars]
        except Exception:
            return medoid[:max_chars]


class ProviderConsensusWriter:
    """Consensus step written by a provider: merges the selected candidates into one
    draft, told which positions they agree on.  Falls back to the medoid on failure."""

    def __init__(self, provider: TextProvider, *, max_prompt_chars: int = 60_000):
        self.provider, self.max_prompt_chars = provider, max_prompt_chars

    async def write(
        self,
        selected: Sequence[SelectedCandidate],
        report: ConsensusReport,
        previous: str | None,
        max_chars: int,
    ) -> str:
        medoid = selected[report.medoid_index].candidate.content
        body = "\n\n".join(
            f"[{s.candidate.source}; resonance={s.assessment.resonance:.2f}] {s.candidate.content}"
            for s in selected
        )
        prompt = (
            "Merge the following candidate contributions into one draft that keeps only what "
            "they agree on and states disagreements explicitly. Do not add new claims. "
            f"Their pairwise agreement is {report.agreement:.2f}.\n\n{body}"
        )
        if len(prompt) > self.max_prompt_chars:
            return medoid[:max_chars]
        try:
            result = await self.provider.generate(prompt, request_id="consensus")
            return (result.text or medoid)[:max_chars]
        except Exception:
            return medoid[:max_chars]
