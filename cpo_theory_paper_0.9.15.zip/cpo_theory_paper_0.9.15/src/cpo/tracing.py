from __future__ import annotations

import asyncio
import hashlib
import json
import os
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# Cross-platform file lock
# On POSIX (Linux, macOS) we use fcntl.flock.
# On Windows we use msvcrt.locking or a fallback .lock-file sentinel.
# ---------------------------------------------------------------------------

if sys.platform == "win32":
    import msvcrt

    def _lock(fh) -> None:
        # Lock the first byte of the file as an exclusive mutex.
        # We retry briefly in case another process holds it.
        import time

        fh.seek(0)
        deadline = time.monotonic() + 10.0
        while True:
            try:
                msvcrt.locking(fh.fileno(), msvcrt.LK_NBLCK, 1)
                return
            except OSError:
                if time.monotonic() > deadline:
                    raise
                time.sleep(0.05)

    def _unlock(fh) -> None:
        fh.seek(0)
        try:
            msvcrt.locking(fh.fileno(), msvcrt.LK_UNLCK, 1)
        except OSError:
            pass  # already unlocked; harmless

else:
    import fcntl

    def _lock(fh) -> None:
        fcntl.flock(fh.fileno(), fcntl.LOCK_EX)

    def _unlock(fh) -> None:
        fcntl.flock(fh.fileno(), fcntl.LOCK_UN)


class NullTraceSink:
    async def append(self, event: dict) -> None:
        return None

    async def readiness(self) -> tuple[bool, str]:
        return True, "disabled"


class HashChainJsonlSink:
    """Process-safe, restart-aware hash-linked JSONL trace.

    Works on Windows (msvcrt.locking) and POSIX (fcntl.flock).
    """

    genesis = "0" * 64

    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.lock_path = self.path.with_suffix(self.path.suffix + ".lock")
        self._async_lock = asyncio.Lock()

    def _last_hash_locked(self) -> str:
        if not self.path.exists() or self.path.stat().st_size == 0:
            return self.genesis
        lines = self.path.read_text(encoding="utf-8").splitlines()
        return json.loads(lines[-1])["hash"] if lines else self.genesis

    async def append(self, event: dict) -> None:
        async with self._async_lock:
            # "a+" creates the file if absent and lets us hold a lock byte on it.
            with self.lock_path.open("a+", encoding="utf-8") as lock_file:
                _lock(lock_file)
                try:
                    previous = self._last_hash_locked()
                    canonical = json.dumps(event, sort_keys=True, separators=(",", ":"), default=str)
                    digest = hashlib.sha256((previous + canonical).encode()).hexdigest()
                    record = {"previous_hash": previous, "event": event, "hash": digest}
                    with self.path.open("a", encoding="utf-8") as f:
                        f.write(json.dumps(record, sort_keys=True, default=str) + "\n")
                        f.flush()
                        os.fsync(f.fileno())
                finally:
                    _unlock(lock_file)

    async def readiness(self) -> tuple[bool, str]:
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            probe = self.path.parent / f".{self.path.name}.ready"
            probe.write_text("ready", encoding="utf-8")
            probe.unlink()
            return True, "writable"
        except OSError as exc:
            return False, f"trace path unavailable: {type(exc).__name__}"

    def verify(self) -> tuple[bool, str]:
        previous = self.genesis
        if not self.path.exists():
            return True, "empty"
        for line_number, line in enumerate(self.path.read_text(encoding="utf-8").splitlines(), 1):
            record = json.loads(line)
            if record.get("previous_hash") != previous:
                return False, f"broken previous hash at line {line_number}"
            canonical = json.dumps(record["event"], sort_keys=True, separators=(",", ":"), default=str)
            expected = hashlib.sha256((previous + canonical).encode()).hexdigest()
            if record.get("hash") != expected:
                return False, f"invalid hash at line {line_number}"
            previous = expected
        return True, previous
