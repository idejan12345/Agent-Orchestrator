from __future__ import annotations

import json
import re
from typing import Any

from .models import Candidate, OrchestrationRequest, WorkspaceContent


class DefaultPolicy:
    """Structural secret policy only; domain safety policy remains an application responsibility."""

    _patterns = [
        re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
        re.compile(r"(?i)(?:api[_-]?key|secret|token|password)\s*[:=]\s*[A-Za-z0-9_\-./+]{12,}"),
    ]

    async def check_request(self, request: OrchestrationRequest) -> list[str]:
        values: list[str] = [request.input, request.goal or ""]
        self._collect_strings(request.context, values)
        return self._scan("\n".join(values))

    def _collect_strings(self, value: Any, output: list[str]) -> None:
        if isinstance(value, str):
            output.append(value)
        elif isinstance(value, list):
            for item in value:
                self._collect_strings(item, output)
        elif isinstance(value, dict):
            for key, item in value.items():
                output.append(key)
                if isinstance(item, str):
                    output.append(f"{key}={item}")
                self._collect_strings(item, output)

    async def check_candidate(self, candidate: Candidate) -> list[str]:
        return self._scan(candidate.content + "\n" + json.dumps(candidate.metadata, sort_keys=True))

    async def check_workspace(self, workspace: WorkspaceContent) -> list[str]:
        return self._scan(workspace.synthesis)

    def _scan(self, text: str) -> list[str]:
        return ["potential secret material"] if any(p.search(text) for p in self._patterns) else []
