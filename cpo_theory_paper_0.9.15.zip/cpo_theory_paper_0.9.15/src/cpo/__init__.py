"""Chosen-Pattern Orchestrator (CPO): a focus-loop agent orchestrator SDK."""

from .version import __version__

__all__ = ["__version__"]
