from __future__ import annotations

import hmac
import json
import os
import time

from fastapi import Depends, FastAPI, Header, HTTPException, Request, Response
from fastapi.responses import PlainTextResponse

from .config import CPOConfig
from .consumers import TextConsumer
from .domain_policy import EnterpriseKnowledgeWorkPolicy
from .errors import NoCandidates, PolicyRejected, RequestTimedOut
from .gateway import GatewayIdentityVerifier, InMemoryQuotaManager, Principal
from .models import OrchestrationRequest, OrchestrationResponse
from .observability import LOGGER, METRICS, configure_json_logging
from .orchestrator import Orchestrator
from .specialists import EchoSpecialist
from .tracing import HashChainJsonlSink
from .version import __version__

VERSION = __version__
configure_json_logging(os.getenv("CPO_LOG_LEVEL", "INFO"))
app = FastAPI(title="Chosen-Pattern Orchestrator", version=VERSION)

trace_path = os.getenv("CPO_TRACE_PATH", "cpo-traces.jsonl")
orchestrator = Orchestrator(
    specialists=[
        EchoSpecialist("analysis", "Analysis"),
        EchoSpecialist("planning", "Plan"),
        EchoSpecialist("review", "Review"),
    ],
    consumers=[TextConsumer()],
    config=CPOConfig(),
    policy=EnterpriseKnowledgeWorkPolicy(),
    trace_sink=HashChainJsonlSink(trace_path),
)
identity = GatewayIdentityVerifier(os.getenv("CPO_GATEWAY_SECRET"))
quotas = InMemoryQuotaManager(
    units_per_minute=int(os.getenv("CPO_QUOTA_UNITS_PER_MINUTE", "60")),
    burst=int(os.getenv("CPO_QUOTA_BURST", "20")),
    max_concurrent=int(os.getenv("CPO_QUOTA_MAX_CONCURRENT", "4")),
)
_MIN_UNITS = orchestrator.config.max_cycles + orchestrator.config.reconfirmation_rounds
if quotas.burst < _MIN_UNITS:
    LOGGER.warning(
        json.dumps(
            {
                "event": "quota_burst_below_request_cost",
                "burst": quotas.burst,
                "units_per_request": _MIN_UNITS,
                "detail": "a full-length request can never be admitted; raise CPO_QUOTA_BURST",
            }
        )
    )


@app.middleware("http")
async def observe_http(request: Request, call_next):
    started = time.perf_counter()
    METRICS.gauge_add("cpo_http_inflight", value=1)
    status = "500"
    try:
        response = await call_next(request)
        status = str(response.status_code)
        return response
    finally:
        elapsed = time.perf_counter() - started
        METRICS.inc(
            "cpo_http_requests_total",
            (("method", request.method), ("path", request.url.path), ("status", status)),
        )
        METRICS.observe("cpo_http_request_duration", elapsed, (("path", request.url.path),))
        METRICS.gauge_add("cpo_http_inflight", value=-1)
        LOGGER.info(
            json.dumps(
                {
                    "event": "http_request",
                    "method": request.method,
                    "path": request.url.path,
                    "status": status,
                    "elapsed_ms": round(elapsed * 1000, 3),
                }
            )
        )


async def gateway_principal(
    request: Request,
    x_cpo_principal: str | None = Header(default=None),
    x_cpo_timestamp: str | None = Header(default=None),
    x_cpo_signature: str | None = Header(default=None),
    x_cpo_roles: str | None = Header(default=None),
) -> Principal:
    return await identity.verify(request, x_cpo_principal, x_cpo_timestamp, x_cpo_signature, x_cpo_roles)


@app.get("/health/live")
async def liveness():
    return {"status": "alive", "version": VERSION}


@app.get("/health/ready")
async def readiness(response: Response):
    result = await orchestrator.readiness()
    result["gateway_identity_configured"] = bool(identity.secret)
    result["ready"] = result["ready"] and bool(identity.secret)
    if not result["ready"]:
        response.status_code = 503
    return result


@app.get("/metrics", response_class=PlainTextResponse)
async def metrics(x_metrics_token: str | None = Header(default=None)):
    expected = os.getenv("CPO_METRICS_TOKEN")
    if not expected:
        raise HTTPException(503, "metrics authentication is not configured")
    if x_metrics_token is None or not hmac.compare_digest(x_metrics_token, expected):
        raise HTTPException(401, "invalid metrics token")
    return PlainTextResponse(METRICS.render(), media_type="text/plain; version=0.0.4; charset=utf-8")


@app.post("/v1/orchestrate", response_model=OrchestrationResponse)
async def run(
    request: OrchestrationRequest, response: Response, principal: Principal = Depends(gateway_principal)
):
    units = (request.max_cycles or orchestrator.config.max_cycles) + orchestrator.config.reconfirmation_rounds
    headers = await quotas.acquire(principal.principal_id, units)
    for key, value in headers.items():
        response.headers[key] = value
    METRICS.gauge_add("cpo_orchestration_inflight", value=1)
    started = time.perf_counter()
    try:
        context = dict(request.context)
        context.pop("_cpo_resample", None)  # never client-settable
        context["_gateway_identity"] = {
            "principal_id": principal.principal_id,
            "roles": list(principal.roles),
        }
        result = await orchestrator.run(request.model_copy(update={"context": context}))
        METRICS.inc(
            "cpo_orchestrations_total",
            (
                ("status", result.status),
                ("terminal", result.workspace.terminal_kind if result.workspace else "none"),
            ),
        )
        if result.reconfirmation:
            METRICS.inc("cpo_reconfirmation_total", (("status", result.reconfirmation.status),))
        return result
    except PolicyRejected as exc:
        METRICS.inc("cpo_policy_rejections_total")
        raise HTTPException(403, str(exc)) from exc
    except NoCandidates as exc:
        raise HTTPException(422, str(exc)) from exc
    except RequestTimedOut as exc:
        raise HTTPException(504, str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from exc
    finally:
        await quotas.release(principal.principal_id)
        METRICS.gauge_add("cpo_orchestration_inflight", value=-1)
        METRICS.observe("cpo_orchestration_duration", time.perf_counter() - started)


def main():
    import uvicorn

    uvicorn.run("cpo.api:app", host="127.0.0.1", port=8000)
