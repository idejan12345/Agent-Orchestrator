"""Command-line entry points that reproduce the paper's computed tables."""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import asdict

from .focus import PoolSpec, run_census
from .focus.archetypes import compute_plane


def census_main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Census of focus-map attractors (theory paper, Appendix B)")
    ap.add_argument("--n", type=int, default=24)
    ap.add_argument("--pool-size", type=int, default=20_000)
    ap.add_argument("--motif-fraction", type=float, default=0.15)
    ap.add_argument("--corruption", type=float, default=0.20)
    ap.add_argument("--phi", type=float, default=0.10)
    ap.add_argument("--theta", type=int, default=3)
    ap.add_argument("--runs", type=int, default=200)
    ap.add_argument("--seeds", type=str, default="1,2,3")
    ap.add_argument("--out", type=str, default=None)
    a = ap.parse_args(argv)
    spec = PoolSpec(n=a.n, size=a.pool_size, motif_fraction=a.motif_fraction, corruption=a.corruption)
    report = run_census(
        spec, runs=a.runs, phi=a.phi, theta=a.theta, seeds=tuple(int(s) for s in a.seeds.split(","))
    )
    text = json.dumps(report.to_dict(), indent=2, default=str)
    if a.out:
        with open(a.out, "w", encoding="utf-8") as f:
            f.write(text)
    print(text if not a.out else json.dumps(report.summary(), indent=2, default=str))
    return 0


def plane_main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="(W, M*) archetype plane (theory paper, Appendix B; the source model's coordinates)")
    ap.add_argument("--length", type=int, default=100_000)
    ap.add_argument("--offsets", type=int, default=50_000)
    ap.add_argument("--seed", type=int, default=11)
    ap.add_argument("--out", type=str, default=None)
    a = ap.parse_args(argv)
    plane = compute_plane(length=a.length, offsets=a.offsets, seed=a.seed)
    out = {
        "settings": {
            "length": a.length,
            "offsets": a.offsets,
            "seed": a.seed,
            "block": 4,
            "conditioner": "two_state",
        },
        "archetypes": {name: {k: asdict(v) for k, v in coords.items()} for name, coords in plane.items()},
        "note": (
            "Absolute values are artefacts of the construction (paper Appendix); the supported "
            "claim is dissociability: dreamer high M*/low W, animal the reverse. M* is an upper bound."
        ),
    }
    text = json.dumps(out, indent=2)
    if a.out:
        with open(a.out, "w", encoding="utf-8") as f:
            f.write(text)
    print(text)
    return 0


def run_main(argv: list[str] | None = None) -> int:
    """Run one request through the focus loop with the built-in echo specialists and print
    the response as JSON.  Useful for smoke tests and for inspecting the report format."""
    import asyncio

    from .config import CPOConfig
    from .consumers import TextConsumer
    from .interfaces import Specialist
    from .models import OrchestrationRequest
    from .orchestrator import Orchestrator
    from .specialists import EchoSpecialist, NoisySpecialist

    ap = argparse.ArgumentParser(description="Run a request through the focus loop (echo specialists)")
    ap.add_argument("input")
    ap.add_argument("--goal", default=None)
    ap.add_argument("--noisy", type=int, default=1, help="number of noisy specialists to add")
    ap.add_argument("--max-cycles", type=int, default=6)
    ap.add_argument("--phi", type=float, default=0.5)
    ap.add_argument("--fixed-point-threshold", type=float, default=0.06)
    ap.add_argument("--compact", action="store_true", help="print only the cycle summary")
    a = ap.parse_args(argv)
    specialists: list[Specialist] = [
        EchoSpecialist("analysis", "Analysis"),
        EchoSpecialist("planning", "Plan"),
        EchoSpecialist("review", "Review"),
    ] + [NoisySpecialist(f"noise{i}", seed=i) for i in range(a.noisy)]
    cfg = CPOConfig(max_cycles=a.max_cycles, phi=a.phi, fixed_point_threshold=a.fixed_point_threshold)
    orch = Orchestrator(specialists, [TextConsumer()], config=cfg)
    result = asyncio.run(orch.run(OrchestrationRequest(input=a.input, goal=a.goal)))
    if a.compact:
        for t in result.cycles:
            print(
                f"cycle {t.cycle}: change={t.change_signal:.3f} selected={t.selected_sources} "
                f"cap={t.occupancy.selection_cap} terminal={t.terminal_kind}"
            )
        print("reconfirmation:", result.reconfirmation.status if result.reconfirmation else None)
    else:
        print(result.model_dump_json(indent=2))
    return 0


if __name__ == "__main__":  # pragma: no cover
    sys.exit(census_main())
