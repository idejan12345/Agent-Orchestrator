"""Capacity of a register: how many alternatives it holds apart (theory paper, Definition 1
and Theorem 3, proved there and checked by ``tests/test_register_theorems.py``).

* holdable alternatives  #(nu) = 1 + (n/2) min(nu, 1-nu); the exact maximum is its floor
* admissible occupancy band for holding B apart:  N in [2(B-1), n-2(B-1)]
* band width W(B) = n - 4(B-1) + 1,   B_max = 1 + floor(n/4),   n = 4 (B_max - 1)
* duty cycle pi(B) = Pr[N in band] under a declared occupancy distribution
* serialisation bound: binding share <= (B-1)/(2B-1) < 1/2  (from the source model)

Using the theorem to cap selection breadth is a design policy (theory paper, sec. 3.4);
whether capped trajectories are better is untested.  See docs/THEORY_MAPPING.md.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Literal


def holdable_alternatives(n: int, occupancy: int) -> float:
    if not 0 <= occupancy <= n:
        raise ValueError("occupancy must lie in [0, n]")
    nu = occupancy / n
    return 1.0 + (n / 2.0) * min(nu, 1.0 - nu)


def holdable_alternatives_fraction(n: int, nu: float) -> float:
    if not 0.0 <= nu <= 1.0:
        raise ValueError("nu must lie in [0, 1]")
    return 1.0 + (n / 2.0) * min(nu, 1.0 - nu)


def admissible_band(n: int, bundle: int) -> tuple[int, int] | None:
    """Occupancy states at which a register of size n can hold `bundle` items apart."""
    if bundle < 1:
        raise ValueError("bundle size must be positive")
    lo, hi = 2 * (bundle - 1), n - 2 * (bundle - 1)
    return (lo, hi) if lo <= hi else None


def band_width(n: int, bundle: int) -> int:
    return max(0, n - 4 * (bundle - 1) + 1)


def max_bundle(n: int) -> int:
    """B_max = 1 + n/4 (floor for n not divisible by 4)."""
    return 1 + n // 4


def register_from_span(b_max: int) -> int:
    """n = 4 (B_max - 1): Miller's 7 gives 24, Cowan's 4 gives 12."""
    if b_max < 2:
        raise ValueError("span must be at least 2")
    return 4 * (b_max - 1)


def duty_cycle(n: int, bundle: int, *, sigma: float | None = None) -> float:
    """Pr[N in admissible band] for N ~ Bin(n, 1/2) (sigma=None) or for a discretised
    normal with mean n/2 and the given standard deviation (the paper's 'regulated' rows)."""
    band = admissible_band(n, bundle)
    if band is None:
        return 0.0
    lo, hi = band
    if sigma is None:
        return sum(math.comb(n, k) for k in range(lo, hi + 1)) / 2**n
    weights = [math.exp(-0.5 * ((k - n / 2) / sigma) ** 2) for k in range(n + 1)]
    total = sum(weights)
    return sum(weights[k] for k in range(lo, hi + 1)) / total


def serialisation_binding_bound(bundle: int) -> float:
    """Under constituent-wise serialisation the share of the message that can carry
    binding is at most (B-1)/(2B-1) < 1/2 (Theorem "serialisation")."""
    if bundle < 2:
        raise ValueError("bundle size must be at least 2")
    return (bundle - 1) / (2 * bundle - 1)


@dataclass(frozen=True)
class OccupancyAssessment:
    n: int
    occupancy: int
    nu: float
    holdable: float
    max_bundle: int
    largest_admissible_bundle: int
    distance_to_half_filling: int
    regime: Literal["starved", "admissible", "saturated"]

    def admits(self, bundle: int) -> bool:
        band = admissible_band(self.n, bundle)
        return band is not None and band[0] <= self.occupancy <= band[1]


def assess_occupancy(n: int, occupancy: int, *, target_bundle: int = 3) -> OccupancyAssessment:
    """Locate an occupancy on the tent and against the band required for `target_bundle`."""
    holdable = holdable_alternatives(n, occupancy)
    largest = max(
        (
            b
            for b in range(1, max_bundle(n) + 1)
            if (band := admissible_band(n, b)) and band[0] <= occupancy <= band[1]
        ),
        default=1,
    )
    band = admissible_band(n, target_bundle)
    regime: Literal["starved", "admissible", "saturated"]
    if band is None or occupancy < band[0]:
        regime = "starved"
    elif occupancy > band[1]:
        regime = "saturated"
    else:
        regime = "admissible"
    return OccupancyAssessment(
        n=n,
        occupancy=occupancy,
        nu=occupancy / n,
        holdable=holdable,
        max_bundle=max_bundle(n),
        largest_admissible_bundle=largest,
        distance_to_half_filling=abs(occupancy - n // 2),
        regime=regime,
    )
