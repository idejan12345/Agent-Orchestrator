"""Information-theoretic quantities used by the paper.

* ``phi_mincut``  -- the binding Postulate's Phi_mc(X) = min over non-trivial
  bipartitions S of H(X_S) + H(X_S^c) - H(X), for a joint distribution over m
  discrete parts.  On the XOR triple it returns exactly 1 bit.
* ``estimate_W`` / ``estimate_M_star`` -- the world-model coordinate
  W = I(s0; e-bar) and the *conditional* self-model coordinate
  M* = I(s0_past; s0_future | e-bar), estimated with a shuffle-corrected plug-in
  estimator on k-bit blocks, as §"The consciousness plane" describes.  The
  estimators return a value and a Monte-Carlo standard error, and refuse to
  produce a number when the sample is too small to mean anything.

The paper itself notes that M* as estimated this way is an upper bound on the
self-model (Remark "The deconfounding is partial").  Callers must not present it
as anything more.
"""

from __future__ import annotations

import math
import random
from collections import Counter
from collections.abc import Hashable, Iterable, Sequence
from dataclasses import dataclass
from itertools import combinations


def entropy(counts: Iterable[int]) -> float:
    total = sum(counts)
    if total == 0:
        return 0.0
    return -sum((c / total) * math.log2(c / total) for c in counts if c)


def entropy_of(samples: Sequence[Hashable]) -> float:
    return entropy(Counter(samples).values())


def mutual_information(x: Sequence[Hashable], y: Sequence[Hashable]) -> float:
    if len(x) != len(y):
        raise ValueError("paired samples required")
    return entropy_of(x) + entropy_of(y) - entropy_of(list(zip(x, y)))


def conditional_mutual_information(
    x: Sequence[Hashable], y: Sequence[Hashable], z: Sequence[Hashable]
) -> float:
    """I(X;Y|Z) = H(X,Z) + H(Y,Z) - H(X,Y,Z) - H(Z)."""
    if not len(x) == len(y) == len(z):
        raise ValueError("paired samples required")
    return (
        entropy_of(list(zip(x, z)))
        + entropy_of(list(zip(y, z)))
        - entropy_of(list(zip(x, y, z)))
        - entropy_of(z)
    )


# --------------------------------------------------------------------------- #
# Binding: Phi_mc
# --------------------------------------------------------------------------- #
def phi_mincut(joint: dict[tuple[Hashable, ...], float]) -> tuple[float, tuple[int, ...]]:
    """Min-cut integration of a joint distribution over m parts.

    ``joint`` maps outcome tuples (x_1, ..., x_m) to probabilities or counts.
    Returns (Phi_mc in bits, the minimising part-subset S).
    """
    if not joint:
        raise ValueError("empty joint distribution")
    m = len(next(iter(joint)))
    if m < 2:
        raise ValueError("at least two parts are required")
    if any(len(k) != m for k in joint):
        raise ValueError("all outcomes must have the same arity")
    total = float(sum(joint.values()))
    probs = {k: v / total for k, v in joint.items() if v > 0}
    h_all = -sum(p * math.log2(p) for p in probs.values())

    def marginal_entropy(idx: tuple[int, ...]) -> float:
        marg: dict[tuple, float] = {}
        for k, p in probs.items():
            key = tuple(k[i] for i in idx)
            marg[key] = marg.get(key, 0.0) + p
        return -sum(p * math.log2(p) for p in marg.values())

    best: float = math.inf
    best_s: tuple[int, ...] = ()
    parts = tuple(range(m))
    for size in range(1, m // 2 + 1):
        for s in combinations(parts, size):
            sc = tuple(i for i in parts if i not in s)
            if size == m / 2 and s > sc:
                continue  # each bipartition once
            value = marginal_entropy(s) + marginal_entropy(sc) - h_all
            if value < best:
                best, best_s = value, s
    return max(0.0, best), best_s


def xor_triple() -> dict[tuple[int, int, int], float]:
    """Joint distribution of (x, y, x xor y) with x, y fair: Phi_mc is exactly 1 bit."""
    return {(x, y, x ^ y): 0.25 for x in (0, 1) for y in (0, 1)}


# --------------------------------------------------------------------------- #
# (W, M*) estimators
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class Estimate:
    value: float | None
    standard_error: float | None
    samples: int
    status: str  # "ok" | "insufficient_samples"
    note: str = ""


def _blocks(bits: Sequence[int], offsets: Sequence[int], block: int) -> list[tuple[int, ...]]:
    return [tuple(bits[o : o + block]) for o in offsets]


def _shuffle_corrected(
    x: Sequence[Hashable],
    y: Sequence[Hashable],
    z: Sequence[Hashable] | None,
    rng: random.Random,
    shuffles: int,
    batches: int,
) -> tuple[float, float]:
    """Plug-in (C)MI minus the mean of the same statistic under label shuffling, with a
    standard error from splitting the sample into batches."""

    def stat(a, b, c):
        return conditional_mutual_information(a, b, c) if c is not None else mutual_information(a, b)

    raw = stat(x, y, z)
    y_list = list(y)
    nulls = []
    for _ in range(shuffles):
        rng.shuffle(y_list)
        nulls.append(stat(x, y_list, z))
    corrected = raw - sum(nulls) / len(nulls)
    # batch standard error of the *raw* statistic
    size = len(x) // batches
    if size < 8:
        return corrected, float("nan")
    parts = []
    for b in range(batches):
        sl = slice(b * size, (b + 1) * size)
        parts.append(stat(x[sl], y[sl], z[sl] if z is not None else None))
    mean = sum(parts) / batches
    var = sum((p - mean) ** 2 for p in parts) / max(1, batches - 1)
    return corrected, math.sqrt(var / batches)


def estimate_W(
    reference: Sequence[int],
    environment: Sequence[int],
    *,
    block: int = 4,
    offsets: int = 20_000,
    seed: int = 0,
    min_samples: int = 512,
    shuffles: int = 5,
    batches: int = 8,
) -> Estimate:
    """W(s0) = I(s0; e-bar) on k-bit blocks at random stationary offsets."""
    if len(reference) != len(environment):
        raise ValueError("reference and environment must be aligned bit sequences")
    usable = len(reference) - block
    if usable < min_samples:
        return Estimate(
            None,
            None,
            max(0, usable),
            "insufficient_samples",
            f"need at least {min_samples} aligned bits beyond one block",
        )
    rng = random.Random(seed)  # nosec B311 - simulation, not security
    offs = [rng.randrange(0, usable) for _ in range(min(offsets, usable))]
    x = _blocks(reference, offs, block)
    y = _blocks(environment, offs, block)
    value, se = _shuffle_corrected(x, y, None, rng, shuffles, batches)
    return Estimate(
        max(0.0, value),
        None if math.isnan(se) else se,
        len(offs),
        "ok",
        "shuffle-corrected plug-in estimator; bits",
    )


def two_state(block_bits: tuple[int, ...]) -> int:
    """The paper's conditioner: the environment block coarse-grained to above/below its median."""
    return 1 if sum(block_bits) * 2 >= len(block_bits) else 0


def estimate_M_star(
    reference: Sequence[int],
    environment: Sequence[int] | None,
    *,
    block: int = 4,
    offsets: int = 20_000,
    seed: int = 0,
    min_samples: int = 512,
    shuffles: int = 5,
    batches: int = 8,
    conditioner: str = "two_state",
) -> Estimate:
    """M*(s0) = I(s0_past; s0_future | e-bar).  With environment=None this is the raw,
    confounded M of eq. (self-model-raw); the paper explains why that is not the axis.

    ``conditioner`` is "two_state" (the paper's above/below-median summary of the
    environment block) or "block" (the full environment block).  The paper documents
    that the two-state conditioner only partially removes the environmental confound.
    """
    usable = len(reference) - 2 * block
    if environment is not None and len(environment) != len(reference):
        raise ValueError("reference and environment must be aligned bit sequences")
    if usable < min_samples:
        return Estimate(
            None,
            None,
            max(0, usable),
            "insufficient_samples",
            f"need at least {min_samples} aligned bits beyond two blocks",
        )
    rng = random.Random(seed)  # nosec B311 - simulation, not security
    offs = [rng.randrange(0, usable) for _ in range(min(offsets, usable))]
    past = _blocks(reference, offs, block)
    future = _blocks(reference, [o + block for o in offs], block)
    cond: list[Hashable] | None = None
    if environment is not None:
        env_blocks = _blocks(environment, offs, block)
        if conditioner == "two_state":
            cond = [two_state(b) for b in env_blocks]
        elif conditioner == "block":
            cond = list(env_blocks)
        else:
            raise ValueError("conditioner must be 'two_state' or 'block'")
    value, se = _shuffle_corrected(past, future, cond, rng, shuffles, batches)
    note = (
        "conditional excess entropy; upper bound on the self-model (partial deconfounding)"
        if environment is not None
        else "raw excess entropy; confounded by environmental predictability"
    )
    return Estimate(max(0.0, value), None if math.isnan(se) else se, len(offs), "ok", note)
