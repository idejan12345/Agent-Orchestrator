"""Generative models for the (W, M*) archetypes (paper Appendix "Generative models").

Environment: two-regime hidden Markov source (switch rate 0.02, emission fidelity
0.85).  Self-motif: period-4 motif 1011 at a random phase with phase slips at rate
0.01 and bit flips at rate 0.05.  Archetypes interleave a world-tracking channel
(even positions) and a self-model channel (odd positions).

The paper is explicit that the absolute values are artefacts of the construction;
the only claim they support is that the two coordinates are dissociable.
"""

from __future__ import annotations

import random
from dataclasses import dataclass

from .information import Estimate, estimate_M_star, estimate_W

SELF_MOTIF = (1, 0, 1, 1)


def environment(
    length: int, rng: random.Random, *, switch: float = 0.02, fidelity: float = 0.85
) -> tuple[list[int], list[int]]:
    """Returns (emitted bits, latent regime bits)."""
    sigma = rng.randrange(2)
    emitted, latent = [], []
    for _ in range(length):
        if rng.random() < switch:
            sigma ^= 1
        latent.append(sigma)
        emitted.append(sigma if rng.random() < fidelity else sigma ^ 1)
    return emitted, latent


def corrupt(bits: list[int], rate: float, rng: random.Random) -> list[int]:
    return [b ^ 1 if rng.random() < rate else b for b in bits]


def self_motif(length: int, rng: random.Random, *, slip: float = 0.01, flip: float = 0.05) -> list[int]:
    phase = rng.randrange(4)
    out = []
    for _ in range(length):
        if rng.random() < slip:
            phase = rng.randrange(4)
        bit = SELF_MOTIF[phase]
        out.append(bit ^ 1 if rng.random() < flip else bit)
        phase = (phase + 1) % 4
    return out


def uniform(length: int, rng: random.Random) -> list[int]:
    return [rng.randrange(2) for _ in range(length)]


@dataclass(frozen=True)
class Archetype:
    name: str
    even_corruption: float | None  # None -> uniform noise on even positions
    odd_self_model: bool  # True -> self motif on odd positions


ARCHETYPES: tuple[Archetype, ...] = (
    Archetype("noise", None, False),
    Archetype("plant", 0.42, False),
    Archetype("thermostat", 0.20, False),
    Archetype("animal", 0.05, False),
    Archetype("dreamer", None, True),
    Archetype("human", 0.05, True),
)


def build_reference(arch: Archetype, env_bits: list[int], rng: random.Random) -> list[int]:
    length = len(env_bits)
    even = (
        uniform(length, rng) if arch.even_corruption is None else corrupt(env_bits, arch.even_corruption, rng)
    )
    odd = self_motif(length, rng) if arch.odd_self_model else uniform(length, rng)
    return [even[i] if i % 2 == 0 else odd[i] for i in range(length)]


def compute_plane(
    *, length: int = 100_000, offsets: int = 50_000, seed: int = 11, block: int = 4
) -> dict[str, dict[str, Estimate]]:
    """Place every archetype in the (W, M*) plane.  Defaults are scaled down from the
    paper's 4e5 bits / 2e5 offsets so the computation runs in seconds; the paper's
    settings are reachable by argument."""
    rng = random.Random(seed)  # nosec B311 - simulation, not security
    env, _ = environment(length, rng)
    out: dict[str, dict[str, Estimate]] = {}
    for arch in ARCHETYPES:
        ref = build_reference(arch, env, random.Random(rng.getrandbits(64)))  # nosec B311 - simulation, not security
        out[arch.name] = {
            "W": estimate_W(ref, env, block=block, offsets=offsets, seed=seed),
            "M_star": estimate_M_star(ref, env, block=block, offsets=offsets, seed=seed),
            "M_raw": estimate_M_star(ref, None, block=block, offsets=offsets, seed=seed),
        }
    return out
