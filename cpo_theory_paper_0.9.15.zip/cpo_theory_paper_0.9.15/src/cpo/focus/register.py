"""Register-level formalism of *A model for consciousness from binary sequences* (Stojkovic, 2026).

Everything in this module operates on binary sequences represented as Python
``int`` bit-masks of a declared length ``n`` (bit ``i`` is position ``i``).  The
functions implement, verbatim, the objects the paper proves theorems about:

* the flip map ``d(u)_i = u_i xor u_{i+1}``  (Lemma: group homomorphism with
  kernel {0^n, 1^n});
* ``order(u) = 1 - wt(d(u)) / (n-1)``;
* resonance as Hamming distance in the flip domain (Theorem "Resonance is
  exactly a Hamming filter");
* the affine selection law ``E[order(p)] = tau + (1 - 2 tau) order(s0)``;
* the focus map  F: s0 -> consensus{ top-phi patterns by resonance }  with
  majority-vote consensus, ties retaining the previous bit;
* iteration to a fixed point or a limit cycle, and classification of terminal
  states as veridical / non-motif exactly as Appendix "Reproducibility"
  prescribes (complement equivalence included).

Nothing here is a consciousness measurement.  These are the computations the
paper tags [computed], reimplemented so that their outputs can be checked.
"""

from __future__ import annotations

import math
import random
from collections.abc import Iterable, Sequence
from dataclasses import dataclass, field


# --------------------------------------------------------------------------- #
# Basic sequence operations
# --------------------------------------------------------------------------- #
def mask(n: int) -> int:
    if n < 2:
        raise ValueError("register length must be at least 2")
    return (1 << n) - 1


def weight(u: int) -> int:
    """Hamming weight."""
    return u.bit_count()


def hamming(u: int, v: int) -> int:
    return weight(u ^ v)


def flips(u: int, n: int) -> int:
    """Discrete derivative d(u) in Z_2^{n-1}: bit i is u_i xor u_{i+1}."""
    return (u ^ (u >> 1)) & mask(n - 1) if n > 2 else (u ^ (u >> 1)) & 1


def order(u: int, n: int) -> float:
    """order(u) = 1 - wt(d(u))/(n-1).  1 for constant sequences, ~0.5 for noise."""
    return 1.0 - weight(flips(u, n)) / (n - 1)


def resonance_distance(s0: int, p: int, n: int) -> int:
    """Hamming distance between d(s0) and d(p): the paper's resonance score.

    Lower is more resonant.  By the Hamming theorem this equals
    (1 - order(s0 xor p)) * (n - 1).
    """
    return hamming(flips(s0, n), flips(p, n))


def resonance(s0: int, p: int, n: int) -> float:
    """rho(s0, p) = order(s0 xor p) in [0, 1]; 1 means the difference is constant."""
    return 1.0 - resonance_distance(s0, p, n) / (n - 1)


def complement(u: int, n: int) -> int:
    return u ^ mask(n)


def selection_law_expectation(tau: float, order_s0: float) -> float:
    """Corollary (selection law): E[order(p)] over patterns at fractional flip-domain
    distance tau from s0 is tau + (1 - 2 tau) * order(s0)."""
    if not 0.0 <= tau <= 1.0:
        raise ValueError("tau must lie in [0, 1]")
    return tau + (1.0 - 2.0 * tau) * order_s0


def to_bits(u: int, n: int) -> str:
    return format(u & mask(n), f"0{n}b")


def from_bits(bits: str) -> int:
    if not bits or any(b not in "01" for b in bits):
        raise ValueError("bit string must be non-empty and contain only 0/1")
    return int(bits, 2)


def periodic(block: str, n: int) -> int:
    """Repeat ``block`` to length n, e.g. periodic('0011', 24) is the paper's m2."""
    if n % len(block):
        raise ValueError("block length must divide n")
    return from_bits(block * (n // len(block)))


def step_motif(n: int) -> int:
    """The paper's m1 = 0^{n/2} 1^{n/2}."""
    if n % 2:
        raise ValueError("n must be even for the step motif")
    return from_bits("0" * (n // 2) + "1" * (n // 2))


# --------------------------------------------------------------------------- #
# Pool construction (Appendix: Reproducibility, item 1)
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class PoolSpec:
    n: int = 24
    size: int = 20_000
    motif_fraction: float = 0.15  # mu
    corruption: float = 0.20  # eta
    motifs: tuple[int, ...] | None = None

    def resolved_motifs(self) -> tuple[int, ...]:
        if self.motifs is not None:
            return self.motifs
        return (step_motif(self.n), periodic("0011", self.n))


def make_pool(spec: PoolSpec, seed: int) -> list[int]:
    """Draw the pool once: (1-mu) i.i.d. uniform, mu split evenly between the motifs,
    each realisation flipping every bit independently with probability eta."""
    rng = random.Random(seed)  # nosec B311 - simulation, not security
    n, m = spec.n, mask(spec.n)
    motifs = spec.resolved_motifs()
    motif_count = round(spec.motif_fraction * spec.size)
    pool: list[int] = [rng.getrandbits(n) & m for _ in range(spec.size - motif_count)]
    for i in range(motif_count):
        base = motifs[i % len(motifs)]
        noise = 0
        for bit in range(n):
            if rng.random() < spec.corruption:
                noise |= 1 << bit
        pool.append(base ^ noise)
    rng.shuffle(pool)
    return pool


# --------------------------------------------------------------------------- #
# The focus map
# --------------------------------------------------------------------------- #
def select(
    reference: int, pool: Sequence[int], n: int, phi: float, pool_flips: Sequence[int] | None = None
) -> list[int]:
    """Keep the ceil(phi*N) most resonant patterns; ties at the boundary broken by
    pool index (Appendix: Reproducibility, item 2).  ``pool_flips`` may carry the
    precomputed flip maps of the pool to avoid recomputing them every iteration."""
    if not 0.0 < phi <= 1.0:
        raise ValueError("phi must lie in (0, 1]")
    if not pool:
        return []
    k = max(1, min(len(pool), math.ceil(len(pool) * phi - 1e-12)))
    d_ref = flips(reference, n)
    pf = pool_flips if pool_flips is not None else [flips(p, n) for p in pool]
    scored = sorted(range(len(pool)), key=lambda i: (weight(d_ref ^ pf[i]), i))
    return [pool[i] for i in scored[:k]]


def consensus(selected: Sequence[int], previous: int, n: int) -> int:
    """Position-wise majority vote; an exact tie retains the previous bit
    (Appendix: Reproducibility, item 3)."""
    if not selected:
        return previous
    counts = [0] * n
    for p in selected:
        while p:
            low = p & -p
            counts[low.bit_length() - 1] += 1
            p ^= low
    out = 0
    half = len(selected) / 2.0
    for bit in range(n):
        if counts[bit] > half or (counts[bit] == half and (previous >> bit) & 1):
            out |= 1 << bit
    return out


def focus_map(
    reference: int, pool: Sequence[int], n: int, phi: float, pool_flips: Sequence[int] | None = None
) -> int:
    """One application of F: resonate, select, form consensus."""
    return consensus(select(reference, pool, n, phi, pool_flips), reference, n)


@dataclass
class FocusRun:
    terminal: int
    kind: str  # "fixed_point" | "cycle" | "budget_exhausted"
    iterations: int
    period: int
    trajectory: list[int] = field(default_factory=list)

    def orders(self, n: int) -> list[float]:
        return [order(s, n) for s in self.trajectory]


def iterate(reference: int, pool: Sequence[int], n: int, phi: float = 0.10, t_max: int = 200) -> FocusRun:
    """Iterate F until a state repeats or t_max elapses (Appendix item 4).

    A repeat with period one is a fixed point; a longer repeat is a cycle.  The
    trajectory records every visited reference, starting with the seed.
    """
    seen: dict[int, int] = {reference: 0}
    trajectory = [reference]
    current = reference
    pool_flips = [flips(p, n) for p in pool]
    for t in range(1, t_max + 1):
        current = focus_map(current, pool, n, phi, pool_flips)
        trajectory.append(current)
        if current in seen:
            period = t - seen[current]
            kind = "fixed_point" if period == 1 else "cycle"
            return FocusRun(terminal=current, kind=kind, iterations=t, period=period, trajectory=trajectory)
        seen[current] = t
    return FocusRun(
        terminal=current, kind="budget_exhausted", iterations=t_max, period=0, trajectory=trajectory
    )


# --------------------------------------------------------------------------- #
# Classification (Appendix item 5) and chimeras
# --------------------------------------------------------------------------- #
def motif_distance(state: int, motifs: Iterable[int], n: int) -> tuple[int, int | None]:
    """min over motifs m of min(dH(s, m), dH(s, complement(m))) and the arg-min index."""
    best, arg = n + 1, None
    for i, m in enumerate(motifs):
        d = min(hamming(state, m), hamming(state, complement(m, n)))
        if d < best:
            best, arg = d, i
    return best, arg


def classify(run: FocusRun, motifs: Sequence[int], n: int, theta: int = 3) -> str:
    """'cycle' | 'budget_exhausted' | 'veridical:<i>' | 'non_motif'.

    Cycles are reported separately and never counted as non-motif (Appendix item 5).
    """
    if run.kind != "fixed_point":
        return run.kind
    d, i = motif_distance(run.terminal, motifs, n)
    return f"veridical:{i}" if d <= theta else "non_motif"


def chimeras(motif_a: int, motif_b: int, n: int) -> list[int]:
    """All sequences obtained by splicing a contiguous block of one motif into the
    other, together with their complements (the paper counts 268 at n=24)."""
    out: set[int] = set()
    for lo in range(n):
        for hi in range(lo + 1, n + 1):
            block = ((1 << (hi - lo)) - 1) << lo
            out.add((motif_a & ~block) | (motif_b & block))
            out.add((motif_b & ~block) | (motif_a & block))
    out |= {complement(c, n) for c in list(out)}
    return sorted(out)


def nearest_chimera_distance(state: int, chims: Sequence[int]) -> int:
    return min(hamming(state, c) for c in chims) if chims else -1
