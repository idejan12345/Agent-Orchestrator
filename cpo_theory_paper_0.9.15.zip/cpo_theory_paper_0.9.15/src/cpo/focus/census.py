"""Census of the focus map's attractors (theory paper, Appendix B; the source model's census).

Reports, for a pool specification, how often random initial references end at a
veridical fixed point, a non-motif fixed point, a cycle, or exhaust the budget;
with exact (Clopper-Pearson) binomial intervals and the spread across independent
seed streams, as the paper's reproducibility appendix requires.
"""

from __future__ import annotations

import math
import random
import statistics
from dataclasses import asdict, dataclass, field
from typing import Any

from .register import (
    PoolSpec,
    chimeras,
    classify,
    hamming,
    iterate,
    make_pool,
    motif_distance,
    nearest_chimera_distance,
    order,
)


def _beta_ppf(q: float, a: float, b: float) -> float:
    """Inverse regularised incomplete beta via bisection (stdlib only)."""
    lo, hi = 0.0, 1.0
    for _ in range(200):
        mid = (lo + hi) / 2
        if _beta_cdf(mid, a, b) < q:
            lo = mid
        else:
            hi = mid
    return (lo + hi) / 2


def _beta_cdf(x: float, a: float, b: float) -> float:
    if x <= 0:
        return 0.0
    if x >= 1:
        return 1.0
    # continued fraction for the regularised incomplete beta (Numerical Recipes betacf)
    lbeta = math.lgamma(a + b) - math.lgamma(a) - math.lgamma(b)
    front = math.exp(lbeta + a * math.log(x) + b * math.log(1 - x))
    if x < (a + 1) / (a + b + 2):
        return front * _betacf(x, a, b) / a
    return 1 - front * _betacf(1 - x, b, a) / b


def _betacf(x: float, a: float, b: float) -> float:
    tiny = 1e-300
    qab, qap, qam = a + b, a + 1, a - 1
    c, d = 1.0, 1 - qab * x / qap
    d = 1 / (d if abs(d) > tiny else tiny)
    h = d
    for m in range(1, 300):
        m2 = 2 * m
        aa = m * (b - m) * x / ((qam + m2) * (a + m2))
        d = 1 + aa * d
        d = 1 / (d if abs(d) > tiny else tiny)
        c = 1 + aa / (c if abs(c) > tiny else tiny)
        h *= d * c
        aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2))
        d = 1 + aa * d
        d = 1 / (d if abs(d) > tiny else tiny)
        c = 1 + aa / (c if abs(c) > tiny else tiny)
        delta = d * c
        h *= delta
        if abs(delta - 1) < 1e-12:
            break
    return h


def exact_binomial_interval(successes: int, trials: int, confidence: float = 0.95) -> tuple[float, float]:
    """Clopper-Pearson interval."""
    if trials <= 0:
        return (0.0, 1.0)
    alpha = 1 - confidence
    lo = 0.0 if successes == 0 else _beta_ppf(alpha / 2, successes, trials - successes + 1)
    hi = 1.0 if successes == trials else _beta_ppf(1 - alpha / 2, successes + 1, trials - successes)
    return (lo, hi)


@dataclass
class SeedCensus:
    seed: int
    runs: int
    counts: dict[str, int]
    fixed_point_rate: float
    non_motif_rate: float
    non_motif_interval: tuple[float, float]
    mean_iterations_to_settle: float | None
    non_motif_orders: list[float]
    non_motif_mean_pairwise_hamming: float | None
    non_motif_mean_distance_to_nearer_motif: float | None
    non_motif_mean_distance_to_nearest_chimera: float | None
    random_mean_distance_to_nearer_motif: float
    random_mean_distance_to_nearest_chimera: float


@dataclass
class CensusReport:
    spec: dict[str, Any]
    phi: float
    theta: int
    t_max: int
    seeds: list[SeedCensus] = field(default_factory=list)

    @property
    def pooled_non_motif_rate(self) -> float:
        total = sum(s.runs for s in self.seeds)
        return sum(s.counts.get("non_motif", 0) for s in self.seeds) / total if total else 0.0

    def summary(self) -> dict[str, Any]:
        rates = [s.non_motif_rate for s in self.seeds]
        fp = [s.fixed_point_rate for s in self.seeds]
        total = sum(s.runs for s in self.seeds)
        nm = sum(s.counts.get("non_motif", 0) for s in self.seeds)
        return {
            "runs_total": total,
            "pooled_non_motif_rate": self.pooled_non_motif_rate,
            "pooled_non_motif_exact_95ci": exact_binomial_interval(nm, total),
            "across_seed_non_motif_min_max": (min(rates), max(rates)) if rates else None,
            "fixed_point_rate_min_max": (min(fp), max(fp)) if fp else None,
            "counts_by_seed": {s.seed: s.counts for s in self.seeds},
            "note": (
                "Rates are parameter-relative and classification-rule-relative; "
                "what replicates robustly is the existence of non-motif fixed points "
                "and their chimera structure, not their frequency to the digit."
            ),
        }

    def to_dict(self) -> dict[str, Any]:
        return {
            "spec": self.spec,
            "phi": self.phi,
            "theta": self.theta,
            "t_max": self.t_max,
            "seeds": [asdict(s) for s in self.seeds],
            "summary": self.summary(),
        }


def run_census(
    spec: PoolSpec | None = None,
    *,
    runs: int = 200,
    phi: float = 0.10,
    theta: int = 3,
    t_max: int = 200,
    seeds: tuple[int, ...] = (1, 2, 3),
    random_baseline: int = 500,
) -> CensusReport:
    spec = spec or PoolSpec()
    n = spec.n
    motifs = spec.resolved_motifs()
    chims = chimeras(motifs[0], motifs[1], n) if len(motifs) >= 2 else []
    report = CensusReport(
        spec=asdict(spec) | {"motifs": [format(m, f"0{n}b") for m in motifs]},
        phi=phi,
        theta=theta,
        t_max=t_max,
    )
    for seed in seeds:
        pool = make_pool(spec, seed)
        rng = random.Random(seed * 7919 + 17)  # nosec B311 - simulation, not security
        counts: dict[str, int] = {}
        settle: list[int] = []
        non_motif: list[int] = []
        for _ in range(runs):
            s0 = rng.getrandbits(n)
            run = iterate(s0, pool, n, phi, t_max)
            label = classify(run, motifs, n, theta)
            counts[label] = counts.get(label, 0) + 1
            if run.kind == "fixed_point":
                settle.append(run.iterations - 1)  # iterations until the state stopped changing
                if label == "non_motif":
                    non_motif.append(run.terminal)
        fixed = sum(v for k, v in counts.items() if k.startswith("veridical") or k == "non_motif")
        nm = counts.get("non_motif", 0)
        pairwise = (
            [hamming(a, b) for i, a in enumerate(non_motif) for b in non_motif[i + 1 :]]
            if len(non_motif) > 1
            else []
        )
        randoms = [rng.getrandbits(n) for _ in range(random_baseline)]
        report.seeds.append(
            SeedCensus(
                seed=seed,
                runs=runs,
                counts=dict(sorted(counts.items())),
                fixed_point_rate=fixed / runs,
                non_motif_rate=nm / runs,
                non_motif_interval=exact_binomial_interval(nm, runs),
                mean_iterations_to_settle=statistics.fmean(settle) if settle else None,
                non_motif_orders=[round(order(s, n), 3) for s in non_motif],
                non_motif_mean_pairwise_hamming=statistics.fmean(pairwise) if pairwise else None,
                non_motif_mean_distance_to_nearer_motif=(
                    statistics.fmean(motif_distance(s, motifs, n)[0] for s in non_motif)
                    if non_motif
                    else None
                ),
                non_motif_mean_distance_to_nearest_chimera=(
                    statistics.fmean(nearest_chimera_distance(s, chims) for s in non_motif)
                    if non_motif and chims
                    else None
                ),
                random_mean_distance_to_nearer_motif=statistics.fmean(
                    motif_distance(s, motifs, n)[0] for s in randoms
                ),
                random_mean_distance_to_nearest_chimera=(
                    statistics.fmean(nearest_chimera_distance(s, chims) for s in randoms) if chims else -1.0
                ),
            )
        )
    return report
