"""Controlled experiments of the theory paper (paper/theory).  Deterministic; writes paper/theory/experiments.json.

E1  Selection-only erosion vs. full focus map (register level; paper table "Order of the reference").
E2  Noise voting: fraction of noisy specialists vs. convergence and noise admission.
E3  Reconfirmation discrimination: veridical vs. history-locked pools.
E4  Occupancy cap: pool size vs. selection cap and cycles to fixed point.
E5  Spurious rate vs. register size and motif density (paper Appendix B, scaling table).
E6  Spurious rate and convergence vs. selection breadth phi (paper section 6.3).
E7  Proposition 1 tested directly: pool accuracy p, selected-set accuracy p_sel, and plurality
    accuracy over the whole pool, the selected set and a random set of the same size, with the
    informativeness of the reference controlled (uninformative / partially correct / wrong).
E8  Binding-proxy ablation: E2b, E3 (eps=0.06) and E4 rerun with binding_exponent=0.
"""

from __future__ import annotations

import asyncio
import json
import random
import statistics
from pathlib import Path

from cpo.config import CPOConfig
from cpo.consumers import TextConsumer
from cpo.focus import (
    PoolSpec,
    consensus,
    flips,
    make_pool,
    order,
    run_census,
    select,
)
from cpo.models import Candidate, OrchestrationRequest
from cpo.orchestrator import Orchestrator
from cpo.specialists import EchoSpecialist, NoisySpecialist

OUT = Path("paper/theory/experiments.json")
OUT.parent.mkdir(exist_ok=True)
N = 24
REQ = "Summarize the quarterly incident review and propose two mitigations for the payments outage."


def e1_erosion(seeds=(1, 2, 3), runs=100, steps=6):
    """Selection-only: new reference = a uniformly drawn *selected* pattern (no vote).
    Full map: majority consensus.  Report mean excess order 2*(order-1/2) per step."""
    out = {"selection_only": [], "consensus": []}
    for seed in seeds:
        pool = make_pool(PoolSpec(size=4000), seed)
        pf = [flips(p, N) for p in pool]
        rng = random.Random(seed)
        motif_seed = PoolSpec().resolved_motifs()[0]
        for _ in range(runs):
            # start from an ordered reference (the motif with 3 flips) so erosion is visible
            s = motif_seed
            for b in rng.sample(range(N), 3):
                s ^= 1 << b
            so, co = s, s
            traj_s, traj_c = [order(so, N)], [order(co, N)]
            for _ in range(steps):
                sel = select(so, pool, N, 0.10, pf)
                so = rng.choice(sel)
                traj_s.append(order(so, N))
                co = consensus(select(co, pool, N, 0.10, pf), co, N)
                traj_c.append(order(co, N))
            out["selection_only"].append(traj_s)
            out["consensus"].append(traj_c)
    return {
        k: [round(statistics.fmean(t[i] for t in v), 4) for i in range(steps + 1)] for k, v in out.items()
    }


async def e2_noise(fractions=(0, 1, 2, 3, 4, 5), echo=3, reps=5):
    rows = []
    for k in fractions:
        cycles, noise_selected, fixed = [], 0, 0
        for r in range(reps):
            specs = [EchoSpecialist(f"e{i}", f"Role{i}") for i in range(echo)] + [
                NoisySpecialist(f"n{j}", seed=100 * r + j) for j in range(k)
            ]
            o = Orchestrator(specs, [TextConsumer()], config=CPOConfig(max_cycles=8))
            res = await o.run(OrchestrationRequest(input=REQ))
            cycles.append(len(res.cycles))
            fixed += res.workspace.terminal_kind == "fixed_point"
            noise_selected += sum(any(s.startswith("n") for s in t.selected_sources) for t in res.cycles)
        rows.append(
            {
                "noisy": k,
                "echo": echo,
                "reps": reps,
                "fixed_point_rate": fixed / reps,
                "mean_cycles": statistics.fmean(cycles),
                "cycles_with_noise_selected": noise_selected,
                "total_cycles": sum(cycles),
            }
        )
    return rows


async def e2b_phi_sweep(phis=(0.10, 0.25, 0.50, 0.75), noisy=(0, 1, 2, 3, 4, 6, 9), echo=3, reps=3, b=0.5):
    """Probability that a noisy source is selected in a cycle, as a function of selection
    breadth phi and the noisy share of the pool."""
    rows = []
    for phi in phis:
        for k in noisy:
            hit, total = 0, 0
            for r in range(reps):
                specs = [EchoSpecialist(f"e{i}", f"Role{i}") for i in range(echo)] + [
                    NoisySpecialist(f"n{j}", seed=500 * r + j) for j in range(k)
                ]
                o = Orchestrator(
                    specs, [TextConsumer()], config=CPOConfig(max_cycles=6, phi=phi, k_min=1, k_max=16, binding_exponent=b)
                )
                res = await o.run(OrchestrationRequest(input=REQ))
                total += len(res.cycles)
                hit += sum(any(src.startswith("n") for src in t.selected_sources) for t in res.cycles)
            rows.append(
                {
                    "phi": phi,
                    "noisy": k,
                    "noise_share": round(k / (echo + k), 3),
                    "cycles": total,
                    "noise_admission_rate": round(hit / total, 3),
                }
            )
    return rows


class Veridical:
    concurrency_safe = True

    def __init__(self, name, seed):
        self.name, self.rng = name, random.Random(seed)

    async def propose(self, request, workspace):
        base = f"{request.input} Root cause: connection pool exhaustion. Mitigation: pool sizing and circuit breaker."
        words = base.split()
        drop = self.rng.sample(range(len(words)), 2)
        return [
            Candidate(source=self.name, content=" ".join(w for i, w in enumerate(words) if i not in drop))
        ]

    async def receive_broadcast(self, w):
        pass


class HistoryLocked:
    concurrency_safe = True

    def __init__(self, name, seed):
        self.name, self.rng = name, random.Random(seed)

    async def propose(self, request, workspace):
        if request.context.get("_cpo_resample") or workspace is None:
            words = [self.rng.choice(NoisySpecialist._words) for _ in range(30)]
            return [Candidate(source=self.name, content=" ".join(words))]
        return [Candidate(source=self.name, content=workspace.synthesis)]

    async def receive_broadcast(self, w):
        pass


async def e3_reconfirmation(reps=30, thresholds=(0.02, 0.06, 0.10), b=0.5):
    rows = []
    for thr in thresholds:
        for label, cls in (("veridical", Veridical), ("history_locked", HistoryLocked)):
            statuses, terminals, recomb = {}, {}, 0
            strict, blind_d = {}, []
            for r in range(reps):
                specs = [cls(f"s{i}", seed=1000 * r + i) for i in range(3)]
                o = Orchestrator(
                    specs,
                    [TextConsumer()],
                    config=CPOConfig(
                        max_cycles=8, reconfirmation_rounds=2, fixed_point_threshold=thr, binding_exponent=b
                    ),
                )
                res = await o.run(OrchestrationRequest(input=REQ))
                st = res.reconfirmation.status if res.reconfirmation else "none"
                statuses[st] = statuses.get(st, 0) + 1
                terminals[res.workspace.terminal_kind] = terminals.get(res.workspace.terminal_kind, 0) + 1
                recomb += bool(res.reconfirmation and res.reconfirmation.recombination_signature)
                # strict verdict (shipped as ReconfirmationReport.strict_status): the tie-retaining
                # test AND the unbiased blind-consensus distance within theta
                rc = res.reconfirmation
                key = (rc.strict_status or rc.status) if rc is not None else "none"
                strict[key] = strict.get(key, 0) + 1
                if rc is not None and rc.blind_consensus_distance is not None:
                    blind_d.append(round(rc.blind_consensus_distance, 4))
            rows.append(
                {
                    "threshold": thr,
                    "pool": label,
                    "reps": reps,
                    "statuses": statuses,
                    "terminals": terminals,
                    "recombination_flagged": recomb,
                    "strict_statuses": strict,
                    "blind_consensus_distance": {
                        "min": min(blind_d) if blind_d else None,
                        "max": max(blind_d) if blind_d else None,
                    },
                }
            )
    return rows


async def e4_occupancy(sizes=(2, 4, 6, 8, 12, 16, 20), b=0.5):
    rows = []
    for m in sizes:
        specs = [EchoSpecialist(f"e{i}", f"Role{i}") for i in range(m)]
        for ctl in (True, False):
            o = Orchestrator(
                specs,
                [TextConsumer()],
                config=CPOConfig(max_cycles=8, k_max=16, occupancy_control_enabled=ctl, binding_exponent=b),
            )
            res = await o.run(OrchestrationRequest(input=REQ))
            rows.append(
                {
                    "specialists": m,
                    "occupancy_control": ctl,
                    "selection_cap": res.cycles[0].occupancy.selection_cap,
                    "selected": len(res.cycles[0].selected_sources),
                    "cycles": len(res.cycles),
                    "terminal": res.workspace.terminal_kind,
                    "regime": res.cycles[0].occupancy.regime,
                }
            )
    return rows


def e5_scaling():
    rows = []
    for n in (12, 16, 24, 32):
        rep = run_census(
            PoolSpec(n=n, size=6000), runs=100, seeds=(1, 2), random_baseline=50, theta=max(1, n // 8)
        )
        s = rep.summary()
        rows.append(
            {
                "n": n,
                "motif_fraction": 0.15,
                "non_motif_rate": s["pooled_non_motif_rate"],
                "ci": s["pooled_non_motif_exact_95ci"],
                "fixed_point_rate": s["fixed_point_rate_min_max"],
            }
        )
    for mu in (0.02, 0.05, 0.15, 0.30):
        rep = run_census(
            PoolSpec(n=24, size=6000, motif_fraction=mu), runs=100, seeds=(1, 2), random_baseline=50
        )
        s = rep.summary()
        rows.append(
            {
                "n": 24,
                "motif_fraction": mu,
                "non_motif_rate": s["pooled_non_motif_rate"],
                "ci": s["pooled_non_motif_exact_95ci"],
                "fixed_point_rate": s["fixed_point_rate_min_max"],
            }
        )
    return rows


def e6_phi_veridicality(phis=(0.02, 0.05, 0.10, 0.15, 0.25, 0.40, 0.60, 0.80)):
    """Does widening the focus reduce non-veridical (spurious) fixed points?

    The register-level counterpart of the question the text-level phi sweep (E2b) asks about
    noise admission.  Same pool and run count as E5 so the two are comparable.
    """
    rows = []
    for phi in phis:
        rep = run_census(
            PoolSpec(n=24, size=6000, motif_fraction=0.15, corruption=0.20),
            runs=100,
            seeds=(1, 2),
            phi=phi,
            theta=3,
        )
        s = rep.summary()
        counts = s["counts_by_seed"]
        rows.append(
            {
                "phi": phi,
                "non_motif_rate": s["pooled_non_motif_rate"],
                "ci": s["pooled_non_motif_exact_95ci"],
                "fixed_point_rate": s["fixed_point_rate_min_max"],
                "cycles": sum(c.get("cycle", 0) for c in counts.values()),
                "counts_by_seed": counts,
            }
        )
    return rows


def _plurality(answers, rng):
    counts = {}
    for a in answers:
        counts[a] = counts.get(a, 0) + 1
    top = max(counts.values())
    return rng.choice(sorted(a for a, c in counts.items() if c == top))


def e7_selection_informativeness(
    ps=(0.35, 0.50, 0.65), deltas=(0.0, 0.25, 0.40, 0.50), trials=4000, n=24, wrong=3, pool=12, k=6, eta=0.10
):
    """Proposition 1 on synthetic pools.  Each candidate carries an answer (0 = correct, 1..wrong =
    one of the wrong answers, uniformly) and a register signature: its answer's code with each bit
    flipped with probability eta.  Selection keeps the k candidates nearest the reference in
    Hamming distance (ties by index); the decision rule is plurality over answers, ties at random.
    The reference is the correct code, or a wrong code, with a fraction delta of its bits flipped;
    or a fresh random string (uninformative).  delta = 0.5 makes any code reference uninformative."""
    def flip(code, frac, rng):
        idx = rng.sample(range(n), round(frac * n))
        return [b ^ 1 if i in idx else b for i, b in enumerate(code)]

    def cell(p, ref_kind, delta, seed):
        rng = random.Random(seed)
        acc = {"full": 0, "selected": 0, "random_k": 0}
        n_corr = n_sel_corr = 0
        for _ in range(trials):
            codes = [[rng.randint(0, 1) for _ in range(n)] for _ in range(wrong + 1)]
            ans = [0 if rng.random() < p else rng.randint(1, wrong) for _ in range(pool)]
            sigs = [[b ^ (rng.random() < eta) for b in codes[a]] for a in ans]
            if ref_kind == "random":
                ref = [rng.randint(0, 1) for _ in range(n)]
            else:
                ref = flip(codes[0 if ref_kind == "correct" else 1], delta, rng)
            dist = [sum(x != y for x, y in zip(sg, ref)) for sg in sigs]
            sel = sorted(range(pool), key=lambda i: (dist[i], i))[:k]
            rnd = rng.sample(range(pool), k)
            n_corr += sum(a == 0 for a in ans)
            n_sel_corr += sum(ans[i] == 0 for i in sel)
            acc["full"] += _plurality(ans, rng) == 0
            acc["selected"] += _plurality([ans[i] for i in sel], rng) == 0
            acc["random_k"] += _plurality([ans[i] for i in rnd], rng) == 0
        return {
            "p": round(n_corr / (trials * pool), 4),
            "p_sel": round(n_sel_corr / (trials * k), 4),
            **{f"acc_{key}": round(v / trials, 4) for key, v in acc.items()},
        }

    conditions = (("uninformative", "random", None), ("partially correct", "correct", 0.25), ("wrong incumbent", "wrong", 0.25))
    table = []
    for ci, (label, kind, delta) in enumerate(conditions):
        for pi, p in enumerate(ps):
            table.append({"reference": label, "p_target": p, **cell(p, kind, delta or 0.0, 7000 + 100 * ci + pi)})
    sweep = []
    for di, delta in enumerate(deltas):
        sweep.append({"delta": delta, "p_target": 0.5, **cell(0.5, "correct", delta, 8000 + di)})
    return {
        "params": {"n": n, "wrong_answers": wrong, "pool": pool, "k": k, "eta": eta, "trials": trials},
        "table": table,
        "delta_sweep": sweep,
    }


async def e8_binding_ablation():
    """E2b, E3 at eps = 0.06, and E4 with the binding proxy switched off (b = 0)."""
    return {
        "E2b_phi_sweep": await e2b_phi_sweep(b=0.0),
        "E3_reconfirmation": await e3_reconfirmation(thresholds=(0.06,), b=0.0),
        "E4_occupancy": await e4_occupancy(b=0.0),
    }


async def main():
    results = {
        "E1_erosion": e1_erosion(),
        "E2_noise": await e2_noise(),
        "E2b_phi_sweep": await e2b_phi_sweep(),
        "E3_reconfirmation": await e3_reconfirmation(),
        "E4_occupancy": await e4_occupancy(),
        "E5_scaling": e5_scaling(),
        "E6_phi_veridicality": e6_phi_veridicality(),
        "E7_selection_informativeness": e7_selection_informativeness(),
        "E8_binding_ablation": await e8_binding_ablation(),
    }
    OUT.write_text(json.dumps(results, indent=2))
    print(json.dumps(results, indent=1))


asyncio.run(main())
