"""Figures for the theory paper, from paper/theory/experiments.json and the capacity theorem."""

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

from cpo.focus.capacity import holdable_alternatives

# Embed TrueType (Type 42), not Type 3, so figure text is vector and extractable.
plt.rcParams["pdf.fonttype"] = 42
plt.rcParams["ps.fonttype"] = 42

data = json.loads(Path("paper/theory/experiments.json").read_text(encoding="utf-8"))
out = Path("paper/theory/figures")
out.mkdir(exist_ok=True)

# Figure 1: erosion vs consensus
e1 = data["E1_erosion"]
fig, ax = plt.subplots(figsize=(4.6, 3.0))
steps = range(len(e1["consensus"]))
ax.plot(steps, [2 * (o - 0.5) for o in e1["selection_only"]], "o-", color="#b34a3a", label="selection only")
ax.plot(steps, [2 * (o - 0.5) for o in e1["consensus"]], "s-", color="#2b5f8a", label="select + consensus")
ax.axhline(0, color="gray", lw=0.6)
ax.set_xlabel("iteration")
ax.set_ylabel("excess order  2(ord $-$ 1/2)")
ax.set_ylim(-0.05, 1.0)
ax.legend(frameon=False, fontsize=8)
fig.tight_layout()
fig.savefig(out / "erosion.pdf")

# Figure 2: the tent and the observed caps
e4 = data["E4_occupancy"]
n = 24
fig, ax = plt.subplots(figsize=(4.6, 3.0))
xs = list(range(0, n + 1))
ax.plot(
    xs, [holdable_alternatives(n, x) for x in xs], color="#2b5f8a", label=r"$1+\frac{n}{2}\min(\nu,1-\nu)$"
)
on = [(r["specialists"], r["selection_cap"]) for r in e4 if r["occupancy_control"]]
off = [(r["specialists"], r["selected"]) for r in e4 if not r["occupancy_control"]]
ax.plot([a for a, _ in on], [b for _, b in on], "s", color="#2b5f8a", label="selection cap (controller on)")
ax.plot(
    [a for a, _ in off],
    [b for _, b in off],
    "o",
    mfc="none",
    color="#b34a3a",
    label=r"$\lceil\varphi N\rceil$ (controller off)",
)
ax.set_xlabel("first-cycle occupancy  $N$ = pool size")
ax.set_ylabel("alternatives")
ax.set_xlim(0, n)
ax.legend(frameon=False, fontsize=7.5, loc="upper left")
fig.tight_layout()
fig.savefig(out / "tent.pdf")

# Figure 3: scaling of non-motif rate with n
e5 = [r for r in data["E5_scaling"] if r["motif_fraction"] == 0.15]
fig, ax = plt.subplots(figsize=(4.6, 3.0))
ns = [r["n"] for r in e5]
rates = [r["non_motif_rate"] for r in e5]
lo = [r["non_motif_rate"] - r["ci"][0] for r in e5]
hi = [r["ci"][1] - r["non_motif_rate"] for r in e5]
ax.errorbar(ns, rates, yerr=[lo, hi], fmt="o-", color="#2b5f8a", capsize=3)
ax.set_xlabel("register size $n$")
ax.set_ylabel("non-motif fixed-point rate")
ax.set_ylim(0, 0.4)
fig.tight_layout()
fig.savefig(out / "scaling.pdf")
print("figures written")
