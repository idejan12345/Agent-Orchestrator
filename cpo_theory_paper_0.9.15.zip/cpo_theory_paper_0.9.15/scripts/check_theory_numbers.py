"""Check that the theory paper's experiment tables print the numbers in its data.

Recomputes from paper/theory/experiments.json (written by scripts/paper_experiments.py, fixed
seeds) every value in the tables of the controlled-experiments section of
paper/theory/cpo_theory.tex and compares it with the printed value at the printed precision:

  * tab:erosion    <- E1_erosion          (mean order per step, two rules)
  * tab:phi        <- E2b_phi_sweep       (noise admission by phi and noise share)
  * tab:reconf     <- E3_reconfirmation   (fixed points and verdicts by tolerance and pool)
  * tab:occupancy  <- E4_occupancy        (first-cycle cap and number selected, controller on/off)
  * tab:breadth    <- E6_phi_veridicality (spurious rate and limit cycles by phi)
  * tab:scaling    <- E5_scaling          (non-motif counts and rates by n and motif density)
  * tab:prop1      <- E7_selection_informativeness.table       (Proposition 1, three references)
  * tab:delta      <- E7_selection_informativeness.delta_sweep (informativeness swept)
  * the binding-ablation claim: E8 reproduces E2b, E3 (eps=0.06, both verdicts) and E4 exactly

plus the version string and the test count quoted in the implementation appendix. The count is of
the tests that ship with the theory paper (everything but tests/test_eval.py, which covers the
evaluation harness and ships with the evaluation paper).

    python scripts/check_theory_numbers.py      # exit 0 = every checked number matches
"""

from __future__ import annotations

import json
import re
import subprocess  # nosec B404 - fixed argv, no shell
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TEX = ROOT / "paper" / "theory" / "cpo_theory.tex"
DATA = ROOT / "paper" / "theory" / "experiments.json"
EVIDENCE = ROOT / "release" / "evidence" / "theory_numbers.json"
_NUM = re.compile(r"-?\d+(?:\.\d+)?")


def table_rows(tex: str, label: str) -> list[list[str]]:
    lab = tex.index(f"\\label{{{label}}}")
    # the tabular inside the same table environment, whether the caption sits above or below it
    env = tex.rindex("\\begin{table}", 0, lab)
    env_end = tex.index("\\end{table}", lab)
    start = tex.index("\\begin{tabular}", env, env_end)
    body = tex[start : tex.index("\\end{tabular}", start)]
    body = body[body.index("\n") :]  # drop the \begin{tabular}{...} column spec
    body = re.sub(r"\\(toprule|midrule|bottomrule)\b", "", body)
    return [[c.strip() for c in row.split("&")] for row in body.split("\\\\")]


def nums(cell: str) -> list[float]:
    return [float(x) for x in _NUM.findall(cell.replace("{", " ").replace("}", " "))]


def check_tables(tex: str, d: dict) -> tuple[int, list[str], dict[str, int]]:
    """Compare every value in the six experiment tables with the data; return (checked, problems, rows)."""
    problems: list[str] = []
    checked = 0
    seen: dict[str, int] = {}

    def same(label: str, printed: float, actual: float, places: int) -> None:
        nonlocal checked
        checked += 1
        if abs(printed - actual) > 10 ** (-places) / 2 + 1e-9:
            problems.append(f"{label}: paper prints {printed}, data gives {actual}")

    def places_of(cell: str) -> int:
        m = re.search(r"\d+\.(\d+)", cell)
        return len(m.group(1)) if m else 0

    # tab:erosion
    for row in table_rows(tex, "tab:erosion"):
        key = (
            "selection_only"
            if row[0].startswith("selection only")
            else "consensus"
            if row[0].startswith("full map")
            else None
        )
        if not key:
            continue
        seen["erosion"] = seen.get("erosion", 0) + 1
        for i, cell in enumerate(row[1:]):
            same(f"erosion {key} step {i}", nums(cell)[0], d["E1_erosion"][key][i], places_of(cell))

    # tab:phi
    noisy_cols = [0, 1, 2, 3, 4, 6, 9]
    sweep = {(r["phi"], r["noisy"]): r["noise_admission_rate"] for r in d["E2b_phi_sweep"]}
    for row in table_rows(tex, "tab:phi"):
        m = re.match(r"\$\\varphi=([\d.]+)\$", row[0])
        if not m:
            continue
        seen["phi"] = seen.get("phi", 0) + 1
        phi = float(m.group(1))
        for noisy, cell in zip(noisy_cols, row[1:]):
            same(f"phi {phi} noisy {noisy}", nums(cell)[0], sweep[(phi, noisy)], max(2, places_of(cell)))

    # tab:reconf
    rec = {(r["threshold"], r["pool"]): r for r in d["E3_reconfirmation"]}
    for row in table_rows(tex, "tab:reconf"):
        m = re.match(r"\$([\d.]+)\$", row[0])
        if not m or len(row) < 6:
            continue
        seen["reconf"] = seen.get("reconf", 0) + 1
        pool = "veridical" if row[1].startswith("supported") else "history_locked"
        r = rec[(float(m.group(1)), pool)]
        st = r["statuses"]
        tag = f"reconf {m.group(1)} {pool}"
        same(f"{tag} fixed points", nums(row[2])[0], r["terminals"].get("fixed_point", 0), 0)
        same(f"{tag} reconfirmed", nums(row[3])[0], st.get("reconfirmed", 0), 0)
        same(f"{tag} not reconfirmed", nums(row[4])[0], st.get("not_reconfirmed", 0), 0)
        same(f"{tag} untested", nums(row[5])[0], st.get("untested", 0), 0)
        same(f"{tag} strict reconfirmed", nums(row[6])[0], r["strict_statuses"].get("reconfirmed", 0), 0)

    # tab:occupancy
    occ = {(r["specialists"], r["occupancy_control"]): r for r in d["E4_occupancy"]}
    sizes = [2, 4, 6, 8, 12, 16, 20]
    for row in table_rows(tex, "tab:occupancy"):
        if row[0].startswith("cap"):
            field, ctl = "selection_cap", True
        elif row[0].startswith("selected, controller on"):
            field, ctl = "selected", True
        elif row[0].startswith("selected, controller off"):
            field, ctl = "selected", False
        else:
            continue
        seen["occupancy"] = seen.get("occupancy", 0) + 1
        for m_, cell in zip(sizes, row[1:]):
            same(f"occupancy m={m_} {field} ctl={ctl}", nums(cell)[0], occ[(m_, ctl)][field], 0)

    # tab:breadth
    br = {r["phi"]: r for r in d["E6_phi_veridicality"]}
    phis = [0.02, 0.05, 0.10, 0.15, 0.25, 0.40, 0.60, 0.80]
    for row in table_rows(tex, "tab:breadth"):
        if row[0].startswith("spurious rate"):
            seen["breadth"] = seen.get("breadth", 0) + 1
            for phi, cell in zip(phis, row[1:]):
                same(f"breadth phi={phi} spurious", nums(cell)[0], br[phi]["non_motif_rate"], places_of(cell))
        elif row[0].startswith("limit cycles"):
            seen["breadth"] = seen.get("breadth", 0) + 1
            for phi, cell in zip(phis, row[1:]):
                same(f"breadth phi={phi} cycles", nums(cell)[0], br[phi]["cycles"], 0)

    # tab:scaling (two blocks: by n at mu=0.15, by mu at n=24)
    sc = d["E5_scaling"]
    by_n = {r["n"]: r for r in sc if r["motif_fraction"] == 0.15}
    by_mu = {r["motif_fraction"]: r for r in sc if r["n"] == 24}
    block = None
    for row in table_rows(tex, "tab:scaling"):
        if row[0].startswith("$n$"):
            block, keys = by_n, [12, 16, 24, 32]
        elif row[0].startswith("$\\mu$"):
            block, keys = by_mu, [0.02, 0.05, 0.15, 0.30]
        elif block is not None and row[0].startswith("non-motif fixed points"):
            seen["scaling"] = seen.get("scaling", 0) + 1
            for k, cell in zip(keys, row[1:]):
                same(f"scaling {k} count", nums(cell)[0], round(block[k]["non_motif_rate"] * 200), 0)
        elif block is not None and row[0].startswith("rate"):
            seen["scaling"] = seen.get("scaling", 0) + 1
            for k, cell in zip(keys, row[1:]):
                same(
                    f"scaling {k} rate",
                    nums(cell)[0],
                    block[k]["non_motif_rate"],
                    places_of(cell.split("[")[0]),
                )

    # tab:prop1 and tab:delta
    e7 = d["E7_selection_informativeness"]
    cols = ["p", "p_sel", "acc_full", "acc_selected", "acc_random_k"]
    rows7 = {(r["reference"], r["p_target"]): r for r in e7["table"]}
    for row in table_rows(tex, "tab:prop1"):
        if len(row) < 7 or not row[1].startswith("$0."):
            continue
        seen["prop1"] = seen.get("prop1", 0) + 1
        r = rows7[(row[0], nums(row[1])[0])]
        for c, cell in zip(cols, row[2:]):
            same(f"prop1 {row[0]} p={row[1]} {c}", nums(cell)[0], r[c], 3)
    rowsd = {r["delta"]: r for r in e7["delta_sweep"]}
    for row in table_rows(tex, "tab:delta"):
        if len(row) < 5 or not row[0].startswith("$0."):
            continue
        seen["delta"] = seen.get("delta", 0) + 1
        r = rowsd[nums(row[0])[0]]
        for c, cell in zip(cols[1:], row[1:]):
            same(f"delta {row[0]} {c}", nums(cell)[0], r[c], 3)

    # binding ablation: the text says every outcome is identical with b = 0
    e8 = d["E8_binding_ablation"]
    checked += 1
    key2b = [(r["phi"], r["noisy"], r["noise_admission_rate"]) for r in d["E2b_phi_sweep"]]
    key4 = [
        (r["specialists"], r["occupancy_control"], r["selection_cap"], r["selected"], r["cycles"])
        for r in d["E4_occupancy"]
    ]
    base3 = [r for r in d["E3_reconfirmation"] if r["threshold"] == 0.06]
    same2b = key2b == [(r["phi"], r["noisy"], r["noise_admission_rate"]) for r in e8["E2b_phi_sweep"]]
    same4 = key4 == [
        (r["specialists"], r["occupancy_control"], r["selection_cap"], r["selected"], r["cycles"])
        for r in e8["E4_occupancy"]
    ]
    same3 = [(r["statuses"], r["strict_statuses"]) for r in base3] == [
        (r["statuses"], r["strict_statuses"]) for r in e8["E3_reconfirmation"]
    ]
    if not (same2b and same3 and same4):
        problems.append(f"binding ablation not identical: E2b {same2b}, E3 {same3}, E4 {same4}")

    expected = {
        "erosion": 2,
        "phi": 4,
        "reconf": 6,
        "occupancy": 3,
        "breadth": 2,
        "scaling": 4,
        "prop1": 9,
        "delta": 4,
    }
    for table, want in expected.items():
        if seen.get(table, 0) != want:
            problems.append(f"parsed {seen.get(table, 0)} rows of the {table} table, expected {want}")
    return checked, problems, seen


def main() -> int:
    tex = TEX.read_text(encoding="utf-8")
    d = json.loads(DATA.read_text(encoding="utf-8"))
    checked, problems, seen = check_tables(tex, d)

    # version and test count
    sys.path.insert(0, str(ROOT / "src"))
    from cpo.version import __version__

    checked += 1
    if f"cpo-orchestrator {__version__}" not in tex:
        problems.append(f"paper does not name cpo-orchestrator {__version__}")
    out = subprocess.run(  # nosec B603 - fixed argv, no shell
        [
            sys.executable,
            "-m",
            "pytest",
            "--collect-only",
            "-q",
            "-o",
            "addopts=",
            "--ignore=tests/test_eval.py",
        ],
        cwd=ROOT,
        capture_output=True,
        text=True,
        check=False,
    ).stdout
    m = re.search(r"(\d+) tests? collected", out)
    stated = re.search(r"Verification: (\d+) tests", tex)
    checked += 1
    if not (m and stated and int(m.group(1)) == int(stated.group(1))):
        problems.append(
            f"paper states {stated and stated.group(1)} tests; the suite collects {m and m.group(1)}"
        )

    report = {"checked": checked, "rows_parsed": seen, "mismatches": problems, "passed": not problems}
    EVIDENCE.parent.mkdir(parents=True, exist_ok=True)
    EVIDENCE.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(f"{checked} theory numbers checked; {len(problems)} mismatch(es)")
    for p in problems:
        print("  -", p)
    return 0 if not problems else 6


if __name__ == "__main__":
    raise SystemExit(main())
