"""Fail if a compiled manuscript has unresolved references or is stale.

A single LaTeX pass leaves every \\ref and \\cite as "??" in the PDF while the .tex is fine; such a
PDF once shipped in a release bundle, and so did a PDF left over from an earlier version when a
build failed silently. This check reads the PDF's text (pdftotext) and the LaTeX log, if present,
and exits non-zero on any "??" or "undefined" reference, or when the package version the PDF names
("cpo-orchestrator X.Y.Z") is not the package's current version.

    python scripts/check_pdf_refs.py paper/theory/cpo_theory.pdf [more.pdf ...]
"""

from __future__ import annotations

import re
import shutil
import subprocess  # nosec B404 - fixed argv, no shell
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from cpo.version import __version__  # noqa: E402


def problems(pdf: Path) -> list[str]:
    out: list[str] = []
    if not pdf.is_file():
        return [f"{pdf}: missing"]
    if shutil.which("pdftotext") is None:
        return [f"{pdf}: pdftotext not available, cannot check"]
    text = subprocess.run(  # nosec B603 B607 - fixed argv, no shell
        ["pdftotext", str(pdf), "-"], capture_output=True, text=True, check=False
    ).stdout
    if "??" in text:
        out.append(f"{pdf}: {text.count('??')} unresolved reference(s) ('??') in the PDF text")
    named = re.findall(r"cpo-orchestrator (\d+\.\d+\.\d+)", text)
    if named and named[0] != __version__:
        out.append(f"{pdf}: names cpo-orchestrator {named[0]} but the package is {__version__} (stale build)")
    log = pdf.with_suffix(".log")
    if log.is_file() and "undefined" in log.read_text(encoding="utf-8", errors="replace"):
        out.append(f"{log}: LaTeX reports undefined references")
    return out


def main(argv: list[str]) -> int:
    found = [p for a in argv for p in problems(Path(a))]
    for p in found:
        print(p)
    if not found:
        print(f"{len(argv)} PDF(s): no unresolved references")
    return 1 if found else 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
