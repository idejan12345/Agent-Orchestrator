import asyncio
import json

from cpo.tracing import HashChainJsonlSink


def run(coro):
    return asyncio.run(coro)


def test_restart_continuity_and_verify(tmp_path):
    path = tmp_path / "trace.jsonl"
    run(HashChainJsonlSink(path).append({"a": 1}))
    run(HashChainJsonlSink(path).append({"b": 2}))
    sink = HashChainJsonlSink(path)
    ok, _ = sink.verify()
    rows = [json.loads(x) for x in path.read_text().splitlines()]
    assert ok and rows[1]["previous_hash"] == rows[0]["hash"]


def test_tamper_detection(tmp_path):
    path = tmp_path / "trace.jsonl"
    sink = HashChainJsonlSink(path)
    run(sink.append({"a": 1}))
    path.write_text(path.read_text().replace('"a": 1', '"a": 2'))
    ok, _ = sink.verify()
    assert not ok
