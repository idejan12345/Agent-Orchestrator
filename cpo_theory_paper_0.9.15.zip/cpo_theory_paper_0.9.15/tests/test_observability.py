from cpo.observability import MetricsRegistry


def test_prometheus_text_format():
    m = MetricsRegistry()
    m.inc("requests_total", (("status", "200"),))
    m.gauge_add("inflight", value=2)
    m.observe("latency", 0.25)
    text = m.render()
    assert 'requests_total{status="200"} 1' in text
    assert "latency_seconds_sum 0.25" in text and text.endswith("\n")
