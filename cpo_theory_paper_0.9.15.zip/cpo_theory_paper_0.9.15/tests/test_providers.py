import asyncio
import json

import httpx
import pytest
from pydantic import ValidationError

from cpo.providers import (
    AnthropicMessagesConfig,
    AnthropicMessagesProvider,
    AzureResponsesConfig,
    AzureResponsesProvider,
    OpenAIResponsesConfig,
    OpenAIResponsesProvider,
    ProviderError,
)


def run(coro):
    return asyncio.run(coro)


def client(handler):
    return httpx.AsyncClient(transport=httpx.MockTransport(handler), follow_redirects=False)


def json_response(data, status=200, headers=None):
    return httpx.Response(status, json=data, headers=headers or {"content-type": "application/json"})


def test_openai_request_and_parse():
    def handler(request):
        assert request.url == httpx.URL("https://api.openai.com/v1/responses")
        assert request.headers["authorization"] == "Bearer secret"
        assert request.headers["x-client-request-id"] == "req-1"
        payload = json.loads(request.content)
        assert payload["model"] == "model-a" and payload["store"] is False
        return json_response(
            {"id": "resp-1", "output_text": "hello", "usage": {"input_tokens": 3}},
            headers={"content-type": "application/json", "x-request-id": "server-1"},
        )

    provider = OpenAIResponsesProvider(
        OpenAIResponsesConfig(model="model-a", api_key="secret"), client=client(handler)
    )
    result = run(provider.generate("prompt", request_id="req-1"))
    assert result.text == "hello" and result.request_id == "server-1"


def test_azure_api_key_request_and_parse():
    def handler(request):
        assert request.url == httpx.URL("https://unit.openai.azure.com/openai/v1/responses")
        assert request.headers["api-key"] == "secret"
        assert "authorization" not in request.headers
        return json_response(
            {"id": "az-1", "output": [{"content": [{"type": "output_text", "text": "azure"}]}]}
        )

    cfg = AzureResponsesConfig(
        model="deployment", endpoint="https://unit.openai.azure.com/", api_key="secret"
    )
    result = run(AzureResponsesProvider(cfg, client=client(handler)).generate("p", request_id="r"))
    assert result.text == "azure" and result.provider == "azure-openai"


def test_azure_bearer_and_exactly_one_credential():
    with pytest.raises(ValidationError):
        AzureResponsesConfig(model="x", endpoint="https://unit.openai.azure.com")
    with pytest.raises(ValidationError):
        AzureResponsesConfig(
            model="x", endpoint="https://unit.openai.azure.com", api_key="a", bearer_token="b"
        )

    def handler(request):
        assert request.headers["authorization"] == "Bearer token"
        return json_response({"output_text": "entra"})

    cfg = AzureResponsesConfig(model="x", endpoint="https://unit.openai.azure.com", bearer_token="token")
    assert (
        run(AzureResponsesProvider(cfg, client=client(handler)).generate("p", request_id="r")).text == "entra"
    )


def test_anthropic_headers_payload_and_parse():
    def handler(request):
        assert request.url == httpx.URL("https://api.anthropic.com/v1/messages")
        assert request.headers["x-api-key"] == "secret"
        assert request.headers["anthropic-version"] == "2023-06-01"
        payload = json.loads(request.content)
        assert payload["messages"][0]["content"] == "prompt"
        return json_response(
            {"id": "m-1", "content": [{"type": "text", "text": "anthropic"}], "usage": {"input_tokens": 2}}
        )

    cfg = AnthropicMessagesConfig(model="model-c", api_key="secret")
    result = run(AnthropicMessagesProvider(cfg, client=client(handler)).generate("prompt", request_id="r"))
    assert result.text == "anthropic" and result.request_id == "m-1"


def test_endpoint_allowlists_and_embedded_credentials():
    with pytest.raises(ValidationError):
        OpenAIResponsesConfig(model="x", api_key="k", base_url="https://evil.example")
    with pytest.raises(ValidationError):
        AzureResponsesConfig(model="x", api_key="k", endpoint="https://evil.example")
    with pytest.raises(ValidationError):
        AnthropicMessagesConfig(model="x", api_key="k", base_url="https://user:pw@api.anthropic.com")


def test_redirect_error_body_sanitization_and_response_limit():
    def redirect(_):
        return httpx.Response(302, headers={"location": "https://evil.example"})

    p = OpenAIResponsesProvider(
        OpenAIResponsesConfig(model="x", api_key="super-secret", max_retries=0), client=client(redirect)
    )
    with pytest.raises(ProviderError) as exc:
        run(p.generate("p", request_id="r"))
    assert "super-secret" not in str(exc.value) and "evil.example" not in str(exc.value)

    def oversized(_):
        return httpx.Response(200, content=b"x" * 2048, headers={"content-type": "application/json"})

    p = OpenAIResponsesProvider(
        OpenAIResponsesConfig(model="x", api_key="k", max_response_bytes=1024), client=client(oversized)
    )
    with pytest.raises(ProviderError):
        run(p.generate("p", request_id="r"))


def test_retries_429_then_success():
    attempts = {"n": 0}

    def handler(_):
        attempts["n"] += 1
        if attempts["n"] == 1:
            return json_response({"error": "limited"}, status=429)
        return json_response({"output_text": "ok"})

    cfg = OpenAIResponsesConfig(model="x", api_key="k", max_retries=1)
    assert (
        run(OpenAIResponsesProvider(cfg, client=client(handler)).generate("p", request_id="r")).text == "ok"
    )
    assert attempts["n"] == 2


def test_anthropic_drops_temperature_when_model_rejects_it():
    """Some models answer 400 '`temperature` is deprecated for this model'.  The adapter must
    retry once without it and stop sending it afterwards."""
    seen = []

    def handler(request):
        payload = json.loads(request.content)
        seen.append("temperature" in payload)
        if "temperature" in payload:
            return json_response(
                {
                    "type": "error",
                    "error": {
                        "type": "invalid_request_error",
                        "message": "`temperature` is deprecated for this model.",
                    },
                },
                status=400,
            )
        return json_response(
            {
                "id": "msg-1",
                "model": "claude-x",
                "content": [{"type": "text", "text": "ok"}],
                "usage": {"input_tokens": 1, "output_tokens": 1},
            }
        )

    provider = AnthropicMessagesProvider(
        AnthropicMessagesConfig(model="claude-x", api_key="secret", temperature=0.7), client=client(handler)
    )
    assert run(provider.generate("p", request_id="r1")).text == "ok"
    assert run(provider.generate("p", request_id="r2")).text == "ok"
    assert seen == [True, False, False]  # rejected once, dropped, never sent again


def test_anthropic_other_400s_still_raise():
    def handler(request):
        return json_response(
            {"type": "error", "error": {"type": "invalid_request_error", "message": "max_tokens: too large"}},
            status=400,
        )

    provider = AnthropicMessagesProvider(
        AnthropicMessagesConfig(model="claude-x", api_key="secret", temperature=0.7), client=client(handler)
    )
    with pytest.raises(ProviderError, match="400"):
        run(provider.generate("p", request_id="r1"))


def test_rate_limit_is_retried_with_backoff(monkeypatch):
    """429 and 529 are retried; a Retry-After header sets the wait; the request eventually succeeds."""
    import cpo.providers.base as base

    sleeps = []

    async def fake_sleep(s):
        sleeps.append(s)

    monkeypatch.setattr(base.asyncio, "sleep", fake_sleep)
    calls = {"n": 0}

    def handler(request):
        calls["n"] += 1
        if calls["n"] == 1:
            return json_response(
                {"error": {"message": "rate limited"}},
                status=429,
                headers={"retry-after": "2", "content-type": "application/json"},
            )
        if calls["n"] == 2:
            return json_response({"error": {"message": "overloaded"}}, status=529)
        return json_response(
            {"id": "m", "model": "claude-x", "content": [{"type": "text", "text": "ok"}], "usage": {}}
        )

    provider = AnthropicMessagesProvider(
        AnthropicMessagesConfig(model="claude-x", api_key="secret"), client=client(handler)
    )
    assert run(provider.generate("p", request_id="r")).text == "ok"
    assert calls["n"] == 3
    assert sleeps[0] == 2.0  # Retry-After honoured
    assert 0.5 <= sleeps[1] <= 2.0  # exponential with jitter for attempt 1


def test_backoff_caps_at_thirty_seconds():
    from cpo.providers.base import HttpProvider

    assert HttpProvider._backoff(10, None) <= 30.0
    assert HttpProvider._backoff(0, "45") == 45.0
    assert HttpProvider._backoff(0, "garbage") <= 1.0
