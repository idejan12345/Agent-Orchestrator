import asyncio

import pytest

from cpo.config import CPOConfig
from cpo.consumers import TextConsumer
from cpo.errors import NoCandidates, PolicyRejected
from cpo.models import Candidate, OrchestrationRequest
from cpo.orchestrator import Orchestrator
from cpo.specialists import EchoSpecialist, FailingSpecialist, NoisySpecialist
from cpo.tracing import HashChainJsonlSink


def run(coro):
    return asyncio.run(coro)


def build(specialists=None, **cfg):
    specialists = specialists or [
        EchoSpecialist("analysis", "Analysis"),
        EchoSpecialist("planning", "Plan"),
        EchoSpecialist("review", "Review"),
        NoisySpecialist(),
    ]
    return Orchestrator(specialists, [TextConsumer()], config=CPOConfig(**cfg))


REQ = OrchestrationRequest(
    input="Summarize the quarterly incident review and propose two mitigations for the payments outage.",
    goal="short plan",
)


def test_loop_reaches_fixed_point_votes_out_noise_and_is_reconfirmed():
    r = run(build().run(REQ))
    assert r.status == "completed" and r.workspace.terminal_kind == "fixed_point"
    assert all("noise" not in t.selected_sources for t in r.cycles)
    assert (
        r.cycles[-1].change_signal <= CPOConfig().fixed_point_threshold
        and len(r.cycles[-1].selected_sources) >= 2
    )
    assert r.reconfirmation.status == "reconfirmed"
    assert r.diagnostics["plane_proxy"]["status"] in {"proxy", "insufficient_cycles"}
    assert "hallucination" not in str(r.model_dump()).lower()


def test_run_is_deterministic():
    a, b = run(build().run(REQ)), run(build().run(REQ))
    assert [t.reference_signature for t in a.cycles] == [t.reference_signature for t in b.cycles]
    assert a.workspace.synthesis == b.workspace.synthesis


def test_reference_delta_is_xor_of_consecutive_references():
    r = run(build().run(REQ))
    seed = r.diagnostics["reference_trajectory"]
    for prev, t in zip(r.cycles, r.cycles[1:]):
        assert int(prev.reference_signature, 16) ^ int(t.reference_signature, 16) == int(
            t.reference_delta, 16
        )
        assert int(t.reference_delta, 16).bit_count() == t.reference_delta_weight
    assert seed == [t.reference_signature for t in r.cycles]


def test_budget_exhausted_reported_when_pool_keeps_moving():
    class Drift:
        concurrency_safe = True

        def __init__(self, name):
            self.name, self.i = name, 0

        async def propose(self, request, workspace):
            self.i += 1
            return [Candidate(source=self.name, content=" ".join(f"w{self.i}x{j}" for j in range(30)))]

        async def receive_broadcast(self, workspace):
            pass

    r = run(build([Drift("a"), Drift("b")], max_cycles=3, fixed_point_threshold=0.0).run(REQ))
    assert r.workspace.terminal_kind == "budget_exhausted"
    assert r.reconfirmation.status == "untested"


def test_cycle_detection():
    class Alternate:
        concurrency_safe = True

        def __init__(self, name, texts):
            self.name, self.texts, self.i = name, texts, 0

        async def propose(self, request, workspace):
            self.i += 1
            return [Candidate(source=self.name, content=self.texts[self.i % 2])]

        async def receive_broadcast(self, workspace):
            pass

    a, b = "alpha beta gamma delta " * 8, "lantern quartz harbor meridian " * 8
    r = run(
        build(
            [Alternate("x", [a, b]), Alternate("y", [a, b])], k_min=1, max_cycles=8, fixed_point_threshold=0.0
        ).run(REQ)
    )
    assert r.workspace.terminal_kind == "cycle"


def test_not_reconfirmed_when_blind_pool_disagrees():
    class Sycophant:
        """First cycle: a transient reading.  Later cycles: echoes the workspace, so the loop
        locks onto its own history.  On a fresh blind pool the environment says something else."""

        concurrency_safe = True

        def __init__(self, name):
            self.name = name

        async def propose(self, request, workspace):
            if request.context.get("_cpo_resample"):
                return [
                    Candidate(
                        source=self.name,
                        content=f"{self.name} lantern quartz harbor meridian saffron ledger orbit",
                    )
                ]
            if workspace is None:
                return [
                    Candidate(
                        source=self.name,
                        content=f"transient reading {self.name} about the outage review plan",
                    )
                ]
            return [Candidate(source=self.name, content=workspace.synthesis)]

        async def receive_broadcast(self, workspace):
            pass

    r = run(build([Sycophant("s1"), Sycophant("s2"), Sycophant("s3")]).run(REQ))
    assert r.workspace.terminal_kind == "fixed_point"
    assert r.reconfirmation.status == "not_reconfirmed"
    assert any("not reconfirmed" in w for w in r.warnings)


def test_policy_rejections_and_failures():
    with pytest.raises(PolicyRejected):
        run(build().run(OrchestrationRequest(input="api_key = abcdefghijklmnop1234")))
    with pytest.raises(NoCandidates):
        run(build([FailingSpecialist()]).run(REQ))
    r = run(build([EchoSpecialist("a", "A"), EchoSpecialist("b", "B"), FailingSpecialist()]).run(REQ))
    assert r.status == "partial" and any("failing:RuntimeError" in f for f in r.cycles[0].failures)


def test_hard_risk_candidates_are_rejected_not_promoted():
    r = run(
        build(
            [
                EchoSpecialist("safe", "Safe"),
                EchoSpecialist("risky", "Risky", risk=0.95),
                EchoSpecialist("also", "Also"),
            ]
        ).run(REQ)
    )
    assert all("risky" not in t.selected_sources for t in r.cycles)
    assert any("risky:rejected:hard_risk_threshold" in f for f in r.cycles[0].failures)


def test_component_validation():
    class Unsafe:
        name = "u"
        concurrency_safe = False

        async def propose(self, r, w):
            return []

        async def receive_broadcast(self, w):
            pass

    with pytest.raises(ValueError):
        Orchestrator([Unsafe()], [TextConsumer()])
    with pytest.raises(ValueError):
        Orchestrator([EchoSpecialist("a", "A"), EchoSpecialist("a", "B")], [TextConsumer()])
    with pytest.raises(ValueError):
        CPOConfig(workspace_slots=8, target_bundle=4)  # B_max = 3


def test_trace_chain_written_and_verifies(tmp_path):
    sink = HashChainJsonlSink(tmp_path / "t.jsonl")
    o = Orchestrator(
        [EchoSpecialist("a", "A"), EchoSpecialist("b", "B")],
        [TextConsumer()],
        config=CPOConfig(),
        trace_sink=sink,
    )
    run(o.run(REQ))
    ok, _ = sink.verify()
    assert ok
    text = (tmp_path / "t.jsonl").read_text()
    assert '"type": "cycle"' in text and '"type": "terminal"' in text


def test_concurrent_requests_isolated():
    o = build()

    async def many():
        return await asyncio.gather(
            *(
                o.run(OrchestrationRequest(input=f"topic {i} about the outage review", request_id=f"r{i}"))
                for i in range(6)
            )
        )

    results = run(many())
    assert len({r.request_id for r in results}) == 6 and all(r.workspace for r in results)


def test_response_carries_bundle_with_correlations():
    r = run(build().run(REQ))
    assert r.bundle is not None and r.bundle["correlations"] is not None
    assert len(r.bundle["constituents"]) == len(r.bundle["correlations"]) >= 2
    assert r.bundle["binding_share_bound"] is None  # bundled mode ships correlations, so no bound applies


def test_empty_later_cycle_keeps_previous_workspace():
    """A provider that goes silent after the first cycle must not destroy the answer already reached."""

    class SilentAfterFirst:
        concurrency_safe = True

        def __init__(self, name):
            self.name, self.calls = name, 0

        async def propose(self, request, workspace):
            self.calls += 1
            if workspace is not None:
                raise RuntimeError("response did not contain text output")
            return [
                Candidate(
                    source=self.name, content=f"{self.name}: the total is sixty minus eight.\nAnswer: 52"
                )
            ]

        async def receive_broadcast(self, workspace):
            pass

    r = run(
        build(
            [SilentAfterFirst("a"), SilentAfterFirst("b"), SilentAfterFirst("c")],
            max_cycles=4,
            fixed_point_threshold=0.0,
            reconfirmation_rounds=0,
        ).run(REQ)
    )
    assert r.workspace is not None
    assert r.workspace.terminal_kind == "pool_exhausted"
    assert "Answer: 52" in r.workspace.synthesis
    assert any("kept previous workspace" in w for w in r.warnings)
    assert r.status == "partial"


def test_empty_first_cycle_still_raises():
    with pytest.raises(NoCandidates):
        run(build([FailingSpecialist()]).run(REQ))


def test_min_cycles_governs_exact_repeat_as_well_as_threshold():
    """A reference that repeats exactly before ``min_cycles`` must not end the run as a fixed
    point; both fixed-point criteria wait for ``min_cycles``, and ``converged`` then agrees with
    ``terminal_kind``."""

    class Constant:
        concurrency_safe = True

        def __init__(self, name):
            self.name = name

        async def propose(self, request, workspace):
            return [Candidate(source=self.name, content="alpha beta gamma delta " * 8)]

        async def receive_broadcast(self, workspace):
            pass

    specialists = [Constant("x"), Constant("y")]
    r = run(build(specialists, k_min=1, max_cycles=6, min_cycles=3, fixed_point_threshold=0.0).run(REQ))
    assert r.workspace.terminal_kind == "fixed_point" and r.workspace.converged
    assert len(r.cycles) == 3  # cycles 1 and 2 repeat the reference exactly but may not terminate
    r1 = run(build(specialists, k_min=1, max_cycles=6, fixed_point_threshold=0.0).run(REQ))
    assert r1.workspace.terminal_kind == "fixed_point" and len(r1.cycles) == 2
