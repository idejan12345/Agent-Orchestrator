"""Each test corresponds to a labelled result in the paper."""

import math
import random

import pytest

from cpo.focus import (
    PoolSpec,
    admissible_band,
    band_width,
    chimeras,
    classify,
    consensus,
    duty_cycle,
    flips,
    holdable_alternatives,
    iterate,
    make_pool,
    max_bundle,
    order,
    periodic,
    phi_mincut,
    register_from_span,
    resonance,
    select,
    selection_law_expectation,
    serialisation_binding_bound,
    step_motif,
    xor_triple,
)
from cpo.focus.register import mask

N = 24
RNG = random.Random(2026)


def test_flip_map_is_homomorphism_with_kernel_constant_sequences():
    for _ in range(200):
        u, v = RNG.getrandbits(N), RNG.getrandbits(N)
        assert flips(u ^ v, N) == flips(u, N) ^ flips(v, N)
    assert flips(0, N) == 0 and flips(mask(N), N) == 0
    for u in range(1, mask(N)):
        if u in (0, mask(N)):
            continue
        assert flips(u, N) != 0 or u in (0, mask(N))
        break


def test_orders_of_the_planted_motifs_match_the_paper():
    assert order(step_motif(N), N) == pytest.approx(0.957, abs=1e-3)
    assert order(periodic("0011", N), N) == pytest.approx(0.522, abs=1e-3)


def test_hamming_theorem_resonance_equals_order_of_difference():
    for _ in range(500):
        s, p = RNG.getrandbits(N), RNG.getrandbits(N)
        assert resonance(s, p, N) == pytest.approx(order(s ^ p, N))


def test_selection_law_is_affine_in_the_order_of_the_self():
    # patterns at fractional flip distance tau have mean order tau + (1-2tau) order(s0)
    s0 = step_motif(N)
    for t in (2, 6, 11):
        tau = t / (N - 1)
        samples = []
        for _ in range(4000):
            positions = RNG.sample(range(N - 1), t)
            d = flips(s0, N)
            for pos in positions:
                d ^= 1 << pos
            # rebuild a pattern with flip map d: cumulative xor from bit 0
            p, bit = 0, 0
            for i in range(N):
                if i:
                    bit ^= (d >> (i - 1)) & 1
                p |= bit << i
            samples.append(order(p, N))
        assert sum(samples) / len(samples) == pytest.approx(
            selection_law_expectation(tau, order(s0, N)), abs=0.01
        )
    assert selection_law_expectation(0.5, 0.9) == pytest.approx(0.5)  # no selection -> noise
    assert selection_law_expectation(0.0, 0.9) == pytest.approx(0.9)  # infinitely sharp -> self


def test_consensus_ties_retain_previous_bit_and_is_deterministic():
    prev = 0b1010
    assert consensus([0b1100, 0b0011], prev, 4) == prev
    assert consensus([0b1110, 0b1100, 0b0100], 0, 4) == 0b1100
    assert consensus([], prev, 4) == prev


def test_select_keeps_ceil_phi_fraction_with_index_tiebreak():
    pool = [0b0000, 0b1111, 0b0001, 0b1110]
    assert select(0b0000, pool, 4, 0.5) == [0b0000, 0b1111]  # both constant-difference; index order


def test_focus_loop_reaches_a_fixed_point_on_the_paper_pool_and_settles_fast():
    pool = make_pool(PoolSpec(size=4000), seed=3)
    motifs = PoolSpec().resolved_motifs()
    kinds, iterations = [], []
    for _ in range(20):
        run = iterate(RNG.getrandbits(N), pool, N, 0.10)
        kinds.append(classify(run, motifs, N))
        iterations.append(run.iterations - 1)
    assert all(k.startswith("veridical") or k == "non_motif" for k in kinds)
    assert sum(iterations) / len(iterations) <= 4  # "two to four iterations"
    assert sum(k.startswith("veridical") for k in kinds) >= 15  # motifs capture the great majority


def test_chimera_count_matches_the_paper():
    m1, m2 = PoolSpec().resolved_motifs()
    assert len(chimeras(m1, m2, N)) == 268


def test_capacity_theorem_numbers_at_n24():
    assert holdable_alternatives(24, 12) == 7 and max_bundle(24) == 7
    assert holdable_alternatives(24, 0) == 1 and holdable_alternatives(24, 24) == 1
    assert admissible_band(24, 6) == (10, 14) and admissible_band(24, 7) == (12, 12)
    assert admissible_band(24, 8) is None and band_width(24, 7) == 1
    assert register_from_span(7) == 24 and register_from_span(4) == 12


def test_duty_cycle_table_row_values():
    assert duty_cycle(24, 5) == pytest.approx(0.936, abs=1e-3)
    assert duty_cycle(24, 6) == pytest.approx(0.693, abs=1e-3)
    assert duty_cycle(24, 7) == pytest.approx(0.161, abs=1e-3)
    assert duty_cycle(24, 8) == 0.0
    assert duty_cycle(24, 7, sigma=1) == pytest.approx(0.399, abs=2e-3)


def test_serialisation_bound_is_below_one_half():
    for b in range(2, 50):
        assert serialisation_binding_bound(b) < 0.5
    assert serialisation_binding_bound(7) == pytest.approx(6 / 13)


def test_phi_mincut_of_xor_triple_is_exactly_one_bit():
    value, cut = phi_mincut(xor_triple())
    assert value == pytest.approx(1.0) and len(cut) == 1
    independent = {(x, y): 0.25 for x in (0, 1) for y in (0, 1)}
    assert phi_mincut(independent)[0] == pytest.approx(0.0)


def test_strict_reconfirmation_rejects_what_the_tie_rule_lets_through():
    """Two fresh candidates that are bitwise complements tie on every position.  The tie rule then
    returns the converged reference itself (distance 0: 'reconfirmed'), although the blind pool
    carries no information; the strict verdict also requires the unbiased blind-consensus distance
    to be within theta, and rejects."""
    from cpo.reconfirmation import reconfirm
    from cpo.sketch import Signature

    n = 64
    ref = Signature(int("10" * 32, 2), n)
    s1 = Signature(int("1100" * 16, 2), n)
    s2 = Signature(s1.bits ^ ((1 << n) - 1), n)  # complement of s1

    class Fixed:
        def sign(self, text):
            return {"one": s1, "two": s2}[text]

    rep = reconfirm(ref, "synthesis", [["one", "two"]], n=n, theta=0.15, phi=1.0, k_min=2, signer=Fixed())
    assert rep.status == "reconfirmed" and rep.distances == [0.0]
    assert rep.blind_consensus_distance is not None and rep.blind_consensus_distance > 0.15
    assert rep.strict_status == "not_reconfirmed"


def test_capacity_theorem_by_exhaustive_search():
    """Theorem 3, checked by brute force: a configuration of occupancy N holds B alternatives
    apart (B-1 further configurations of occupancy N whose differences from it are pairwise
    disjoint and of size >= 4) for B up to exactly 1 + floor(min(N, n-N)/2), for every n <= 8."""
    from itertools import combinations

    def most_held_apart(n, occupancy):
        base = frozenset(range(occupancy))
        diffs = [base.symmetric_difference(y) for y in combinations(range(n), occupancy)]
        diffs = [d for d in diffs if len(d) >= 4]
        best = 0

        def extend(start, used, k):
            nonlocal best
            best = max(best, k)
            for j in range(start, len(diffs)):
                if not diffs[j] & used:
                    extend(j + 1, used | diffs[j], k + 1)

        extend(0, frozenset(), 0)
        return 1 + best

    for n in range(1, 9):
        for occupancy in range(n + 1):
            held = most_held_apart(n, occupancy)
            assert held == 1 + min(occupancy, n - occupancy) // 2
            assert held == math.floor(holdable_alternatives(n, occupancy))
            band = admissible_band(n, held)
            assert band is not None and band[0] <= occupancy <= band[1]
        assert max(most_held_apart(n, k) for k in range(n + 1)) == max_bundle(n)
