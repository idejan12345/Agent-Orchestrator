import asyncio

import pytest

from cpo.focus_loop import ConsensusReport
from cpo.models import Candidate, CandidateAssessment, OrchestrationRequest, SelectedCandidate
from cpo.provider_specialist import ProviderConsensusWriter, ProviderSpecialist
from cpo.providers.base import ProviderResult
from cpo.sketch import Signature


def run(coro):
    return asyncio.run(coro)


class FakeProvider:
    provider_name = "fake"

    def __init__(self):
        self.prompts = []

    async def generate(self, prompt, request_id):
        self.prompts.append((prompt, request_id))
        return ProviderResult("answer", "fake", "m", "pr-1", {"input_tokens": 1})

    async def readiness(self):
        return True, "ok"

    async def close(self):
        pass


def test_provider_specialist_metadata_and_blind_resample_prompt():
    p = FakeProvider()
    s = ProviderSpecialist("provider-a", p, role_instruction="Analyze evidence.")
    c = run(s.propose(OrchestrationRequest(input="x", request_id="r1"), None))[0]
    assert c.content == "answer" and c.claimed_risk == 0.0 and c.metadata["blind"] is True
    assert p.prompts[-1][1] == "r1" and "shared workspace" not in p.prompts[-1][0]
    run(s.propose(OrchestrationRequest(input="x", request_id="r1", context={"_cpo_resample": 2}), None))
    assert p.prompts[-1][1] == "r1:resample:2"


def test_prompt_limit():
    s = ProviderSpecialist("p", FakeProvider(), role_instruction="r", max_prompt_chars=10)
    with pytest.raises(ValueError):
        run(s.propose(OrchestrationRequest(input="long"), None))


def test_consensus_writer_uses_provider_and_falls_back_to_medoid():
    sel = [
        SelectedCandidate(
            candidate=Candidate(source="a", content="draft a"),
            assessment=CandidateAssessment(
                source="a",
                candidate_index=0,
                signature="00",
                resonance=0.9,
                binding=0.0,
                risk=0.0,
                weight=0.9,
            ),
        )
    ]
    report = ConsensusReport(Signature.of_text("draft a"), 1.0, 0)
    assert run(ProviderConsensusWriter(FakeProvider()).write(sel, report, None, 1000)) == "answer"

    class Broken(FakeProvider):
        async def generate(self, prompt, request_id):
            raise RuntimeError("down")

    assert run(ProviderConsensusWriter(Broken()).write(sel, report, None, 1000)) == "draft a"
