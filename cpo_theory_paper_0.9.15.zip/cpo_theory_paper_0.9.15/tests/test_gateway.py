import asyncio
import hashlib
import hmac
import time

import pytest
from fastapi import HTTPException
from starlette.requests import Request

from cpo.gateway import GatewayIdentityVerifier, InMemoryQuotaManager


def run(c):
    return asyncio.run(c)


def request(body=b"{}"):
    sent = False

    async def receive():
        nonlocal sent
        if sent:
            return {"type": "http.request", "body": b"", "more_body": False}
        sent = True
        return {"type": "http.request", "body": body, "more_body": False}

    return Request(
        {
            "type": "http",
            "method": "POST",
            "path": "/v1/orchestrate",
            "headers": [],
            "scheme": "https",
            "server": ("x", 443),
            "client": ("x", 1),
            "query_string": b"",
        },
        receive,
    )


def signature(secret, principal, timestamp, body=b"{}"):
    canonical = "\n".join(
        [principal, str(timestamp), "POST", "/v1/orchestrate", hashlib.sha256(body).hexdigest()]
    )
    return hmac.new(secret.encode(), canonical.encode(), hashlib.sha256).hexdigest()


def test_signed_identity_binds_body_and_expiry():
    now = int(time.time())
    v = GatewayIdentityVerifier("secret", clock_skew_s=5)
    body = b'{"x":1}'
    p = run(
        v.verify(request(body), "alice", str(now), signature("secret", "alice", now, body), "analyst,user")
    )
    assert p.principal_id == "alice" and p.roles == ("analyst", "user")
    with pytest.raises(HTTPException):
        run(v.verify(request(b'{"x":2}'), "alice", str(now), signature("secret", "alice", now, body), None))
    with pytest.raises(HTTPException):
        run(v.verify(request(), "alice", str(now - 99), signature("secret", "alice", now - 99), None))


def test_quota_and_release():
    q = InMemoryQuotaManager(units_per_minute=1, burst=2, max_concurrent=1)
    run(q.acquire("a", 1))
    with pytest.raises(HTTPException):
        run(q.acquire("a", 1))
    run(q.release("a"))
    run(q.acquire("a", 1))
    run(q.release("a"))
    with pytest.raises(HTTPException):
        run(q.acquire("a", 1))


def test_replay_rejected():
    now = int(time.time())
    body = b'{"r":1}'
    sig = signature("secret", "carol", now, body)
    v = GatewayIdentityVerifier("secret")
    run(v.verify(request(body), "carol", str(now), sig, "user"))
    with pytest.raises(HTTPException) as exc:
        run(v.verify(request(body), "carol", str(now), sig, "user"))
    assert exc.value.status_code == 409
