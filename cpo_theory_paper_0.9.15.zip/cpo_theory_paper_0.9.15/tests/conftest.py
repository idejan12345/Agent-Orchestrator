"""Test-session configuration.

``cpo.api`` reads ``CPO_TRACE_PATH`` at import time and defaults to ``cpo-traces.jsonl`` in the
current directory, so running the API tests from the repository root used to write a live trace
log (and its lock file) into the source tree -- which is how one reached the 0.9.2 release
archive.  Point it at a throwaway directory before anything imports the API.
"""

import os
import tempfile

_TRACE_DIR = tempfile.mkdtemp(prefix="cpo-test-traces-")
os.environ.setdefault("CPO_TRACE_PATH", os.path.join(_TRACE_DIR, "cpo-traces.jsonl"))
