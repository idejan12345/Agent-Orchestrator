"""The theory paper's experiment tables print the numbers in its data, and the checker would notice
if they did not."""

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_theory_paper_tables_match_their_data_and_a_planted_error_is_caught():
    sys.path.insert(0, str(ROOT / "scripts"))
    from check_theory_numbers import DATA, TEX, check_tables

    tex = TEX.read_text(encoding="utf-8")
    data = json.loads(DATA.read_text(encoding="utf-8"))
    checked, problems, rows = check_tables(tex, data)
    assert problems == [] and checked > 100
    assert rows == {
        "erosion": 2,
        "phi": 4,
        "reconf": 6,
        "occupancy": 3,
        "breadth": 2,
        "scaling": 4,
        "prop1": 9,
        "delta": 4,
    }

    planted = tex.replace(
        "full map, mean order & $0.752$ & $0.937$", "full map, mean order & $0.752$ & $0.973$", 1
    )
    assert planted != tex
    _, problems, _ = check_tables(planted, data)
    assert any("erosion consensus step 1" in p for p in problems)
