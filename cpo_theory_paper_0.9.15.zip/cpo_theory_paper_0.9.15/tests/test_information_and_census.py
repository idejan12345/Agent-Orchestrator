import random

import pytest

from cpo.focus import (
    PoolSpec,
    estimate_M_star,
    estimate_W,
    exact_binomial_interval,
    mutual_information,
    run_census,
)
from cpo.focus.archetypes import ARCHETYPES, build_reference, environment


def test_exact_binomial_interval_matches_paper_example():
    lo, hi = exact_binomial_interval(18, 200)
    assert lo == pytest.approx(0.054, abs=0.002) and hi == pytest.approx(0.139, abs=0.002)
    assert exact_binomial_interval(0, 10)[0] == 0.0 and exact_binomial_interval(10, 10)[1] == 1.0


def test_census_reproduces_structure_not_rate():
    report = run_census(PoolSpec(size=3000), runs=40, seeds=(1, 2), random_baseline=100)
    summary = report.summary()
    assert summary["runs_total"] == 80
    for seed in report.seeds:
        assert seed.fixed_point_rate >= 0.9  # the loop settles
        assert sum(v for k, v in seed.counts.items() if k.startswith("veridical")) >= 0.6 * seed.runs
        if seed.non_motif_mean_distance_to_nearest_chimera is not None:
            # non-motif attractors sit nearer chimeras than random sequences do
            assert (
                seed.non_motif_mean_distance_to_nearest_chimera < seed.random_mean_distance_to_nearest_chimera
            )
    assert 0.0 <= summary["pooled_non_motif_rate"] <= 0.25


def test_mutual_information_basic_identities():
    x = [0, 1] * 500
    assert mutual_information(x, x) == pytest.approx(1.0)
    assert mutual_information(x, [0] * 1000) == pytest.approx(0.0)


def test_estimators_refuse_small_samples():
    assert estimate_W([0, 1] * 20, [0, 1] * 20).status == "insufficient_samples"
    assert estimate_M_star([0, 1] * 20, None).status == "insufficient_samples"


def test_periodic_reference_has_two_bits_of_raw_excess_entropy():
    # Appendix worked example: period-4 motif at random phase -> M = log2 4 = 2 bits
    rng = random.Random(1)
    phase = rng.randrange(4)
    motif = (1, 0, 1, 1)
    bits = [motif[(phase + i) % 4] for i in range(6000)]
    m = estimate_M_star(bits, None, offsets=4000, seed=1)
    assert m.status == "ok" and m.value == pytest.approx(2.0, abs=0.05)


def test_plane_axes_are_dissociable():
    """The only claim the archetype table supports: dreamer high M*, low W; animal the reverse."""
    rng = random.Random(5)
    env, _ = environment(40_000, rng)
    by_name = {a.name: a for a in ARCHETYPES}

    def coords(name):
        ref = build_reference(by_name[name], env, random.Random(7))
        return (
            estimate_W(ref, env, offsets=15_000, seed=3).value,
            estimate_M_star(ref, env, offsets=15_000, seed=3).value,
        )

    w_animal, m_animal = coords("animal")
    w_dreamer, m_dreamer = coords("dreamer")
    w_noise, m_noise = coords("noise")
    assert w_animal > 0.5 and w_dreamer < 0.15
    assert m_dreamer > 0.2 and m_dreamer > m_animal
    assert w_noise < 0.05 and m_noise < 0.05
