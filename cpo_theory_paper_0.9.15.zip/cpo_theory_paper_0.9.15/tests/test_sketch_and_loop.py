import asyncio

import pytest

from cpo.binding import min_cut_binding, split_parts
from cpo.focus_loop import MedoidConsensusWriter, TextFocusLoop
from cpo.models import Candidate
from cpo.occupancy import OccupancyController
from cpo.reconfirmation import recombination_test, reconfirm
from cpo.sketch import Signature, majority
from cpo.tower import Atom, bundle


def test_signature_is_deterministic_and_overlap_monotone():
    a = "the payments service failed during peak traffic because of connection pool exhaustion"
    b = "the payments service failed during peak traffic because of a certificate expiry"
    c = "lanterns and quartz harbor the saffron meridian"
    sa, sb, sc = (Signature.of_text(t) for t in (a, b, c))
    assert sa == Signature.of_text(a)
    assert sa.hamming(sb) < sa.hamming(sc)
    assert 0.0 <= sa.similarity(sb) <= 1.0 and sa.hex() == Signature.from_hex(sa.hex(), 256).hex()


def test_majority_ties_retain_previous_bit():
    prev = Signature(0b1010, 8)
    assert majority([Signature(0b1100, 8), Signature(0b0011, 8)], prev) == prev
    assert majority([], prev) == prev


def test_binding_proxy_zero_for_disjoint_parts_and_positive_for_shared_terms():
    disjoint = "Alpha beta gamma delta.\n\nOmicron pi rho sigma."
    shared = "The cache layer failed under load.\n\nThe cache layer must be resized for load."
    assert min_cut_binding(disjoint) == 0.0
    assert min_cut_binding(shared) > 0.0
    assert min_cut_binding("single part only") == 0.0
    assert len(split_parts("a. " * 50 + "B", max_parts=8)) <= 8


def _loop():
    return TextFocusLoop(
        n=256, phi=0.5, k_min=2, resonance_exponent=1.0, binding_exponent=0.5, hard_risk_threshold=0.8
    )


def test_loop_rejects_hard_risk_and_never_promotes_by_claims():
    loop = _loop()
    ref = Signature.of_text("plan the migration of the payments database")
    cands = [
        Candidate(
            source="a", content="plan the migration of the payments database carefully", claimed_risk=0.9
        ),
        Candidate(source="b", content="plan the migration of the payments database in stages"),
        Candidate(source="c", content="unrelated lanterns and quartz"),
    ]
    assessed = asyncio.run(loop.assess(ref, cands))
    selected, rejected = loop.select(assessed, selection_cap=8)
    assert [a.source for a in rejected] == ["a"] and rejected[0].reasons == ["hard_risk_threshold"]
    assert [s.candidate.source for s in selected] == ["b", "c"]
    assert selected[0].assessment.resonance > selected[1].assessment.resonance


def test_medoid_writer_is_idempotent_at_a_fixed_point():
    loop = _loop()
    ref = Signature.of_text("agreed draft about the outage")
    cands = [
        Candidate(source="x", content="agreed draft about the outage"),
        Candidate(source="y", content="agreed draft about the outage and its causes"),
    ]
    assessed = asyncio.run(loop.assess(ref, cands))
    selected, _ = loop.select(assessed, selection_cap=8)
    report = loop.consensus(selected, ref)
    text1 = asyncio.run(MedoidConsensusWriter().write(selected, report, None, 1000))
    text2 = asyncio.run(MedoidConsensusWriter().write(selected, report, text1, 1000))
    assert text1 == text2


def test_occupancy_controller_caps_selection_by_tent():
    ctl = OccupancyController(slots=24, target_bundle=3, k_min=1, k_max=8)
    assert ctl.decide(0, 8).report.selection_cap == 1  # empty register holds one alternative
    assert ctl.decide(12, 8).report.selection_cap == 7  # half-filling: B_max
    assert ctl.decide(12, 3).report.selection_cap == 3
    assert ctl.decide(20, 8).report.selection_cap == 3  # 1 + 12*(4/24) = 3, not int(2.999..)
    assert ctl.decide(24, 8).report.regime == "saturated" and ctl.decide(24, 8).action == "compress_workspace"
    assert ctl.decide(2, 8).action == "expand_pool" and ctl.decide(10, 8).action == "hold"


def test_reconfirmation_classifies_fixed_points():
    ref = Signature.of_text("the outage was caused by connection pool exhaustion in payments")
    fresh_same = ["the outage was caused by connection pool exhaustion in payments"] * 3
    fresh_other = ["quartz lantern harbor meridian saffron", "ledger orbit thistle granite velvet"]
    ok = reconfirm(ref, fresh_same[0], [fresh_same], n=256, theta=0.15, phi=0.5, k_min=2)
    bad = reconfirm(ref, fresh_same[0], [fresh_other], n=256, theta=0.15, phi=0.5, k_min=2)
    assert ok.status == "reconfirmed" and bad.status == "not_reconfirmed"
    assert reconfirm(ref, "x", [], n=256, theta=0.15, phi=0.5, k_min=2).status == "untested"
    assert reconfirm(ref, "x", [[]], n=256, theta=0.15, phi=0.5, k_min=2).status == "unavailable"


def test_recombination_test_detects_a_blend():
    synthesis = "alpha beta gamma delta epsilon zeta"
    fresh = ["alpha beta gamma", "delta epsilon zeta", "lantern quartz harbor"]
    single, pair, flag = recombination_test(synthesis, fresh)
    assert flag is True and pair < single


def test_bundle_keeps_correlations_and_flattened_mode_reports_bound():
    atoms = [
        Atom(f"a{i}", f"shared basis with item {i}", Signature.of_text(f"shared basis with item {i}"))
        for i in range(3)
    ]
    b = bundle(atoms, "concept")
    assert b.level == 1 and b.size == 3 and len(b.correlations) == 3
    bundled, flat = b.serialize("bundled"), b.serialize("flattened")
    assert bundled["correlations"] is not None and bundled["binding_share_bound"] is None
    assert flat["correlations"] is None and flat["binding_share_bound"] == pytest.approx(2 / 5)
    with pytest.raises(ValueError):
        bundle(atoms[:1], "x")


def test_thresholded_vector_signer_and_orchestrator_hook():
    import asyncio

    from cpo.config import CPOConfig
    from cpo.consumers import TextConsumer
    from cpo.models import OrchestrationRequest
    from cpo.orchestrator import Orchestrator
    from cpo.sketch import SimHashSigner, ThresholdedVectorSigner
    from cpo.specialists import EchoSpecialist

    def embed(text: str):  # deterministic toy embedding: character-class histogram over 64 dims
        vec = [0.0] * 64
        for i, ch in enumerate(text.lower()):
            vec[(ord(ch) * 31 + i) % 64] += 1.0
        return vec

    signer = ThresholdedVectorSigner(embed, 64)
    a, b = signer.sign("payments outage review"), signer.sign("payments outage review plan")
    assert a.n == 64 and a.hamming(b) < 32
    with pytest.raises(ValueError):
        ThresholdedVectorSigner(embed, 60)
    with pytest.raises(ValueError):  # signer length must match signature_bits
        Orchestrator(
            [EchoSpecialist("a", "A"), EchoSpecialist("b", "B")],
            [TextConsumer()],
            config=CPOConfig(signature_bits=256),
            signer=signer,
        )
    o = Orchestrator(
        [EchoSpecialist("a", "A"), EchoSpecialist("b", "B")],
        [TextConsumer()],
        config=CPOConfig(signature_bits=64),
        signer=signer,
    )
    r = asyncio.run(o.run(OrchestrationRequest(input="review the payments outage and plan mitigations")))
    assert len(r.workspace.reference_signature) == 16 and r.workspace.terminal_kind in {
        "fixed_point",
        "budget_exhausted",
    }
    assert SimHashSigner(256).sign("x") == Signature.of_text("x", 256)


def test_reconfirmation_reports_unbiased_blind_distance():
    ref = Signature.of_text("the outage was caused by connection pool exhaustion in payments")
    rep = reconfirm(
        ref,
        "x",
        [["the outage was caused by connection pool exhaustion in payments"] * 3],
        n=256,
        theta=0.15,
        phi=0.5,
        k_min=2,
    )
    assert rep.blind_consensus_distance is not None and rep.blind_consensus_distance < 0.05
