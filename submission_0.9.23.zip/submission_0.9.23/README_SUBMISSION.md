# Submission package: cpo_theory 0.9.23 (November 2026)

01_manuscript/cpo_theory.pdf              26 pages; Latin Modern Type 1 fonts, no bitmap fonts;
                                          no unresolved references (checked).
02_latex_source/                          cpo_theory.tex + figures/; compiles standalone with
                                          pdflatex (three passes); needs lmodern, amsmath, amssymb,
                                          amsthm, booktabs, array, caption, graphicx, geometry,
                                          hyperref, enumitem. References are inline (thebibliography).
03_supplementary_code/cpo_theory_0.9.23.zip  code and data; verified in a fresh environment
                                          (85 tests, 225 table values, lint, types, build).
04_cover_letter_and_declarations/         cover letter (fill in the journal), highlights
                                          (Elsevier-style, each under 85 characters), declarations.

Before uploading, confirm:
[ ] The GitHub repository holds the 0.9.23 code (see repository_upload/ in the outputs): it currently
    contains only cpo_evaluation_paper_0.9.15.zip, which is outdated and includes the withdrawn
    evaluation paper. Replace it before submitting, since the paper now cites the repository.
[ ] Affiliation for John Hutchinson: the title page still reads "[affiliat]".
[ ] Whether Branislav Stojkovic's employer (Meta) requires an approval or competing-interests statement.
[ ] Author contributions in declarations.txt.
[ ] Date: the title page prints the compile date (no \date line); add \date{November 2026} for a fixed one.
[ ] Journal name in cover_letter.md; adjust the article type if the journal uses another.
[ ] Funding statement ("no external funding") and competing-interests statement are accurate.
[ ] The generative-AI declaration wording matches the journal's required form.
[ ] Optional: archive the GitHub release on Zenodo for a DOI and add it to the Data and code
    availability section; many journals prefer a DOI to a bare repository link.
[ ] Suggested reviewers, if the submission system asks (none are included here).
