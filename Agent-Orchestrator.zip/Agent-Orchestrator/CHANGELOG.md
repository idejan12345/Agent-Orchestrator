# Changelog

## 0.9.24 - release accompanying the theory paper

Theory paper only: the select-consensus map and its three theorems (Hamming theorem, selection
law, capacity theorem, with proofs and exhaustive checks), the transfer to text-level
orchestration, the Chosen-Pattern Orchestrator, Proposition 1 with its direct synthetic test, and
the controlled tests of H1-H3. Evaluation on language-model tasks is not part of this release.

Internal consistency checks shipped with it: theorem tests; `scripts/check_theory_numbers.py`
(every printed table value, the version and the test count against the regenerated data); and
`scripts/check_pdf_refs.py` (no unresolved references, no stale build).
