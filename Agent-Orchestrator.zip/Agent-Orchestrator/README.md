# Select-consensus dynamics for multi-agent orchestration — paper and code

Manuscript: `papers/theory/cpo_theory.tex` (PDF alongside). Package: `cpo-orchestrator 0.9.24`.
Repository: https://github.com/idejan12345/Agent-Orchestrator

Requires Python 3.11 or later (tested with 3.12). The register-level computations and the census
and coordinate tools use only the standard library; the text-level experiments also need pydantic,
which is installed with the package.

The paper states a select-consensus dynamical system on binary registers and proves the three
results it uses (a Hamming theorem, a selection law and a capacity theorem); transfers the map to
text-level orchestration, classifying each result by what survives; specifies the Chosen-Pattern
Orchestrator (CPO); states when selection toward a reference can help a decision (Proposition 1);
tests H1-H3 and Proposition 1 on fully specified synthetic pools; and relates the loop to
classical consensus and attractor dynamics. It makes no claim about language-model tasks.

| what | where |
|---|---|
| register formalism and theorem tests | `src/cpo/focus/`, `tests/test_register_theorems.py` |
| transferred loop, occupancy cap, blind reconfirmation | `src/cpo/focus_loop.py`, `occupancy.py`, `reconfirmation.py` |
| orchestrator, service and provider adapters | `src/cpo/orchestrator.py`, `api.py`, `gateway.py`, `providers/` |
| controlled experiments | `scripts/paper_experiments.py` -> `papers/theory/experiments.json` |
| figures | `scripts/paper_figures.py` -> `papers/theory/figures/` |
| census and coordinates (Appendix B) | `cpo-census`, `cpo-plane` |
| every table value checked against the data | `scripts/check_theory_numbers.py` |

```bash
pip install -e ".[dev]"
make test          # all tests
make experiments   # regenerate experiments.json and the figures from fixed seeds
make papercheck    # every printed table value, the version and the test count, against the data
make paper         # compile the manuscript (LaTeX with lmodern) and check its references
```

`make experiments` regenerates every experiment from its fixed seeds (about two and a half
minutes); the regenerated data are identical to those shipped. Internal consistency is checked
three ways: theorem tests assert the paper's proved results and
stated numbers; `papercheck` compares every printed table value with the regenerated data; and
`make paper` refuses a PDF with unresolved references or one built from another package version.
`SHA256SUMS` lists a checksum for every file in this bundle.
