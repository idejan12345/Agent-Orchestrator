"""SimHash on sentence embeddings as the CPO signature backend.

The default signer hashes word shingles, so resonance measures lexical overlap. This signer
embeds each text with a sentence-embedding model and applies random-hyperplane hashing
(Charikar's SimHash) to the embedding, so the Hamming distance between two signatures estimates
the angle between their embeddings: semantic rather than lexical similarity.

    pip install sentence-transformers numpy
    python examples/embedding_simhash.py

Bit positions are still unordered, so the register theorems apply no more than they do with the
default signer; only the similarity kernel changes.
"""

from __future__ import annotations

import asyncio
import random
from collections.abc import Callable, Sequence
from functools import lru_cache

from cpo.config import CPOConfig
from cpo.consumers import TextConsumer
from cpo.models import OrchestrationRequest
from cpo.orchestrator import Orchestrator
from cpo.sketch import Signature
from cpo.specialists import EchoSpecialist


class EmbeddingSimHashSigner:
    """Random-hyperplane SimHash over an embedding. ``embed`` maps a text to a float vector of
    length ``dim`` and must be deterministic. Bit i is 1 when the embedding lies on the positive
    side of hyperplane i. The hyperplanes come from a fixed seed, so signatures are reproducible."""

    def __init__(self, embed: Callable[[str], Sequence[float]], dim: int, n: int = 256, seed: int = 0):
        if n < 8 or n % 8:
            raise ValueError("signature length must be a positive multiple of 8")
        self.n, self.dim = n, dim
        rng = random.Random(seed)
        self._planes = [[rng.gauss(0.0, 1.0) for _ in range(dim)] for _ in range(n)]
        self._sign = lru_cache(maxsize=4096)(lambda text: self._compute(embed, text))

    def _compute(self, embed: Callable[[str], Sequence[float]], text: str) -> Signature:
        vec = list(embed(text))
        if len(vec) != self.dim:
            raise ValueError(f"embedding length {len(vec)} does not match dim {self.dim}")
        bits = 0
        for i, plane in enumerate(self._planes):
            if sum(p * v for p, v in zip(plane, vec, strict=True)) > 0.0:
                bits |= 1 << i
        return Signature(bits, self.n)

    def sign(self, text: str) -> Signature:
        return self._sign(text)


def sentence_transformer_embedder(
    model_name: str = "all-MiniLM-L6-v2",
) -> tuple[Callable[[str], list[float]], int]:
    """An embedding function and its dimension, from the sentence-transformers library."""
    from sentence_transformers import SentenceTransformer  # imported here: optional dependency

    model = SentenceTransformer(model_name)
    dim = model.get_sentence_embedding_dimension()

    def embed(text: str) -> list[float]:
        return model.encode(text, normalize_embeddings=True).tolist()

    return embed, dim


def main() -> None:
    embed, dim = sentence_transformer_embedder()
    signer = EmbeddingSimHashSigner(embed, dim, n=256)

    a = signer.sign("The bridge collapsed after the storm.")
    b = signer.sign("The span gave way following the storm.")
    c = signer.sign("Quarterly revenue rose by four percent.")
    print(f"paraphrase distance {a.hamming(b)}/256, unrelated distance {a.hamming(c)}/256")

    orchestrator = Orchestrator(
        [EchoSpecialist("a", "A"), EchoSpecialist("b", "B"), EchoSpecialist("c", "C")],
        [TextConsumer()],
        config=CPOConfig(signature_bits=256),  # must equal the signer's n
        signer=signer,
    )
    response = asyncio.run(
        orchestrator.run(OrchestrationRequest(input="review the payments outage and plan mitigations"))
    )
    print("terminal kind:", response.workspace.terminal_kind)


if __name__ == "__main__":
    main()
