import asyncio
import json
import subprocess

import pytest

from cpo.providers import CodexCliConfig, CodexCliProvider, ProviderError


def run(awaitable):
    return asyncio.run(awaitable)


def test_codex_builds_stdin_command(monkeypatch):
    monkeypatch.setattr("cpo.providers.codex_cli.shutil.which", lambda _: "/usr/local/bin/codex")
    provider = CodexCliProvider(
        CodexCliConfig(model="gpt-6-luna", profile="research", sandbox="read-only")
    )

    assert provider.build_command() == [
        "/usr/local/bin/codex",
        "exec",
        "--json",
        "--model",
        "gpt-6-luna",
        "--profile",
        "research",
        "--sandbox",
        "read-only",
        "--ephemeral",
        "-",
    ]


def test_codex_normalizes_legacy_sandbox_name():
    assert CodexCliConfig(sandbox="seatbelt").sandbox == "read-only"


def test_codex_returns_common_provider_result(monkeypatch):
    monkeypatch.setattr("cpo.providers.codex_cli.shutil.which", lambda _: "/usr/local/bin/codex")

    def fake_run(command, **kwargs):
        assert command[-1] == "-"
        assert kwargs["input"] == "hello"
        stdout = "\n".join(
            [
                json.dumps({"type": "thread.started", "thread_id": "thread-1"}),
                json.dumps(
                    {
                        "type": "item.completed",
                        "item": {"type": "agent_message", "text": "answer"},
                    }
                ),
                json.dumps(
                    {
                        "type": "turn.completed",
                        "usage": {"input_tokens": 12, "output_tokens": 4},
                    }
                ),
            ]
        )
        return subprocess.CompletedProcess(command, 0, stdout=stdout, stderr="")

    monkeypatch.setattr("cpo.providers.codex_cli.subprocess.run", fake_run)
    provider = CodexCliProvider(CodexCliConfig())
    assert provider.model == "gpt-5.6-luna"
    result = run(provider.generate("hello", request_id="r-1"))

    assert result.text == "answer"
    assert result.provider == "codex_cli"
    assert result.model == "gpt-5.6-luna"
    assert result.request_id == "r-1"
    assert result.usage["input_tokens"] == 12
    assert result.usage["output_tokens"] == 4
    assert result.usage["thread_id"] == "thread-1"
    assert result.elapsed_s is not None


def test_codex_nonzero_exit_is_sanitized(monkeypatch):
    monkeypatch.setattr("cpo.providers.codex_cli.shutil.which", lambda _: "/usr/local/bin/codex")
    monkeypatch.setattr(
        "cpo.providers.codex_cli.subprocess.run",
        lambda command, **kwargs: subprocess.CompletedProcess(
            command, 7, stdout="", stderr="authentication failed\n"
        ),
    )

    with pytest.raises(ProviderError, match="codex_cli exited with status 7: authentication failed"):
        run(CodexCliProvider(CodexCliConfig()).generate("hello", request_id="r-1"))


def test_codex_readiness_reports_missing_cli(monkeypatch):
    monkeypatch.setattr("cpo.providers.codex_cli.shutil.which", lambda _: None)
    ready, message = run(CodexCliProvider(CodexCliConfig()).readiness())

    assert not ready
    assert "not found" in message
