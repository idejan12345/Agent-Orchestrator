from __future__ import annotations

import asyncio
import json
import shutil
import subprocess
import time
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator

from .base import ProviderError, ProviderResult

DEFAULT_CODEX_MODEL = "gpt-5.6-luna"


class CodexCliConfig(BaseModel):
    """Configuration for the locally authenticated Codex CLI provider."""

    model_config = ConfigDict(extra="forbid")
    model: str | None = Field(default=None, max_length=256)
    codex_path: str = Field(default="codex", min_length=1, max_length=512)
    timeout_s: float = Field(default=180.0, gt=0, le=1800)
    sandbox: str = Field(default="read-only", min_length=1, max_length=64)
    profile: str | None = Field(default=None, max_length=128)
    ephemeral: bool = True

    @field_validator("sandbox")
    @classmethod
    def normalize_sandbox(cls, value: str) -> str:
        # ``seatbelt`` was used by an older Codex CLI; current releases call
        # the same restricted mode ``read-only``.
        aliases = {
            "seatbelt": "read-only",
            "full-access": "danger-full-access",
        }
        normalized = aliases.get(value.strip().lower(), value.strip().lower())
        allowed = {"read-only", "workspace-write", "danger-full-access"}
        if normalized not in allowed:
            raise ValueError(f"unsupported Codex sandbox {value!r}; expected one of {sorted(allowed)}")
        return normalized


class CodexCliProvider:
    """Call the locally installed Codex CLI through the common provider interface.

    The prompt is sent on stdin so shell quoting is not involved. Codex's normal
    final text output is returned as the provider text; CLI diagnostics remain
    separate on stderr and are only included in bounded error messages.
    """

    provider_name = "codex_cli"

    def __init__(self, config: CodexCliConfig):
        self.config = config

    @property
    def model(self) -> str:
        return self.config.model or DEFAULT_CODEX_MODEL

    def build_command(self) -> list[str]:
        path = shutil.which(self.config.codex_path) or self.config.codex_path
        command = [path, "exec", "--json"]
        command.extend(["--model", self.model])
        if self.config.profile:
            command.extend(["--profile", self.config.profile])
        command.extend(["--sandbox", self.config.sandbox])
        if self.config.ephemeral:
            command.append("--ephemeral")
        command.append("-")
        return command

    @staticmethod
    def _parse_jsonl(stdout: str) -> tuple[str, dict[str, Any], str | None]:
        messages: list[str] = []
        usage: dict[str, Any] = {}
        thread_id: str | None = None
        for line in stdout.splitlines():
            if not line.strip():
                continue
            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                continue
            if not isinstance(event, dict):
                continue
            if event.get("type") == "thread.started" and isinstance(event.get("thread_id"), str):
                thread_id = event["thread_id"]
            if event.get("type") == "turn.completed":
                event_usage = event.get("usage")
                if isinstance(event_usage, dict):
                    usage.update(event_usage)
            item = event.get("item")
            if not isinstance(item, dict) or item.get("type") != "agent_message":
                continue
            text = item.get("text")
            if isinstance(text, str) and text.strip():
                messages.append(text.strip())
        text = messages[-1] if messages else ""
        if not text:
            raise ProviderError("codex_cli JSON output did not contain an agent response")
        if not usage:
            usage["accounting"] = "unavailable"
        return text, usage, thread_id

    def _run(self, prompt: str) -> tuple[str, dict[str, Any], list[str], float]:
        command = self.build_command()
        started = time.perf_counter()
        try:
            result = subprocess.run(
                command,
                input=prompt,
                capture_output=True,
                text=True,
                check=False,
                timeout=self.config.timeout_s,
            )
        except FileNotFoundError as exc:
            raise ProviderError(
                "codex_cli was not found. Install the Codex CLI and make sure it is on PATH."
            ) from exc
        except subprocess.TimeoutExpired as exc:
            raise ProviderError(
                f"codex_cli timed out after {self.config.timeout_s:g} seconds"
            ) from exc
        except OSError as exc:
            raise ProviderError(f"codex_cli could not be started: {type(exc).__name__}") from exc

        if result.returncode != 0:
            detail = (result.stderr.strip() or result.stdout.strip())[:240]
            suffix = f": {detail}" if detail else ""
            raise ProviderError(f"codex_cli exited with status {result.returncode}{suffix}")
        text, usage, thread_id = self._parse_jsonl(result.stdout)
        if thread_id:
            usage["thread_id"] = thread_id
        return text, usage, command, time.perf_counter() - started

    async def generate(self, prompt: str, *, request_id: str) -> ProviderResult:
        text, usage, _command, elapsed_s = await asyncio.to_thread(self._run, prompt)
        usage = {"request_id": request_id, **usage}
        return ProviderResult(
            text=text,
            provider=self.provider_name,
            model=self.model,
            request_id=request_id,
            usage=usage,
            elapsed_s=elapsed_s,
        )

    async def readiness(self) -> tuple[bool, str]:
        path = shutil.which(self.config.codex_path)
        if path is None:
            return False, "codex CLI not found on PATH"
        return True, f"configured ({path})"

    async def close(self) -> None:
        return None
